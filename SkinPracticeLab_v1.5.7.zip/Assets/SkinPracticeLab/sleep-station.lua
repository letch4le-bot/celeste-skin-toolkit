local preview=loadCelesteAsset("Assets/SkinPracticeLab/common")
function onTalk()
    miniTextbox("SPL_SLEEP_START");preview.begin()
    preview.play("sleep",3.0);preview.play("asleep",1.0)
    player.StateMachine.Locked=false
    player.StateMachine.State=celeste.Player.StIntroWakeUp
    local elapsed=0
    repeat wait();elapsed=elapsed+engine.DeltaTime
    until player.StateMachine.State~=celeste.Player.StIntroWakeUp or elapsed>10
end
function onEnd(room,skipped) preview.finish(room,skipped) end
