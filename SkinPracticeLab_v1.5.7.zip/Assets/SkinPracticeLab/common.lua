local preview={}
local saved
function preview.begin()
    saved={position=player.Position,gravity=player.DummyGravity,friction=player.DummyFriction,
           animate=player.DummyAutoAnimate,camera=player.ForceCameraUpdate,dashes=player.Dashes,
           facing=player.Facing,rate=player.Sprite.Rate,mode=player.Sprite.Mode,defaultMode=player.DefaultSpriteMode}
    setPlayerState("Dummy",true)
    player.DummyGravity=false;player.DummyFriction=false;player.DummyAutoAnimate=false
    player.Speed=vector2(0,0)
    local wind=getFirstEntity("WindController")
    if wind then
        wind:SetPattern(getEnum("Celeste.WindController+Patterns","None"))
        wind:SnapWind()
    end
end
function preview.play(id,duration)
    if not player.Sprite:Has(id) then
        miniTextbox("SPL_MISSING");log("Missing animation "..id,"SkinPracticeLab");return false
    end
    player.Sprite.Rate=1;player.Sprite:Play(id,true,false)
    wait(duration);return true
end
function preview.finish(room,skipped)
    if saved and player and not player.Dead and player.Scene==room then
        player.StateMachine.Locked=false
        if player.Sprite.Mode~=saved.mode then
            player.DefaultSpriteMode=saved.defaultMode
            player:ResetSprite(saved.mode)
        end
        player.DummyGravity=saved.gravity;player.DummyFriction=saved.friction
        player.DummyAutoAnimate=saved.animate;player.ForceCameraUpdate=saved.camera
        player.Facing=saved.facing;player.Dashes=saved.dashes;player.Sprite.Rate=saved.rate
        player.Speed=vector2(0,0);player.Position=saved.position
        celeste.FallEffects.Show(false)
        enableMovement()
    end
    saved=nil
end
return preview
