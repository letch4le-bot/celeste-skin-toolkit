local stage=loadCelesteAsset("Assets/SkinPracticeLab/stage-common")
function onTalk()
    local selected=choice("SPL_WALK_LAND","SPL_STORY_STATES","SPL_ROLL","SPL_HUG","SPL_THEO_SCENE","SPL_STAY")
    if selected==6 then enableMovement();return end
    local actions
    if selected==2 then actions=stage.pick({"shaking","faint","fainted","halfWakeUp","bagdown"});if #actions==0 then enableMovement();return end end
    if not stage.begin(160) then return end
    local origin=getRoomCoordinates()
    if selected==1 then
        miniTextbox("SPL_ANIM_WALK");player.Facing=getEnum("Celeste.Facings","Right")
        player.Sprite:Play("walk",true,false)
        local t=0
        while t<2 do player.Position=origin+vector2(112+t*40,168);wait();t=t+engine.DeltaTime end
        player.Position=origin+vector2(192,112);player.Sprite:Play("fallSlow",true,false);t=0
        while t<.45 do player.Position=origin+vector2(192,112+56*(t/.45)^2);wait();t=t+engine.DeltaTime end
        player.Position=origin+vector2(192,168);stage.play(player.Sprite,"fallPose")
    elseif selected==2 then
        for _,id in ipairs(actions)do stage.play(player.Sprite,id) end
    elseif selected==3 then
        if not player.Sprite:Has("roll") then
            local mode=getEnum("Celeste.PlayerSpriteMode","MadelineNoBackpack")
            player.DefaultSpriteMode=mode;player:ResetSprite(mode)
        end
        miniTextbox("SPL_ANIM_ROLL");player.Sprite:Play("roll",true,false)
        local t=0
        while t<.65 do player.Position=origin+vector2(112+t*80,168);wait();t=t+engine.DeltaTime end
        stage.play(player.Sprite,"rollGetUp");stage.play(player.Sprite,"downed")
        stage.play(player.Sprite,"skid")
    elseif selected==5 then
        miniTextbox("SPL_ANIM_CARRYTHEOWALK")
        player.Facing=getEnum("Celeste.Facings","Right");player.Sprite:Play("carryTheoWalk",true,false)
        local t=0
        while t<2.4 do player.Position=origin+vector2(136+t*28,168);wait();t=t+engine.DeltaTime end
        stage.play(player.Sprite,"carryTheoCollapse")
    elseif selected==4 then
        local partner=stage.npc(origin+vector2(170,168));partner.Sprite.Scale=vector2(-1,1)
        player.Facing=getEnum("Celeste.Facings","Right");player.Position=origin+vector2(160,168)
        if partner.Sprite:Has("hug") then partner.Sprite:Play("hug",true,false) end
        stage.play(player.Sprite,"hug");wait(1.0)
    end
end
function onEnd(room,skipped)stage.finish(room,skipped)end
