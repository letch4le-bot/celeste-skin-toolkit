local preview=loadCelesteAsset("Assets/SkinPracticeLab/common")
local enemy
function onTalk()
    preview.begin()
    say("SPL_SIGN_WALL")
end
function onEnd(room,skipped)
    preview.finish(room,skipped)
end
