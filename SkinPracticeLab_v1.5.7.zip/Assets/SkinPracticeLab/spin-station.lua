local preview=loadCelesteAsset("Assets/SkinPracticeLab/common")
local partner
function onTalk()
    miniTextbox("SPL_SPIN_START");preview.begin()
    local center=getRoomCoordinates()+vector2(160,132)
    player.Position=center;preview.play("spin",2.0)
    partner=celeste.BadelineDummy(center)
    partner.AutoAnimator.Enabled=false;partner.Wave.Active=false
    getLevel():Add(partner);wait()
    if player.Sprite:Has("spin") and partner.Sprite:Has("spin") then
        player.Facing=getEnum("Celeste.Facings","Right")
        partner.Sprite.Scale=vector2(1,partner.Sprite.Scale.Y)
        player.Sprite:Play("spin",true,false);partner.Sprite:Play("spin",true,false)
        player.Sprite.Rate=0;partner.Sprite.Rate=0
        local t=0
        while t<4 do
            local angle=math.pi/2-2*t
            local index=10+math.floor((angle%(2*math.pi))/(2*math.pi)*14)
            player.Sprite:SetAnimationFrame(index);partner.Sprite:SetAnimationFrame(index+7)
            local distance=math.min(1,t*4,(4-t)*4)
            local offset=vector2(math.sin(angle)*32*distance,math.cos(angle)*8*distance)
            player.Position=center-offset;partner.Position=center+offset
            wait();t=t+engine.DeltaTime
        end
        partner:RemoveSelf();partner=nil
        local t=0
        while t<2 do
            player.Position=center-vector2(0,t*18)
            player.Sprite:SetAnimationFrame(math.floor(t/0.08)%10)
            wait();t=t+engine.DeltaTime
        end
    else miniTextbox("SPL_MISSING") end
    player.Position=getRoomCoordinates()+vector2(160,168)
    preview.play("sitDown",2.0);preview.play("idle",0.5)
end
function onEnd(room,skipped)
    if partner then partner:RemoveSelf();partner=nil end
    preview.finish(room,skipped)
end
