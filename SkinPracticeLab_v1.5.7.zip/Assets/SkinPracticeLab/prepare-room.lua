-- Stop the enemy until the entrance sign has been read. This has no dialog.
function onBegin()
    local name=getLevel().Session.Level
    local enemy
    if name=="boss" then enemy=getFirstEntity("FinalBoss")
    elseif name=="chaser" then enemy=getFirstEntity("BadelineOldsite") end
    if enemy then enemy.Active=false;enemy.Collidable=false end
end
function onEnd(room,skipped)
    if player and not player.Dead then enableMovement() end
end
