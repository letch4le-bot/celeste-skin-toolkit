function onTalk()
 say("SPL_PORTRAIT_PHONE_TEST")
 enableMovement()
end
function onEnd(room,skipped) if player and not player.Dead then enableMovement() end end
