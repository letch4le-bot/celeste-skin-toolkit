function onTalk()
 say("SPL_PORTRAIT_LAYOUT_0")
 say("SPL_PORTRAIT_LAYOUT_1")
 say("SPL_PORTRAIT_LAYOUT_2")
 say("SPL_PORTRAIT_LAYOUT_3")
 enableMovement()
end
function onEnd(room,skipped) if player and not player.Dead then enableMovement() end end
