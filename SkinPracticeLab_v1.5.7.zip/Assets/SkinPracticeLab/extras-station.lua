local preview=loadCelesteAsset("Assets/SkinPracticeLab/common")
function onTalk()
    local chosen=choice("SPL_MODE_BACKPACK","SPL_MODE_NO_BACKPACK","SPL_SHADOW_0","SPL_SHADOW_1","SPL_SHADOW_2","SPL_EXTRA_INFO","SPL_STAY")
    if chosen==6 then say("SPL_EXTRA_INFO");enableMovement();return end
    if chosen==7 then enableMovement();return end
    if chosen>=3 then
        local shadow=getFirstEntity("PlayerPlayback")
        if shadow then
            shadow.Timeline=celeste.PlaybackData.Tutorials["SkinPracticeLab/preview"..tostring(chosen-3)]
            shadow:Restart()
        else miniTextbox("SPL_MISSING") end
        enableMovement();return
    end
    preview.begin()
    local mode=getEnum("Celeste.PlayerSpriteMode",chosen==1 and "Madeline" or "MadelineNoBackpack")
    player.DefaultSpriteMode=mode;player:ResetSprite(mode)
    player.Position=getRoomCoordinates()+vector2(80,148)
    preview.play("idle",1.5);preview.play("runFast",1.5)
    preview.play("jumpSlow",1.0);preview.play("climbup",1.0)
end
function onEnd(room,skipped) preview.finish(room,skipped) end
