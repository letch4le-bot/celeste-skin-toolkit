local preview=loadCelesteAsset("Assets/SkinPracticeLab/common")
function onTalk()
    miniTextbox("SPL_COLOR_START")
    preview.begin()
    -- Ground refills happen even while previewing. Keep the actor off the ground.
    player.Position=player.Position-vector2(0,32)
    for _,dashes in ipairs({2,1,0}) do
        player.Dashes=dashes
        preview.play("idle",2.0)
    end
end
function onEnd(room,skipped) preview.finish(room,skipped) end
