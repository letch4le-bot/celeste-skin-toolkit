local stage={actors={}}
local preview=loadCelesteAsset("Assets/SkinPracticeLab/common")
local visible,enemyState,active
function stage.begin(x)
    if player.Holding then miniTextbox("SPL_PUT_DOWN");enableMovement();return false end
    visible=player.Visible;active=true;preview.begin()
    player.Position=getRoomCoordinates()+vector2(x,168);player.ForceCameraUpdate=true
    local enemy=getFirstEntity("FinalBoss")
    if enemy then
        enemyState={actor=enemy,active=enemy.Active,visible=enemy.Visible,collidable=enemy.Collidable}
        enemy.Active=false;enemy.Visible=false;enemy.Collidable=false
        for _,name in ipairs({"FinalBossShot","FinalBossBeam"})do
            for _,projectile in ipairs(getAllEntities(name))do projectile:RemoveSelf() end
        end
    end
    return true
end
function stage.npc(position)
    local actor=celeste.BadelineDummy(position)
    celeste.GFX.SpriteBank:CreateOn(actor.Sprite,"badeline")
    actor.AutoAnimator.Enabled=false;actor.Wave.Active=false
    getLevel():Add(actor);stage.actors[#stage.actors+1]=actor
    return actor
end
function stage.boss(position)
    local Entity=require("#monocle.entity")
    local actor=Entity(position);actor.Collidable=false
    local sprite=celeste.GFX.SpriteBank:Create("badeline_boss")
    actor:Add(sprite);getLevel():Add(actor);stage.actors[#stage.actors+1]=actor
    return sprite
end
function stage.play(sprite,id)
    miniTextbox("SPL_ANIM_"..id:upper())
    if not sprite:Has(id) then miniTextbox("SPL_MISSING");return false end
    sprite.Rate=1;sprite:Play(id,true,false)
    local previous=0;local elapsed=0
    local count=sprite.CurrentAnimationTotalFrames
    repeat
        wait();elapsed=elapsed+engine.DeltaTime
        local frame=sprite.CurrentAnimationFrame
        if count>1 and (sprite.CurrentAnimationID~=id or not sprite.Animating or frame<previous) then break end
        previous=frame
    until elapsed>=(count<=1 and 1.2 or 10)
    sprite.Rate=0;wait(.65);sprite.Rate=1
    return true
end
function stage.pick(actions)
    local page=1
    local pageSize=#actions<=10 and #actions or 8
    while true do
        local first=(page-1)*pageSize+1;local last=math.min(#actions,first+pageSize-1)
        local options={"SPL_PLAY_GROUP"};local values={"all"}
        for i=first,last do options[#options+1]="SPL_ANIM_"..actions[i]:upper();values[#values+1]=actions[i] end
        if page>1 then options[#options+1]="SPL_PREVIOUS";values[#values+1]="previous" end
        if last<#actions then options[#options+1]="SPL_NEXT";values[#values+1]="next" end
        options[#options+1]="SPL_STAY";values[#values+1]="back"
        local selected=values[choice(options)]
        if selected=="previous" then page=page-1
        elseif selected=="next" then page=page+1
        elseif selected=="back" then return {}
        elseif selected=="all" then return actions
        else return {selected} end
    end
end
function stage.finish(room,skipped)
    for _,actor in ipairs(stage.actors)do actor:RemoveSelf() end
    stage.actors={}
    if enemyState and enemyState.actor.Scene==room then
        local e=enemyState.actor;e.Active=enemyState.active;e.Visible=enemyState.visible;e.Collidable=enemyState.collidable
    end
    enemyState=nil
    if active then
        if player and not player.Dead then player.Visible=visible end
        preview.finish(room,skipped)
    elseif player and not player.Dead then enableMovement() end
    active=false
end
return stage
