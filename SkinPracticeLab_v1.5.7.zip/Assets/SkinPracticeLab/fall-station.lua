local preview=loadCelesteAsset("Assets/SkinPracticeLab/common")
function onTalk()
    miniTextbox("SPL_FALL_START");preview.begin()
    player.Position=getRoomCoordinates()+vector2(216,72)
    player.ForceCameraUpdate=true
    preview.play("tentacle_grab",0.9);preview.play("tentacle_grabbed",1.8)
    preview.play("tentacle_pull",0.8);preview.play("tentacle_dangling",0.8)
    player.StateMachine.Locked=false
    player.StateMachine.State=celeste.Player.StReflectionFall
    local elapsed=0
    repeat wait();elapsed=elapsed+engine.DeltaTime
    until player.StateMachine.State~=celeste.Player.StReflectionFall or elapsed>12
end
function onEnd(room,skipped) preview.finish(room,skipped) end
