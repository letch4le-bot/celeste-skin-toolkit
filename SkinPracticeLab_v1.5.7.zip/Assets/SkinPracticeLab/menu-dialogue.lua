function onTalk()
 enableMovement()
 teleportTo(48,1192,"portraits","Respawn")
end
function onEnd(room,skipped) if player and not player.Dead then enableMovement() end end
