function onTalk()
    local room=getLevel()
    local pos=getRoomCoordinates()
    local name=room.Session.Level
    enableMovement()
    teleportTo(pos.X+48,pos.Y+168,name,"Respawn")
end
function onEnd(room, skipped) if player and not player.Dead then enableMovement() end end
