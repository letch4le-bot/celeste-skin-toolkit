function onTalk()
    local name=getLevel().Session.Level
    local x=192
    if name=="basic" then x=64 elseif name=="items" then x=128 elseif name=="portraits" then x=256 end
    player.StateMachine.Locked = false
    enableMovement()
    teleportTo(x,168,"hub","Respawn")
end
function onEnd(room, skipped)
    if player and not player.Dead then player.StateMachine.Locked=false;enableMovement() end
end
