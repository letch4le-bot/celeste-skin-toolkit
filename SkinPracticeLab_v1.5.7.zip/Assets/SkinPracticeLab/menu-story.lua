local rooms={
{"scenes",2608,680},
{"wake",48,680},{"boost",368,680},{"boss",688,680},{"fall",1008,640},{"spin",1328,680},{"death",1648,680},{"chaser",1968,680},{"extras",2288,680}
}
function onTalk()
    local chosen=choice("SPL_SCENES","SPL_WAKE","SPL_BOOST","SPL_BOSS","SPL_FALL","SPL_SPIN","SPL_DEATH","SPL_CHASER","SPL_EXTRAS","SPL_STAY")
    enableMovement()
    if chosen<=#rooms then
        local target=rooms[chosen]
        teleportTo(target[2],target[3],target[1],"Respawn")
    end
end
function onEnd(room,skipped) if player and not player.Dead then enableMovement() end end
