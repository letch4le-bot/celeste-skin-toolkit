function onTalk()
 local group=choice("SPL_PORTRAIT_FIRST","SPL_PORTRAIT_SECOND","SPL_PORTRAIT_LAYOUT","SPL_STAY")
 local keys
 if group==1 then keys={"NORMAL","PEACEFUL","ANGRY","DEADPAN","SAD","SADDER","UPSET"}
 elseif group==2 then keys={"SURPRISED","DISTRACTED","DETERMINED","DETERMINEDCLOSED","PANIC","TOGETHER","TOGETHERZOOM","SLEEP"}
 elseif group==3 then
  for i=0,3 do say("SPL_PORTRAIT_LAYOUT_"..i) end
  enableMovement();return
 else enableMovement();return end
 local options={};for i,key in ipairs(keys) do options[i]="SPL_PORTRAIT_CHOOSE_"..key end
 options[#options+1]="SPL_STAY"
 local selected=choice((table.unpack or unpack)(options))
 if selected>=1 and selected<=#keys then say("SPL_PORTRAIT_"..keys[selected]) end
 enableMovement()
end
function onEnd(room,skipped) if player and not player.Dead then enableMovement() end end
