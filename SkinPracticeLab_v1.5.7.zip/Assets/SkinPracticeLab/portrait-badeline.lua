local keys={"normal","upset","scoff","serious","serious_alt","angry","angryAlt","yell","worried","concerned","worriedAlt","sad","freakA","freakB","freakBAlt","freakC","freakC_cont","freakCAlt","sigh","simple_sigh"}
local function pick()
    local page=1
    while true do
        local first=(page-1)*8+1
        local last=math.min(#keys,first+7)
        local options={};local values={}
        for i=first,last do
            options[#options+1]="SPL_BAD_CHOOSE_"..keys[i]:upper()
            values[#values+1]=keys[i]
        end
        if page>1 then options[#options+1]="SPL_PREVIOUS";values[#values+1]="previous" end
        if last<#keys then options[#options+1]="SPL_NEXT";values[#values+1]="next" end
        options[#options+1]="SPL_STAY";values[#values+1]="back"
        local selected=values[choice((table.unpack or unpack)(options))]
        if selected=="previous" then page=page-1
        elseif selected=="next" then page=page+1
        elseif selected=="back" then return nil
        else return selected end
    end
end
function onTalk()
    local selected=choice("SPL_PORTRAIT_ALL","SPL_PORTRAIT_SELECT","SPL_PORTRAIT_LAYOUT","SPL_STAY")
    if selected==1 then
        for _,key in ipairs(keys) do say("SPL_BAD_"..key:upper()) end
    elseif selected==2 then
        local key=pick();if key then say("SPL_BAD_"..key:upper()) end
    elseif selected==3 then
        for i=0,3 do say("SPL_BAD_LAYOUT_"..i) end
    end
    enableMovement()
end
function onEnd(room,skipped) if player and not player.Dead then enableMovement() end end
