local stage=loadCelesteAsset("Assets/SkinPracticeLab/stage-common")
function onTalk()
    local selected=stage.pick({"idleA","idleB","idleC"})
    if #selected==0 then enableMovement();return end
    if not stage.begin(216) then return end
    for _,id in ipairs(selected)do stage.play(player.Sprite,id) end
end
function onEnd(room,skipped)stage.finish(room,skipped)end
