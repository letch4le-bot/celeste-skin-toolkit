function onTalk()
    enableMovement()
    teleportTo(368,424,"items","Respawn")
end
function onEnd(room, skipped) if player and not player.Dead then enableMovement() end end
