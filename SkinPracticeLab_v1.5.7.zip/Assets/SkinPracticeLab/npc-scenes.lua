local stage=loadCelesteAsset("Assets/SkinPracticeLab/stage-common")
local groups={{"spawn","laugh","angry","pretendDead","hug","boost","spin"},{"idle","lookUp","walk","push","runSlow","runFast","runStumble","flip","skid","slide"},{"tired","duck","sleep","faint","fainted"}}
function onTalk()
    local group=choice("SPL_NPC_UNIQUE","SPL_NPC_MOVE","SPL_NPC_STATES","SPL_STAY")
    if group==4 then enableMovement();return end
    local selected=stage.pick(groups[group]);if #selected==0 then enableMovement();return end
    if not stage.begin(352) then return end
    player.Visible=false
    local actor=stage.npc(getRoomCoordinates()+vector2(352,168))
    for _,id in ipairs(selected)do stage.play(actor.Sprite,id) end
end
function onEnd(room,skipped)stage.finish(room,skipped)end
