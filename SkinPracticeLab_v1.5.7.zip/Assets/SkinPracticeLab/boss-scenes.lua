local stage=loadCelesteAsset("Assets/SkinPracticeLab/stage-common")
local groups={{"scaredIdle","scaredTransition","calm","lookUp","lookingUp"},{"attack1Begin","attack1Loop","attack1Recoil"},{"attack2Begin","attack2Aim","attack2Lock","attack2Recoil"},{"idle","getHit","star","recoverHit"}}
function onTalk()
    local group=choice("SPL_BOSS_POST","SPL_BOSS_SHOT","SPL_BOSS_BEAM","SPL_BOSS_HIT","SPL_STAY")
    if group==5 then enableMovement();return end
    local selected=stage.pick(groups[group]);if #selected==0 then enableMovement();return end
    local x=getLevel().Session.Level=="boss" and 192 or 544
    if not stage.begin(x) then return end
    player.Visible=false
    local sprite=stage.boss(getRoomCoordinates()+vector2(x,152))
    for _,id in ipairs(selected)do stage.play(sprite,id) end
end
function onEnd(room,skipped)stage.finish(room,skipped)end
