function onTalk() say("SPL_SIGN_LOOKOUT");enableMovement() end
function onEnd(room,skipped) if player and not player.Dead then enableMovement() end end
