local preview=loadCelesteAsset("Assets/SkinPracticeLab/common")
local enemy
function onTalk()
    preview.begin()
    enemy=getFirstEntity("BadelineOldsite")
    if enemy then enemy.Active=false;enemy.Collidable=false end
    say("SPL_SIGN_CHASER")
end
function onEnd(room,skipped)
    preview.finish(room,skipped)
    if enemy and enemy.Scene==room then enemy.Active=true;enemy.Collidable=true end
end
