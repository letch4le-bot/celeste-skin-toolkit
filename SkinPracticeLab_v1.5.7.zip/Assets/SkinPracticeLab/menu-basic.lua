function onTalk()
    enableMovement()
    teleportTo(368,168,"basic","Respawn")
end
function onEnd(room, skipped) if player and not player.Dead then enableMovement() end end
