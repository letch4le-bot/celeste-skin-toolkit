"""Optional entity animation collections; definitions contain no game artwork."""
from xml.etree import ElementTree as ET
import copy

CATEGORIES=(
 {'role':'props_interactive','label':'交互实体','preference':'hidden-interactive','components':(
  ('bird','鸟','鸟'),('flyFeather','羽毛','羽毛'),('glider','水母','水母'),('theo_crystal','水晶 Theo','水晶 Theo'))},
 {'role':'props_bubbles','label':'泡泡','preference':'hidden-bubbles','components':(
  ('booster','绿泡泡','绿泡泡'),('boosterRed','红泡泡','红泡泡'))},
 {'role':'props_refills','label':'冲刺水晶','preference':'hidden-refills','components':(
  ('refill','单冲水晶／绿水晶','单冲水晶／绿水晶'),('refillTwo','双冲水晶／粉水晶','双冲水晶／粉水晶'))},
 {'role':'props_berries','label':'草莓','preference':'hidden-berries','components':(
  ('strawberry','草莓','草莓'),('ghostberry','草莓（已收集外观）','草莓'),
  ('goldberry','金草莓','金草莓'),('goldghostberry','金草莓（已收集外观）','金草莓'),
  ('moonberry','月莓','月莓'),('moonghostberry','月莓（已收集外观）','月莓'))},
)
ENTITY_BANKS=tuple(bank for category in CATEGORIES for bank,_,_ in category['components'])
CODE_BANKS={'refill':'objects/refill/','refillTwo':'objects/refillTwo/'}

def refill_node(name,path):
    # Celeste.Refill constructor: idle AddLoop(.1), separate flash Add(.05), centered outline Image.
    node=ET.Element(name,path=path,start='idle');ET.SubElement(node,'Center')
    ET.SubElement(node,'Loop',id='idle',path='idle',delay='.1')
    ET.SubElement(node,'Anim',id='flash',path='flash',delay='.05')
    ET.SubElement(node,'Loop',id='outline',path='outline',frames='0',delay='0')
    return node

def add_bank(session,source,node):
    file='__skinlab_entities__.xml';key=f'{source.id}|{file}|{node.tag}'
    session.banks[key]=dict(key=key,source=source.id,file=file,node=node,name=node.tag,entity_component=True)
    return key

def find_bank(session,source_id,name):
    return next((key for key,row in session.banks.items() if row['source']==source_id and row['name']==name),None)

def has_override(session,source,base):
    bank=session.resolve_bank(base)
    keys=list(source.keys())
    for anim in bank['animations'].values():
        for _,path in bank['paths']:
            prefix=path+anim.get('path','')
            if any(k.casefold().startswith(prefix.casefold()) and (not k[len(prefix):] or k[len(prefix):].isdigit()) for k in keys):return True
    return False

def register(session):
    native=session.sources.get('official')
    if native:
        for name,path in CODE_BANKS.items():
            if not find_bank(session,'official',name) and any(k.startswith(path+'idle') for k in native.keys()):add_bank(session,native,refill_node(name,path))
    for source in session.sources.values():
        for category in CATEGORIES:
            children=[]
            for name,label,group in category['components']:
                key=find_bank(session,source.id,name)
                if not key and source.id!='official' and native:
                    base=find_bank(session,'official',name)
                    if base and has_override(session,source,base):
                        native_bank=session.resolve_bank(base)
                        node=ET.Element('__entity_override_'+name,copy=name,path=native_bank['paths'][0][1])
                        key=add_bank(session,source,node)
                if key:
                    session.banks[key]['entity_component']=True
                    children.append(dict(prefix=name,label=label,group=group,bank=key))
            if children:
                key=f"{source.id}|__skinlab_entities__.xml|{category['role']}"
                session.banks[key]=dict(key=key,source=source.id,file='__skinlab_entities__.xml',node=ET.Element(category['role']),name=category['role'],entity_children=children)

def resolve_collection(session,row,stack):
    out=dict(paths=[],animations={},metadata={},origin=['absolute',0,0],start=None,is_player=False)
    for child in row['entity_children']:
        bank=session.resolve_bank(child['bank'],stack)
        for action,definition in bank['animations'].items():
            alias=child['prefix']+'/'+action
            out['animations'][alias]=dict(definition,_entity_bank=child['bank'],_entity_action=action,_entity_label=child['label'],_entity_group=child['group'])
        if out['start'] is None and bank['animations']:out['start']=child['prefix']+'/'+(bank['start'] or next(iter(bank['animations'])))
    return out

def catalog_data(session):
    groups={};labels={}
    for row in session.banks.values():
        if not row.get('entity_children'):continue
        role=row['name'];target=groups.setdefault(role,{})
        try:bank=session.resolve_bank(row['key'])
        except (KeyError,ValueError):continue
        for alias,definition in bank['animations'].items():
            items=target.setdefault(definition['_entity_group'],[])
            if alias not in items:items.append(alias)
            labels[alias]=definition['_entity_label']
    groups.update(lookout_groups(session))
    return dict(entity_categories=[{k:c[k] for k in ('role','label','preference')} for c in CATEGORIES],entity_groups=groups,entity_action_labels=labels)


def register_lookout(session):
    """Recognize global texture overrides as well as Helper-bound lookout XMLs."""
    native=find_bank(session,'official','lookout')
    if not native:return
    for source in session.sources.values():
        if source.id=='official' or find_bank(session,source.id,'lookout'):continue
        if has_override(session,source,native):
            node=ET.Element('__lookout_texture_override',copy='lookout',path=session.resolve_bank(native)['paths'][0][1])
            key=add_bank(session,source,node)
            session.banks[key]['entity_component']=False
            session.banks[key]['name']='lookout'


def lookout_groups(session):
    groups={}
    for key,row in session.banks.items():
        if row['name']!='lookout':continue
        try:animations=session.resolve_bank(key)['animations']
        except (KeyError,ValueError):continue
        target=groups.setdefault('lookout',{})
        for action in animations:
            name='望远镜 · Badeline' if action.startswith('badeline_') else '望远镜 · 玩家（无背包）' if action.startswith('nobackpack_') else '望远镜 · 玩家（有背包）'
            ids=target.setdefault(name,[])
            if action not in ids:ids.append(action)
    return groups


def attach_player_lookouts(session,banks,choices):
    """Keep each character's body and its corresponding lookout in one choice."""
    import hashlib
    from skinlab import simple_rows
    native=find_bank(session,'official','lookout')
    if not native:return
    for c in choices:
        if c['role']=='lookout':c['internal']=True
        if c['role'] not in ('player','player_no_backpack','badeline'):continue
        body=c['bank'];source=session.sources[c['source']]
        registrations=simple_rows(source.texts.get('SkinModHelperConfig.yaml',''))
        skin=c['id'].split('|')[1]
        config=next((r for r in registrations if r.get('SkinName')==skin),{})
        if c['role']=='player_no_backpack':config=next((r for r in registrations if r.get('SkinName')==skin+'_NB'),config)
        folder=config.get('OtherSprite_Path','').strip('/') or config.get('OtherSprite_ExPath','').strip('/')
        linked=next((k for k,r in session.banks.items() if r['source']==source.id and r['name']=='lookout' and folder and r['file']=='Graphics/'+folder+'/Sprites.xml'),None)
        if not linked:
            linked=next((k for k,r in session.banks.items() if r['source']==source.id and r['name']=='lookout' and r['file'] in ('Graphics/Sprites.xml','__skinlab_entities__.xml','Content/Graphics/Sprites.xml')),native)
        prefix={'player':'','player_no_backpack':'nobackpack_','badeline':'badeline_'}[c['role']]
        mappings={}
        for a in session.resolve_bank(linked)['animations']:
            if prefix:
                if not a.startswith(prefix):continue
                bare=a[len(prefix):]
            else:
                if a.startswith(('badeline_','nobackpack_')):continue
                bare=a
            mappings['lookout/'+bare]=a
        if not mappings:continue
        key=source.id+'|__skinlab_roles__.xml|'+hashlib.sha256(c['id'].encode()).hexdigest()[:16]
        session.banks[key]=dict(key=key,source=source.id,file='__skinlab_roles__.xml',name=c['role'],node=ET.Element(c['role']),entity_component=True,role_body=body,role_lookout=linked,lookout_actions=mappings)
        b=session.resolve_bank(key)
        banks.append(dict(key=key,name=c['role'],source=source.id,file='__skinlab_roles__.xml',label=source.label,kind=source.kind,actions=list(b['animations']),entity_component=True))
        c['bank']=key


def resolve_player_collection(session,row):
    out=copy.deepcopy(session.resolve_bank(row['role_body']))
    lookup=session.resolve_bank(row['role_lookout'])
    for alias,action in row['lookout_actions'].items():out['animations'][alias]=dict(lookup['animations'][action],id=alias)
    return out


def player_clip(session,key,action,dash,palette_key):
    row=session.banks[key];lookup=action in row['lookout_actions']
    actual=row['lookout_actions'][action] if lookup else action
    owner=row['role_lookout'] if lookup else row['role_body']
    palette=palette_key or (key if key in session.state.get('palettes',{}) else row['role_body'])
    result=copy.deepcopy(session.clip(owner,actual,dash,palette))
    result['action']=action
    if lookup:
        result['fallback_indices']=[i for i,f in enumerate(result['frames']) if f.get('source')!=row['source']]
        result['lookout']=True
    return result
