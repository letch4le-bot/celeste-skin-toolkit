"""Celeste Skin Lab: local, read-only sources; writes only an owned session directory.
No game/mod art is shipped with this tool. Python 3.10+ and Pillow are required.
"""
from __future__ import annotations
import argparse
import base64
import copy
import hashlib
import io
import json
import math
import re
import secrets
import socket
import struct
import threading
import time
import urllib.parse
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from xml.etree import ElementTree as ET
from PIL import Image
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from precision import COLLISION_REFERENCE, COLLISION_NOTE
from preview_palette import normalize_palette
import entities
import portraits
import particles

KIT = Path(__file__).resolve().parents[1]
VERSION = '1.11.1'
IMAGE_SUFFIXES = {'.png','.jpg','.jpeg','.webp','.bmp','.gif'}
OFFICIAL_BANKS = ('player', 'player_no_backpack', 'player_badeline', 'player_playback', 'badeline', 'badeline_boss', 'badelineBoost', 'lookout')
ROLE_LABELS = {'player':'玩家（有背包）','player_no_backpack':'玩家（无背包）','player_badeline':'追逐影子',
               'player_playback':'教程剪影','badeline':'剧情角色','badeline_boss':'Boss','badelineBoost':'抬升球','lookout':'望远镜'}
ROLE_LABELS.update({c['role']:c['label'] for c in entities.CATEGORIES})
ROLE_LABELS['portraits']='头像与表情'

def scalar(value):
    value = value.strip()
    if value.startswith('"'):
        try: return json.loads(value)
        except ValueError: return value.strip('"')
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1].replace("''", "'")
    return value.split(' #',1)[0].strip()

def simple_rows(text):
    """Read only scalar registration/list fields, never YAML tags or code."""
    rows, current = [], None
    for line in text.splitlines():
        match = re.match(r'^\s*(-\s+)?([A-Za-z_][\w]*):\s*(.*?)\s*$',line)
        if not match: continue
        if match[1]:
            current = {}; rows.append(current)
        if current is not None and match[3]: current[match[2]] = scalar(match[3])
    return rows
GROUPS = {
    '站立与移动': ['idle', 'idleA', 'idleB', 'idleC', 'lookUp', 'walk', 'runSlow', 'runFast', 'runWind', 'push', 'skid', 'runStumble', 'slide', 'flip'],
    '跳跃与墙面': ['jumpSlow', 'jumpFast', 'fallSlow', 'fallFast', 'fallPose', 'wallslide', 'climbup', 'climbPush', 'climbPull', 'wallBounce', 'climbLookBackStart', 'climbLookBack', 'climbLookBackLoop', 'edge', 'edgeBack'],
    '冲刺与果冻': ['dash', 'dashCrouch', 'dashSlide', 'dash_Side', 'dash_Up', 'dash_Down', 'dash_SideUp', 'dash_SideDown', 'dreamDashIn', 'dreamDashLoop', 'dreamDashOut'],
    '水中与羽毛': ['swimIdle', 'swimUp', 'swimDown', 'swimSide', 'startStarFly', 'starFly', 'starMorph', 'starMorphIdle'],
    '弹射与托举': ['bubble', 'launch', 'launchRecover', 'npcboost', 'boost', 'hug', 'spin'],
    '抓鸟与弹球（共用姿势）': ['jumpSlow', 'jumpFast', 'fallSlow', 'fallFast', 'fallPose', 'runSlow', 'runFast', 'idle'],
    '携带与抛接': ['idle_carry', 'runSlow_carry', 'jumpSlow_carry', 'fallSlow_carry', 'pickUp', 'throw', 'carryTheoWalk', 'carryTheoCollapse'],
    '剧情下坠与触手': ['fall', 'bigFall', 'bigFallRecover', 'tentacle_grab', 'tentacle_grabbed', 'tentacle_pull', 'tentacle_dangling', 'dangling'],
    '休息与死亡': ['tired', 'tiredStill', 'shaking', 'duck', 'downed', 'roll', 'rollGetUp', 'sleep', 'asleep', 'bagdown', 'wakeUp', 'halfWakeUp', 'deadside', 'deadup', 'deaddown', 'faint', 'fainted', 'sitDown', 'pretendDead'],
}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def safe_key(text):
    text = str(text).replace('\\', '/')
    p = PurePosixPath(text)
    if p.is_absolute() or '..' in p.parts or ':' in text or '\x00' in text:
        raise ValueError('拒绝越界资源路径')
    return str(p).lstrip('./')

def parse_xml(data):
    try:
        text = data.decode('utf-8-sig')
    except UnicodeDecodeError:
        raise ValueError('Sprites.xml 需要 UTF-8 编码；可在工作区副本转换')
    if len(data) > 8_000_000 or '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():
        raise ValueError('XML 太大或包含 DTD/实体，无法安全解析')
    root = ET.fromstring(data)
    if root.tag != 'Sprites':
        raise ValueError('XML 根元素必须是 Sprites')
    return root

def frame_sequence(text, available):
    if not text:
        return sorted(available)
    out = []
    for part in text.split(','):
        m = re.fullmatch(r'\s*(\d+)(?:\s*-\s*(\d+))?(?:\s*\*\s*(\d+))?\s*', part)
        if not m:
            raise ValueError('无法识别帧段: ' + part)
        a, b, repeat = int(m[1]), int(m[2] or m[1]), int(m[3] or 1)
        if b < a or b > 10000 or repeat > 10000 or len(out) + (b-a+1)*repeat > 20000:
            raise ValueError('帧段越界或过大')
        out.extend(list(range(a, b+1)) * repeat)
    return out

def binary_string(stream):
    count, shift = 0, 0
    for _ in range(5):
        b = stream.read(1)
        if not b:
            raise ValueError('Atlas 字符串截断')
        count |= (b[0] & 127) << shift
        if b[0] < 128:
            raw = stream.read(count)
            if len(raw) != count or count > 2_000_000:
                raise ValueError('Atlas 字符串长度异常')
            return raw.decode('utf-8')
        shift += 7
    raise ValueError('Atlas 字符串长度编码异常')

def data_image(data):
    if len(data) < 9:
        raise ValueError('Atlas .data 截断')
    w, h = struct.unpack_from('<ii', data)
    if not (0 < w <= 16384 and 0 < h <= 16384 and w*h <= 70_000_000):
        raise ValueError('Atlas 图片大小异常')
    alpha, i, o = data[8] == 1, 9, 0
    dest = bytearray(w*h*4)
    while o < len(dest):
        if i >= len(data):
            raise ValueError('Atlas RLE 截断')
        count = data[i]
        if alpha:
            if i+1 >= len(data):
                raise ValueError('Atlas RLE alpha 截断')
            a = data[i+1]
            if a:
                if i+4 >= len(data):
                    raise ValueError('Atlas RLE color 截断')
                color, i = bytes((data[i+4], data[i+3], data[i+2], a)), i+5
            else:
                color, i = b'\0\0\0\0', i+2
        else:
            if i+3 >= len(data):
                raise ValueError('Atlas RLE color 截断')
            color, i = bytes((data[i+3], data[i+2], data[i+1], 255)), i+4
        if not count or o+count*4 > len(dest):
            raise ValueError('Atlas RLE 长度异常')
        dest[o:o+count*4] = color*count
        o += count*4
    if i != len(data):
        raise ValueError('Atlas 数据有剩余字节，可能是不同打包格式')
    return Image.frombytes('RGBA', (w, h), bytes(dest))

def validate_pose_png(data, origin):
    if origin != [16,32] or any(type(v) is not int for v in origin):
        raise ValueError('单张图片固定使用原点 (16,32)')
    try:
        with Image.open(io.BytesIO(data)) as im:
            if im.format not in ('PNG','JPEG','WEBP','BMP','GIF') or im.size != (32,32) or getattr(im,'n_frames',1)!=1:
                raise ValueError('仅支持32×32的静态PNG、JPG/JPEG、WebP、BMP或GIF；不会自动缩放或裁切')
            im.load(); out=io.BytesIO(); im.convert('RGBA').save(out,format='PNG');return out.getvalue()
    except (OSError,Image.DecompressionBombError) as error:
        raise ValueError('图片无法读取，请选择32×32静态图片') from error


def validate_reference_image(data):
    try:
        with Image.open(io.BytesIO(data)) as im:
            if im.format not in ('PNG','JPEG','WEBP','BMP','GIF') or getattr(im,'n_frames',1)!=1:
                raise ValueError('请选择静态PNG、JPG/JPEG、WebP、BMP或GIF')
            if min(im.size)<1 or max(im.size)>8192 or im.width*im.height>16_000_000:
                raise ValueError('图片最多8192像素一边、1600万像素')
            im.load();out=io.BytesIO();im.convert('RGBA').save(out,format='PNG');return out.getvalue()
    except (OSError,Image.DecompressionBombError) as error:
        raise ValueError('图片无法读取') from error


class Source:
    def __init__(self, ident, label, kind, path):
        self.id, self.label, self.kind = ident, label, kind
        self.path = Path(path).expanduser().resolve()
        self.xmls, self.pngs, self.packed, self.hashes, self.sheets, self.texts = {}, {}, {}, {}, {}, {}

    def read(self, relative):
        path = (self.path / safe_key(relative)).resolve()
        if not path.is_relative_to(self.path):
            raise ValueError('源目录中的链接指向目录外')
        data = path.read_bytes()
        self.hashes[relative] = digest(data)
        return data

    def load(self):
        if self.path.suffix.lower() in IMAGE_SUFFIXES and self.kind!='official':
            origin = getattr(self, 'png_origin', None)
            data=self.path.read_bytes()
            data=validate_reference_image(data) if getattr(self,"png_mode","frame")=="reference" else validate_pose_png(data,origin)
            self.add_file('Graphics/Atlases/Gameplay/single/pose00.png',data)
            if getattr(self,'png_mode','frame')=='reference':
                with Image.open(io.BytesIO(data)) as ref:origin=[ref.width/2,ref.height]
            root=ET.Element('Sprites');node=ET.SubElement(root,'single_pose',path='single/')
            ET.SubElement(node,'Origin',x=str(origin[0]),y=str(origin[1]))
            ET.SubElement(node,'Loop',id='pose',path='pose',frames='0',delay='0')
            self.xmls['Graphics/Sprites.xml']=root
        elif self.kind == 'official':
            self.xmls['Content/Graphics/Sprites.xml'] = parse_xml(self.read('Content/Graphics/Sprites.xml'))
            for atlas,prefix in [('Gameplay',''),('Portraits','__portraits__/')]:
                if atlas=='Portraits':
                    file='Content/Graphics/Portraits.xml'
                    if not (self.path/file).is_file():continue
                    root=parse_xml(self.read(file))
                    for node in root:
                        if node.get('path') is not None:node.set('path',prefix+node.get('path'))
                    self.xmls[file]=root
                raw=self.read('Content/Graphics/Atlases/'+atlas+'.meta');f=io.BytesIO(raw)
                version=struct.unpack('<i',f.read(4))[0];binary_string(f);f.read(4)
                count=struct.unpack('<h',f.read(2))[0]
                if not 0<count<1000:raise ValueError(atlas+'.meta sheet 数异常')
                for _ in range(count):
                    sheet=safe_key(binary_string(f));entries=struct.unpack('<h',f.read(2))[0]
                    for _ in range(entries):
                        name=safe_key(binary_string(f));values=struct.unpack('<hhhhhhhh',f.read(16))
                        self.packed[prefix+name]=(sheet,values)
                self.format_version=version
        elif self.path.is_file():
            if not zipfile.is_zipfile(self.path):
                raise ValueError('参考文件必须是 ZIP 或目录')
            if self.path.stat().st_size > 750_000_000:
                raise ValueError('参考 ZIP 文件过大')
            self.hashes['archive'] = digest(self.path.read_bytes())
            with zipfile.ZipFile(self.path) as z:
                if len(z.infolist()) > 30000 or sum(x.file_size for x in z.infolist()) > 750_000_000:
                    raise ValueError('参考 ZIP 太大')
                for info in z.infolist():
                    key = safe_key(info.filename)
                    if info.is_dir():
                        continue
                    parts = PurePosixPath(key).parts
                    if 'Graphics' in parts: key = '/'.join(parts[parts.index('Graphics'):])
                    elif 'Dialog' in parts: key = '/'.join(parts[parts.index('Dialog'):])
                    elif parts[-1] == 'SkinModHelperConfig.yaml': key = parts[-1]
                    else: continue
                    if not (key.endswith(('.png','Sprites.xml','Portraits.xml','/HairConfig.yaml','/CharacterConfig.yaml')) or key in ('SkinModHelperConfig.yaml','Dialog/Simplified Chinese.txt','Dialog/English.txt')):
                        continue
                    if info.file_size > 32_000_000:
                        raise ValueError('参考资源文件太大')
                    self.add_file(key, z.read(info))
        else:
            if not self.path.is_dir():
                raise ValueError('参考路径不存在')
            graphics = self.path / 'Graphics'
            if not graphics.is_dir():
                raise ValueError('目录需要包含 Graphics；请选择 mod 根目录')
            for path in sorted(graphics.rglob('*')):
                if path.is_file() and (path.suffix.lower() == '.png' or path.name in ('Sprites.xml','Portraits.xml','HairConfig.yaml','CharacterConfig.yaml')):
                    if len(self.pngs) > 30000 or path.stat().st_size > 32_000_000:
                        raise ValueError('参考资源过大')
                    relative = path.relative_to(self.path).as_posix()
                    self.add_file(relative, self.read(relative))
            for relative in ('SkinModHelperConfig.yaml','Dialog/English.txt','Dialog/Simplified Chinese.txt'):
                if (self.path/relative).is_file(): self.add_file(relative,self.read(relative))
        return self

    def add_file(self, key, data):
        self.hashes[key] = digest(data)
        if key.endswith(('Sprites.xml','Portraits.xml')):
            root=parse_xml(data)
            if key.endswith('Portraits.xml'):
                for node in root:
                    if node.get('path') is not None:node.set('path','__portraits__/'+node.get('path'))
            self.xmls[key]=root
        elif key.startswith('Graphics/Atlases/Portraits/') and key.endswith('.png'):
            name='__portraits__/'+key[len('Graphics/Atlases/Portraits/'):-4]
            if name in self.pngs:raise ValueError('重复头像资源: '+name)
            self.pngs[name]=data
        elif key.startswith('Graphics/Atlases/Gameplay/') and key.endswith('.png'):
            name = key[len('Graphics/Atlases/Gameplay/'):-4]
            if name in self.pngs:
                raise ValueError('ZIP 中有重复 Gameplay 资源路径: ' + name)
            self.pngs[name] = data
        elif key.endswith(('.yaml','.txt')):
            self.texts[key] = data.decode('utf-8-sig')

    def keys(self):
        return self.packed.keys() if self.kind == 'official' else self.pngs.keys()

    def image(self, key):
        if self.kind != 'official':
            im = Image.open(io.BytesIO(self.pngs[key]))
            if im.width * im.height > 16_000_000:
                raise ValueError('参考 PNG 尺寸过大')
            return im.convert('RGBA')
        sheetname, (x,y,w,h,ox,oy,fw,fh) = self.packed[key]
        if min(w,h,fw,fh) <= 0 or fw*fh > 4_000_000:
            raise ValueError('Atlas 帧尺寸异常')
        rel = 'Content/Graphics/Atlases/' + sheetname + '.data'
        if (self.path / rel).is_file():
            if sheetname not in self.sheets:
                self.sheets[sheetname] = data_image(self.read(rel))
            crop = self.sheets[sheetname].crop((x,y,x+w,y+h))
        else:
            crop = data_image(self.read('Content/Graphics/Atlases/' + sheetname + '/' + key.removeprefix('__portraits__/') + '.data')).crop((x,y,x+w,y+h))
        result = Image.new('RGBA', (fw,fh))
        result.paste(crop, (-ox,-oy))
        return result

class Session:
    def __init__(self, directory):
        self.path = Path(directory).expanduser().resolve()
        marker = self.path / '.skinlab-session'
        if self.path.exists() and not marker.is_file() and any(self.path.iterdir()):
            raise ValueError('会话目录非空且不是本工具的目录；请指定新的独立工作目录')
        self.path.mkdir(parents=True, exist_ok=True)
        marker.write_text('Celeste Skin Lab owned workspace\n', encoding='utf-8')
        (self.path / 'assets').mkdir(exist_ok=True)
        (self.path / 'reports').mkdir(exist_ok=True)
        self.state_file = self.path / 'session.json'
        self.state = json.loads(self.state_file.read_text(encoding='utf-8')) if self.state_file.exists() else {'sources': [], 'reviews': {}, 'palettes': {}}
        self.state.setdefault('preferences', {})
        self.state.setdefault('baselines', [])
        self.state.setdefault('confirmations', [])
        self.sources, self.banks, self.errors, self.clips = {}, {}, [], {}
        self.token = secrets.token_hex(24)
        self.lock = threading.RLock()
        self.reload()

    def source_guard(self, path):
        p = Path(path).expanduser().resolve()
        if self.path == p or self.path.is_relative_to(p) or p.is_relative_to(self.path):
            raise ValueError('源目录与会话目录必须互相独立，避免写入游戏或参考素材')
        return p

    def save(self):
        tmp = self.state_file.with_suffix('.tmp')
        tmp.write_text(json.dumps(self.state, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(self.state_file)

    def add_source(self, path, label, kind, png_origin=None):
        if kind not in ('official', 'reference', 'candidate'):
            raise ValueError('来源类型错误')
        p = self.source_guard(path)
        ident = 'official' if kind == 'official' else digest((str(p)+kind).encode())[:12]
        # Validate before replacing existing configuration.
        preview=Source(ident, label[:100] or p.name, kind, p)
        preview.png_origin=png_origin
        preview.png_mode="frame"
        preview.load()
        item = {'id': ident, 'label': label[:100] or p.name, 'kind': kind, 'path': str(p)}
        if p.suffix.lower() in IMAGE_SUFFIXES:item['png_origin']=png_origin
        self.state['sources'] = [s for s in self.state['sources'] if s['id'] != ident] + [item]
        self.state['preferences'].update({'gamepath':str(p)} if kind=='official' else {'modpath':str(p),'modlabel':item['label'],'modkind':kind})
        self.save()
        self.reload()
        return ident

    def remove_source(self, ident):
        self.state['sources'] = [s for s in self.state['sources'] if s['id'] != ident]
        self.save(); self.reload()

    def add_pngs(self, rows, origin, mode="frame"):
        if mode not in ("frame","reference"):raise ValueError("导入用途错误")
        validate=lambda data,origin:validate_reference_image(data) if mode=="reference" else validate_pose_png(data,origin)
        """Import an explicit file drop/selection; validate the whole batch first."""
        if not isinstance(rows,list) or not 1<=len(rows)<=32:
            raise ValueError('每次请选择1至32张PNG')
        pending, total = [], 0
        for row in rows:
            if not isinstance(row,dict):raise ValueError('图片列表格式错误')
            if 'png' in row:
                name=str(row.get('name','image.png')).replace('\\','/').rsplit('/',1)[-1]
                encoded=row['png']
                if not isinstance(encoded,str) or not re.match(r'^data:(?:image/(?:png|jpeg|jpg|webp|bmp|gif)|application/octet-stream);base64,',encoded):
                    raise ValueError('请选择支持的静态图片')
                data=validate(base64.b64decode(encoded.split(',',1)[1],validate=True),origin)
                path=self.path/'imports'/(digest(data)+'.png')
                managed=True
            else:
                path=self.source_guard(row.get('path',''))
                if not path.is_file() or path.suffix.lower() not in IMAGE_SUFFIXES:raise ValueError('请选择PNG图片')
                name=path.name
                if path.stat().st_size>2_000_000:raise ValueError('单张拖入图片不能超过2MB')
                data=path.read_bytes();managed=False
            total+=len(data)
            if len(data)>2_000_000 or total>8_000_000:raise ValueError('单张图片最多2MB，一次最多8MB')
            validate(data,origin)
            ident=digest((str(path)+'reference').encode())[:12]
            item=dict(id=ident,label=name[:100],kind='reference',path=str(path),png_origin=list(origin or [16,32]),png_mode=mode)
            if managed:item['imported_png']=True
            pending.append((item,data if managed else None))
        for item,data in pending:
            if data is not None:
                directory=self.path/'imports';directory.mkdir(exist_ok=True)
                if not directory.resolve().is_relative_to(self.path):raise ValueError('导入目录不能指向会话外')
                (directory/Path(item['path']).name).write_bytes(data)
        identifiers={item['id'] for item,_ in pending}
        self.state['sources']=[s for s in self.state['sources'] if s['id'] not in identifiers]+[item for item,_ in pending]
        # Repeated identical images in one drop should create only one source.
        self.state['sources']=list({s['id']:s for s in self.state['sources']}.values())
        self.save();self.reload()
        return list(dict.fromkeys(item['id'] for item,_ in pending))

    def registered_source_path(self,item):
        if not item.get('imported_png'):return self.source_guard(item['path'])
        path=Path(item['path']).resolve()
        if not path.is_relative_to(self.path) or path.parent!=(self.path/'imports').resolve() or not re.fullmatch(r'[a-f0-9]{64}\.png',path.name):
            raise ValueError('导入图片的保存位置无效')
        if digest(path.read_bytes())!=path.stem:raise ValueError('导入图片已变化，请重新拖入')
        return path

    def save_preferences(self, values):
        allowed={'gamepath','modpath','modlabel','modkind','base','target','targetsource','refsource','action','group','dash','facing','zoom','speed','bg','refs','hair','anchor','bounds','overlay','follow','internal','inspect','collision','hitbox','hurtbox','grid','wall','overlaydirection','overlayalpha','keybindings','baseline','nativecolor','skincolor','cardorder','portrait-mode','nativecards'}
        allowed.update(c['preference'] for c in entities.CATEGORIES)
        allowed.add('hiddenactionspanel')
        if not isinstance(values,dict) or set(values)-allowed:
            raise ValueError('不支持的显示设置')
        for key,value in values.items():
            if key=='keybindings':
                keynames={'toggle','prev','next','copyToggle','copyPrev','copyNext','copyPlay','copyLoop'}
                if not isinstance(value,dict) or not {'toggle','prev','next'} <= set(value) or set(value)-keynames or not all(isinstance(row,list) and len(row)<=4 and all(isinstance(k,str) and re.fullmatch(r'(?:(?:Ctrl|Alt|Shift)\+)*(?:[A-Za-z][A-Za-z0-9]{0,30})',k) for k in row) for row in value.values()):
                    raise ValueError('快捷键格式无效')
                flat=[k for row in value.values() for k in row]
                if len(set(flat))!=len(flat):raise ValueError('快捷键重复')
            elif key=='cardorder':
                if not isinstance(value,list) or len(value)>32 or not all(isinstance(v,str) and len(v)<=2048 for v in value):raise ValueError('栏顺序无效')
            elif key in ('nativecolor','skincolor'):
                if not isinstance(value,str) or not re.fullmatch(r'#[a-fA-F0-9]{6}',value):raise ValueError('叠图颜色格式无效')
            elif key=='refs':
                if not isinstance(value,list) or len(value)>12 or not all(isinstance(v,str) and len(v)<=2048 for v in value):raise ValueError('参考列表过长')
            elif not isinstance(value,str) or len(value)>4096:raise ValueError('显示设置过长')
        self.state['preferences'].update(values)
        self.save()

    def reload(self):
        self.sources, self.banks, self.errors, self.clips = {}, {}, [], {}
        for item in sorted(self.state['sources'], key=lambda x:x['kind']!='official'):
            try:
                self.registered_source_path(item)
                source=Source(item['id'], item['label'], item['kind'], item['path'])
                source.png_origin=item.get('png_origin')
                source.png_mode=item.get('png_mode','frame')
                self.sources[item['id']] = source.load()
            except Exception as e:
                self.errors.append(item['label'] + ': ' + str(e))
        for source in self.sources.values():
            for file, root in source.xmls.items():
                for node in root:
                    if not isinstance(node.tag, str):
                        continue
                    if source.kind == 'official' and not file.endswith('Portraits.xml') and node.tag not in OFFICIAL_BANKS + entities.ENTITY_BANKS:
                        continue
                    key = f'{source.id}|{file}|{node.tag}'
                    self.banks[key] = {'key': key, 'source': source.id, 'file': file, 'node': node, 'name': node.tag}

        entities.register(self)
        entities.register_lookout(self)
        portraits.register(self)
        particles.register(self)

    def resolve_bank(self, key, stack=()):
        if key in stack or len(stack)>20:
            raise ValueError('SpriteBank copy 循环')
        row = self.banks[key]
        if row.get('role_body'):return entities.resolve_player_collection(self,row)
        if row.get('portrait_children'):return portraits.resolve(self,row)
        if row.get('death_player'):return particles.resolve(row)
        if row.get('entity_children'):return entities.resolve_collection(self,row,(*stack,key))
        node = row['node']; source = self.sources[row['source']]
        out = {'paths': [], 'animations': {}, 'metadata': {}, 'origin': ['absolute',0,0], 'start': None, 'is_player':node.tag.startswith('player')}
        parent = node.get('copy')
        if parent:
            parent_key = f"{row['source']}|{row['file']}|{parent}"
            if parent_key not in self.banks:
                parent_key = next((k for k,b in self.banks.items() if b['source']=='official' and b['name']==parent), None)
            if not parent_key:
                raise ValueError('找不到 copy 基础动画定义: '+parent+'；请先加载游戏目录')
            out = copy.deepcopy(self.resolve_bank(parent_key, (*stack, key)))
        prefix = safe_key(node.get('path', '')).rstrip('/')
        out['paths'].insert(0, (source.id, prefix + '/' if prefix else ''))
        out['start'] = node.get('start', out['start'])
        for child in node:
            if child.tag in ('Anim', 'Loop'):
                out['animations'][child.get('id')] = dict(child.attrib, kind=child.tag,
                    _definition=(source.id, prefix + '/' if prefix else ''), _delay_default=node.get('delay','0'))
            elif child.tag in ('Origin','Justify'):
                out['origin'] = ['absolute' if child.tag=='Origin' else 'justify', float(child.get('x',0)), float(child.get('y',0))]
            elif child.tag == 'Center':
                out['origin'] = ['justify',.5,.5]
            elif child.tag == 'Metadata':
                for frame in child:
                    out['metadata'][frame.get('path','')] = dict(frame.attrib)
        if 'runFast' in out['animations'] and 'jumpSlow' in out['animations']: out['is_player'] = True
        return out

    def frame_files(self, bank, group, expression=None, definition=None):
        paths = bank['paths'] if definition is None else ([bank['paths'][0]] if tuple(bank['paths'][0]) != tuple(definition) else []) + [definition]
        last_files = {}
        for source_id, path in paths:
            files = {}
            source = self.sources[source_id]
            combined = path+group
            prefix = safe_key(combined) + ('/' if combined.endswith('/') else '')
            for key in source.keys():
                if not key.casefold().startswith(prefix.casefold()):
                    continue
                suffix = key[len(prefix):]
                if suffix.isdigit():
                    files[int(suffix)] = (source_id,key)
                elif suffix == '':
                    files[0] = (source_id,key)
            required = frame_sequence(expression, files) if expression else [0]
            # Monocle selects an entire override prefix only if HasFrames succeeds.
            # Do not combine incomplete custom frames with the parent's body frames.
            if required and all(i in files for i in required):
                return files
            last_files = files
        return last_files

    def set_palette(self, key, mapping):
        self.resolve_bank(key)
        mapping = normalize_palette(mapping)
        self.state['palettes'][key] = mapping
        self.save()
        self.clips.clear()
        return mapping

    def cache_image(self, source_id, key, color_map=None, lut=None, tint=None, after_colored=False, mask_tint=None, mask_mode=3):
        im = self.sources[source_id].image(key)
        raw_sha256 = digest(struct.pack('<ii',im.width,im.height)+im.tobytes())
        source_pixels = list(im.get_flattened_data()) if color_map else None
        palette = {tuple(bytes.fromhex(a)):tuple(bytes.fromhex(b)) for a,b in (color_map or {}).items()}
        def mix_hair(p):
            rgb = p[:3]
            selected = rgb[0] == rgb[1] == rgb[2] if mask_mode > 2 else sum(rgb) == rgb[mask_mode]
            intensity = rgb[0] if mask_mode > 2 else sum(rgb)
            return (*(round(intensity*v/255) for v in mask_tint),p[3]) if selected else p
        if mask_tint and after_colored:
            im.putdata([mix_hair(p) for p in im.get_flattened_data()])
        if lut:
            if tint and after_colored:
                # Keep floating precision until the shader's 16-level lookup.
                input_tint = tint
                tint = None
            else:
                input_tint = None
            grading = self.sources[source_id].image(lut)
            if grading.size != (256,16): raise ValueError('目前支持 256×16 的 ColorGrading LUT')
            def grade(p):
                rgb = [p[i]*input_tint[i]/255 for i in range(3)] if input_tint else p[:3]
                r,g,b = (min(15,int(v*15/255+.5)) for v in rgb)
                coord = (r+b*16,g)
                return (*grading.getpixel(coord)[:3],p[3]) if p[3] else p
            im.putdata([grade(p) for p in im.get_flattened_data()])
        if mask_tint and not after_colored:
            im.putdata([mix_hair(p) for p in im.get_flattened_data()])
        if tint:
            im.putdata([(*(round(p[i]*tint[i]/255) for i in range(3)),p[3]) for p in im.get_flattened_data()])
        replaced_pixels = 0
        if source_pixels is not None:
            result = []
            for original, rendered in zip(source_pixels,im.get_flattened_data()):
                if original[3] and original[:3] in palette:
                    result.append((*palette[original[:3]],original[3]))
                    replaced_pixels += 1
                else:
                    result.append(rendered)
            im.putdata(result)
        buf = io.BytesIO(); im.save(buf, format='PNG')
        data = buf.getvalue(); ident = digest(data); dest = self.path/'assets'/(ident+'.png')
        if not dest.exists():
            dest.write_bytes(data)
        return {'url':'/assets/'+ident+'.png','size':list(im.size),'alpha_bounds':list(im.getbbox()) if im.getbbox() else None,
                'source':source_id,'texture':key,'sha256':ident,'raw_sha256':raw_sha256,'preview_replaced_pixels':replaced_pixels}

    def clip(self, key, action, dash='1', palette_key=None, portrait_mode='talk'):
        if self.banks[key].get('role_body'):return entities.player_clip(self,key,action,dash,palette_key)
        if self.banks[key].get('portrait_children'):return portraits.clip(self,key,action,portrait_mode)
        if self.banks[key].get('death_player'):return particles.clip(self,key,action,dash)
        palette_key = palette_key or key
        cache_key = (key,action,str(dash),palette_key)
        if cache_key in self.clips:
            return self.clips[cache_key]
        bank = self.resolve_bank(key)
        if action not in bank['animations']:
            return {'missing_action':action, 'frames':[], 'delay':0, 'kind':'Missing'}
        anim = bank['animations'][action]
        if anim.get('_entity_bank'):
            result=copy.deepcopy(self.clip(anim['_entity_bank'],anim['_entity_action'],dash,palette_key=palette_key))
            result.update(action=action,entity_label=anim['_entity_label'],entity_group=anim['_entity_group'])
            if result.get('goto'):
                prefix=action.split('/',1)[0]+'/'
                result['goto']=','.join(prefix+v.strip() for v in result['goto'].split(','))
            self.clips[cache_key]=result
            return result
        group = anim.get('path','')
        available = self.frame_files(bank, group, anim.get('frames'), anim.get('_definition'))
        sequence = frame_sequence(anim.get('frames'), available)
        if not anim.get('frames') and sequence:
            # A numbered hole must be reported instead of silently skipping it.
            sequence = list(range(sequence[-1]+1))
        preview_setting = self.state.get('palettes',{}).get(palette_key,{}).get(str(dash),'keep')
        map_colors = preview_setting if isinstance(preview_setting,dict) else {}
        root_source, root_path = bank['paths'][0]
        source = self.sources[root_source]
        hair_config = source.texts.get('Graphics/Atlases/Gameplay/'+root_path+'skinConfig/HairConfig.yaml','')
        character_config = source.texts.get('Graphics/Atlases/Gameplay/'+root_path+'skinConfig/CharacterConfig.yaml','')
        hair_color = [(68,183,255),(172,50,50),(255,109,239)][min(2,max(0,int(dash)))]
        for row in simple_rows(hair_config):
            if str(row.get('Dashes'))==str(dash) and re.fullmatch('[0-9A-Fa-f]{6}',str(row.get('Color',''))):
                hair_color = tuple(bytes.fromhex(row['Color']))
        if self.banks[key]['name'] in ('badeline','player_badeline') and root_source=='official':hair_color=(155,63,181)
        lut = root_path+'ColorGrading/dash'+str(dash)
        fixed_lut = re.search(r'^ColorGrade_Path:\s*([^\r\n]+)',character_config,re.M)
        after_colored = bool(re.search(r'^ColorGradingAfterColored:\s*true\s*$',character_config,re.M|re.I))
        if fixed_lut: lut = safe_key(str(scalar(fixed_lut.group(1))))
        if lut not in source.keys(): lut = None
        is_playback = self.banks[key]['name']=='player_playback' or bool(re.search(r'^SilhouetteMode:\s*true\s*$',character_config,re.M|re.I))
        if is_playback and fixed_lut and after_colored and str(dash)=='0':
            hair_color = (68,174,246)  # Native tutorial recording's spent-dash tint.
        tint = hair_color if is_playback else None
        mask_tint = hair_color if re.search(r'^TintMaskWithHair:\s*true\s*$',character_config,re.M|re.I) else None
        mask_match = re.search(r'^MaskMode:\s*(Red|Green|Blue|Grayscale|[0-3])\s*$',character_config,re.M|re.I)
        mask_value = mask_match.group(1).lower() if mask_match else 'red'
        mask_mode = {'red':0,'green':1,'blue':2,'grayscale':3}.get(mask_value,int(mask_value) if mask_value.isdigit() else 0)
        effects = {'lut':lut,'tint':tint,'hair_color':hair_color}
        if mask_tint: effects.update(mask_tint=mask_tint,mask_mode=mask_mode)
        if after_colored: effects['after_colored'] = True
        if lut: effects['lut_sha256']=digest(source.pngs[lut]) if lut in source.pngs else None
        frames, missing, fallbacks = [], [], []
        hair_data = bank['metadata'].get(group, {}).get('hair','').split('|')
        bangs = self.frame_files(bank, 'bangs')
        if not bangs and self.banks[key]['name']=='badeline':
            native_player=next((k for k,b in self.banks.items() if b['source']=='official' and b['name']=='player'),None)
            if native_player:bangs=self.frame_files(self.resolve_bank(native_player),'bangs')
        for index in sequence:
            if index not in available:
                missing.append(index); frames.append({'index':index,'missing':True}); continue
            sid, texture = available[index]
            frame = self.cache_image(sid, texture, map_colors, lut if sid==root_source else None,tint,after_colored,mask_tint,mask_mode)
            frame['index'] = index
            if sid != self.banks[key]['source']:
                fallbacks.append(index)
            origin = bank['origin']
            frame['origin'] = [origin[1]*frame['size'][0], origin[2]*frame['size'][1]] if origin[0]=='justify' else origin[1:]
            token = hair_data[min(index, len(hair_data)-1)].strip()
            frame['hair_metadata'] = token
            match = re.fullmatch(r'(-?\d+),\s*(-?\d+)(?::(\d+))?', token)
            # Explicitly a static head-hair anchor preview; never pretends to render the trailing chain.
            if match and (bank['is_player'] or self.banks[key]['name']=='badeline'):
                hi = int(match[3] or 0)
                if hi in bangs:
                    hs, hk = bangs[hi]
                    frame['bangs'] = self.cache_image(hs,hk)
                    frame['bangs_offset'] = [int(match[1])-5, int(match[2])-14]
                    frame['bangs_bounds'] = [*frame['bangs_offset'],*frame['bangs']['size']]
            frames.append(frame)
        result = {'action':action,'path':group,'sequence':sequence,'frames_expression':anim.get('frames'),
                  'kind':anim['kind'],'delay':float(anim.get('delay',anim.get('_delay_default',0))),'goto':anim.get('goto'),
                  'origin_definition':bank['origin'],'metadata':bank['metadata'].get(group,{}),
                  'frames':frames,'missing_frames':missing,'fallback_indices':sorted(set(fallbacks)),
                  'preview_palette':map_colors,'preview_matched_pixels':sum(f.get('preview_replaced_pixels',0) for f in frames),'preview_effects':effects,'procedural_effects_rendered':False}
        if not math.isfinite(result['delay']) or result['delay'] < 0:
            raise ValueError('delay 必须为非负有限数值')
        signature = {k:result[k] for k in ('sequence','kind','delay','goto','origin_definition','metadata')}
        signature['frames'] = [(f.get('index'),f.get('raw_sha256'),f.get('size'),f.get('origin'),f.get('hair_metadata'),f.get('bangs',{}).get('raw_sha256')) for f in frames]
        signature['palettes'] = self.state.get('palettes',{}).get(palette_key,{})
        signature['preview_effects'] = effects
        result['signature'] = digest(json.dumps(signature,sort_keys=True).encode())
        result['unique_image_count']=len({(f.get('raw_sha256'),f.get('bangs',{}).get('raw_sha256'),tuple(f.get('bangs_offset',[]))) for f in frames if not f.get('missing')})
        self.clips[cache_key] = result
        return result

    def catalog(self):
        for k in list(self.banks):
            if self.banks[k].get('role_body'):del self.banks[k]
        banks = []
        for key, row in self.banks.items():
            source = self.sources[row['source']]
            try:
                bank = self.resolve_bank(key)
                banks.append({'key':key,'name':row['name'],'source':row['source'],'file':row['file'],
                              'label':source.label,'kind':source.kind,'actions':list(bank['animations']),'entity_component':row.get('entity_component',False)})
            except Exception as e:
                banks.append({'key':key,'name':row['name'],'source':row['source'],'file':row['file'],'label':source.label,'kind':source.kind,'actions':[],'error':str(e)})
        public_choices=self.choices(banks)+particles.choices(self)
        entities.attach_player_lookouts(self,banks,public_choices)
        media=entities.catalog_data(self)
        media['entity_groups'].update(portraits.groups(self))
        media['entity_groups']['death_particle']={'死亡粒子':['scatter','particle']}
        return {**media,'version':VERSION,'collision_reference':COLLISION_REFERENCE,'collision_note':COLLISION_NOTE,'banks':banks,'choices':public_choices,'sources':self.state['sources'],'errors':self.errors,'groups':GROUPS,'role_groups':{'badeline':'Badeline · 剧情','badeline_boss':'Badeline · Boss','badelineBoost':'Badeline · 抬升球'},
                'reviews':self.state['reviews'],'baselines':self.state['baselines'],'confirmations':self.state['confirmations'],'palettes':self.state.get('palettes',{}),'preferences':self.state['preferences'],'session':str(self.path),'token':self.token}

    def save_baseline(self,payload):
        """Freeze the web preview, independent of the mutable source. This is not approval."""
        data=payload.get('png','')
        if not isinstance(data,str) or not data.startswith('data:image/png;base64,'):
            raise ValueError('需要PNG预览快照')
        raw=base64.b64decode(data.split(',',1)[1],validate=True)
        with Image.open(io.BytesIO(raw)) as im:
            if im.format!='PNG' or im.width*im.height>4_000_000:raise ValueError('基准图过大或格式错误')
            rgba=im.convert('RGBA');rgba.load()
        origin=payload.get('origin')
        if not isinstance(origin,list) or len(origin)!=2 or any(type(v) is not int or abs(v)>4096 for v in origin):
            raise ValueError('基准原点无效')
        out=io.BytesIO();rgba.save(out,format='PNG');png=out.getvalue();image_hash=digest(png)
        ident=digest(png+json.dumps(origin).encode()+secrets.token_bytes(8))
        path=self.path/'assets'/(image_hash+'.png')
        if not path.exists():path.write_bytes(png)
        row={'id':ident,'url':'/assets/'+image_hash+'.png','origin':origin,'size':list(rgba.size),
             'label':str(payload.get('label','基准'))[:150],'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
             'note':'保存的对照画面'}
        if not any(r['id']==ident for r in self.state['baselines']):self.state['baselines'].append(row)
        self.state['preferences']['baseline']=ident;self.save()
        return row

    def save_confirmation(self,payload):
        scope=payload.get('scope');visual=payload.get('visual');reason=str(payload.get('reason','')).strip()
        if scope not in ('pose','animation','gameplay') or visual not in ('approved','changes_needed','unreviewed'):
            raise ValueError('确认范围或状态无效')
        if scope=='gameplay' and not reason:raise ValueError('实机记录需要填写游戏版本、场景及实际观察；工具不会代测')
        clip=self.clip(payload['target'],payload['action'],payload.get('dash','1'))
        position=payload.get('position',0)
        if type(position) is not int or not 0<=position<len(clip['frames']) or clip['frames'][position].get('missing') or clip.get('missing_frames'):
            raise ValueError('缺少有效画面，不能记录确认')
        row={'target':payload['target'],'action':payload['action'],'dash':str(payload.get('dash','1')),
             'position':position,'scope':scope,'visual':visual,'reason':reason[:4096],
             'signature':clip['signature'],'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
             'note':'人工记录；签名包含整组播放数据，内容变化后需重查。实机项不是自动检测结果。'}
        self.state['confirmations'].append(row);self.save();return row

    def choices(self, banks):
        choices=[]
        for source in self.sources.values():
            rows=[b for b in banks if b['source']==source.id and not b.get('entity_component')]
            if source.path.suffix.lower() in IMAGE_SUFFIXES:
                for b in rows:
                    choices.append(dict(id=b['key'],bank=b['key'],source=source.id,label='固定参考图',role='pose',internal=False,size=list(source.image('single/pose00').size)))
                continue
            if source.kind=='official':
                for b in rows:
                    choices.append(dict(id=b['key'],bank=b['key'],source=source.id,label=ROLE_LABELS.get(b['name'],b['name']),role=b['name'],internal=False))
                continue
            registrations=simple_rows(source.texts.get('SkinModHelperConfig.yaml',''))
            dialog={}
            for name in ('Dialog/English.txt','Dialog/Simplified Chinese.txt'):
                for line in source.texts.get(name,'').splitlines():
                    if '=' in line:
                        k,v=line.split('=',1);dialog[k.strip()]=v.strip()
            used=set()
            for config in registrations:
                skin=config.get('SkinName','')
                title=dialog.get(config.get('SkinDialogKey',skin),skin)
                for ending in (' NPC',' 剪影',' 教程',' silhouette',' tutorial'):
                    if title.endswith(ending):title=title[:-len(ending)]
                roles=[]
                if str(config.get('Player_List','')).lower()=='true':roles.append('player')
                if str(config.get('Silhouette_List','')).lower()=='true':roles.append('player_playback')
                for role in roles:
                    b=next((b for b in rows if b['file']=='Graphics/Sprites.xml' and b['name']==config.get('Character_ID')),None)
                    if b:
                        label=title+' · '+('玩家' if role=='player' else ROLE_LABELS[role])
                        choices.append(dict(id=source.id+'|'+skin+'|'+role,bank=b['key'],source=source.id,label=label,role=role,internal=False));used.add(b['key'])
                        if role=='player':
                            nb=next((c for c in registrations if c.get('SkinName')==skin+'_NB'),None)
                            if nb and nb.get('Character_ID')!=config.get('Character_ID'):
                                other=next((b for b in rows if b['file']=='Graphics/Sprites.xml' and b['name']==nb.get('Character_ID')),None)
                                if other:
                                    choices[-1]['label']=title+' · 玩家（有背包）'
                                    choices.append(dict(id=source.id+'|'+skin+'|player_no_backpack',bank=other['key'],source=source.id,label=title+' · 玩家（无背包）',role='player_no_backpack',internal=False));used.add(other['key'])
                player_path=config.get('OtherSprite_Path','').strip('/')
                if player_path and str(config.get('Player_List','')).lower()=='true':
                    file='Graphics/'+player_path+'/Sprites.xml'
                    for b in rows:
                        if b['file']==file and b['name']=='lookout':
                            choices.append(dict(id=source.id+'|'+skin+'|lookout',bank=b['key'],source=source.id,label=title+' · 望远镜',role='lookout',internal=False));used.add(b['key'])
                path=config.get('OtherSprite_ExPath','').strip('/')
                if path and str(config.get('General_List','true')).lower()=='true':
                    file='Graphics/'+path+'/Sprites.xml'
                    for b in rows:
                        if b['file']==file:
                            role=b['name'];label=title+' · '+ROLE_LABELS.get(role,role)
                            choices.append(dict(id=source.id+'|'+skin+'|'+role,bank=b['key'],source=source.id,label=label,role=role,internal=role not in ROLE_LABELS));used.add(b['key'])
            for b in rows:
                if b['key'] in used:continue
                playerlike='runFast' in b['actions'] and 'jumpSlow' in b['actions']
                inferred=b['name'] if b['name'] in ROLE_LABELS else 'player' if playerlike else 'other'
                label=ROLE_LABELS.get(b['name'],b['name']+' · 玩家' if playerlike else b['name'])
                choices.append(dict(id=b['key'],bank=b['key'],source=source.id,label=label,role=inferred,internal=(bool(registrations) or inferred=='other') and not inferred.startswith('props_') and inferred not in ('lookout','portraits')))
        return choices

    def audit(self, base, target, mapping=None):
        mapping = mapping or {}
        base_bank, target_bank = self.resolve_bank(base), self.resolve_bank(target)
        rows = []
        for action in base_bank['animations']:
            if action in ('idleA','idleB','idleC'):continue
            other_action = mapping.get(action,action)
            a, b = self.clip(base,action), self.clip(target,other_action)
            differences = []
            for field in ('sequence','delay','kind','goto','origin_definition'):
                if a.get(field) != b.get(field):
                    differences.append(field)
            if b.get('missing_action') or not b['frames']:
                differences.append('missing_action_or_empty')
            if b.get('missing_frames'):
                differences.append('missing_frames')
            sizes_a = [f.get('size') for f in a['frames']]
            sizes_b = [f.get('size') for f in b['frames']]
            size_changed = sizes_a != sizes_b if a.get('sequence')==b.get('sequence') else {tuple(s) for s in sizes_a if s} != {tuple(s) for s in sizes_b if s}
            if size_changed:
                differences.append('canvas_sizes')
            review_key = base+'\n'+target+'\n'+action
            review = self.state['reviews'].get(review_key, {})
            current_review = review.get('base_signature')==a.get('signature') and review.get('target_signature')==b.get('signature')
            hard = any(x in differences for x in ('missing_action_or_empty','missing_frames'))
            static_pass = not hard and (not differences or (current_review and review.get('deviation_approved') and bool(review.get('reason','').strip())))
            rows.append({'action':action,'target_action':other_action,'differences':differences,
                         'missing_frames':b.get('missing_frames',[]),'fallback_indices':b.get('fallback_indices',[]),
                         'static_contract_pass':static_pass,'visual_review':review.get('visual','unreviewed') if current_review else ('stale' if review else 'unreviewed'),
                         'approval_matches_current_content':current_review,
                         'reason':review.get('reason',''),'deviation_approved':review.get('deviation_approved',False),
                         'resource_status':'missing' if hard else 'complete',
                         'playback_differences':[d for d in differences if d not in ('missing_action_or_empty','missing_frames')],
                         'playback_status':'unavailable' if hard else 'same' if not differences else 'accepted_design' if static_pass else 'needs_confirmation'})
        extra_actions = sorted(set(target_bank['animations'])-set(base_bank['animations'])-{'idleA','idleB','idleC'})
        extra_reviews = []
        for action in extra_actions:
            clip = self.clip(target,action)
            review = self.state['reviews'].get(base+'\n'+target+'\n'+action,{})
            current = review.get('base_signature') is None and review.get('target_signature')==clip.get('signature')
            extra_reviews.append({'action':action,'visual_review':review.get('visual','unreviewed') if current else ('stale' if review else 'unreviewed'),
                                  'semantic_reference':review.get('reason',''),'missing_frames':clip.get('missing_frames',[]),'empty_animation':not bool(clip['frames'])})
        report = {'version':VERSION,'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
                  'excluded_custom_actions':['idleA','idleB','idleC'],'base':base,'target':target,'rows':rows,'extra_actions':extra_actions,'extra_visual_reviews':extra_reviews,
                  'static_pass':all(r['static_contract_pass'] for r in rows) and all(not r['empty_animation'] and not r['missing_frames'] for r in extra_reviews),
                  'visual_all_approved':all(r['visual_review']=='approved' for r in rows) and all(r['visual_review']=='approved' and bool(r['semantic_reference'].strip()) and not r['missing_frames'] and not r['empty_animation'] for r in extra_reviews),
                  'gameplay_tested':False,'procedural_effects_rendered':False,
                  'resource_pass':all(r['resource_status']=='complete' for r in rows) and all(not r['empty_animation'] and not r['missing_frames'] for r in extra_reviews),
                  'playback_needs_confirmation':[r['action'] for r in rows if r['playback_status']=='needs_confirmation'],
                  'playback_accepted_design':[r['action'] for r in rows if r['playback_status']=='accepted_design'],
                  'manual_pixel_checks':[{'action':a,'parts':['脚底'] if a.startswith('idle') else ['手','脚','下巴','头顶'],'status':'manual_only'} for a in ('idle','wallslide','climbup','climbPush','climbPull') if base_bank['is_player'] and target_bank['is_player'] and a in base_bank['animations'] and a in target_bank['animations']],
                  'collision_reference':COLLISION_REFERENCE,'collision_note':COLLISION_NOTE,
                  'note':'自动检查缺图、帧序、播放间隔、后续动作、原点与画布尺寸；idleA/B/C为自定义待机，不作原版对照。像素造型由人工逐帧核对。'}
        path = self.path/'reports'/('audit-'+digest((base+target).encode())[:12]+'.json')
        path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        report['saved_to'] = str(path)
        fingerprint = {s.label:dict(s.hashes) for s in self.sources.values()}
        (self.path/'reports'/'source-fingerprints.json').write_text(json.dumps(fingerprint,ensure_ascii=False,indent=2),encoding='utf-8')
        return report

def serve(session, port):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass

        def response(self, data, status=200, mime='application/json; charset=utf-8'):
            if isinstance(data, (dict,list)):
                data = json.dumps(data,ensure_ascii=False).encode('utf-8')
            if isinstance(data,str):
                data = data.encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type',mime)
            self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' blob:; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'")
            self.end_headers(); self.wfile.write(data)

        def guard_host(self):
            return self.headers.get('Host') in (f'127.0.0.1:{port}',f'localhost:{port}')

        def do_GET(self):
            if not self.guard_host():
                return self.response({'error':'Host rejected'},403)
            url = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(url.query)
            try:
                with session.lock:
                    if url.path == '/api/catalog':
                        return self.response(session.catalog())
                    if url.path == '/api/clip':
                        return self.response(session.clip(q['bank'][0],q['action'][0],q.get('dash',['1'])[0],portrait_mode=q.get('portrait_mode',['talk'])[0]))
                    if re.fullmatch(r'/assets/[a-f0-9]{64}\.png',url.path):
                        return self.response((session.path/url.path[1:]).read_bytes(),mime='image/png')
                    if url.path in ('/','/index.html','/app.js','/precision.js','/workflow.js','/workflow-core.js','/preview-core.js','/png-drop.js','/media.js','/style.css'):
                        name = 'index.html' if url.path=='/' else url.path[1:]
                        mime = 'text/html; charset=utf-8' if name.endswith('.html') else 'text/css; charset=utf-8' if name.endswith('.css') else 'text/javascript; charset=utf-8'
                        return self.response((KIT/'web'/name).read_bytes(),mime=mime)
                    if url.path == '/guide':
                        return self.response((KIT/'使用说明.html').read_bytes(),mime='text/html; charset=utf-8')
                    if url.path == '/docs/action-reference.json':
                        return self.response((KIT/'docs/action-reference.json').read_bytes(),mime='application/json; charset=utf-8')
                    if url.path.startswith('/docs/'):
                        name=safe_key(urllib.parse.unquote(url.path[len('/docs/'):]))
                        if re.fullmatch(r'images/[A-Za-z0-9_-]+\.png',name) and (KIT/'docs'/name).is_file():
                            return self.response((KIT/'docs'/name).read_bytes(),mime='image/png')
                        if '/' not in name and name.endswith('.md') and (KIT/'docs'/name).is_file():
                            return self.response((KIT/'docs'/name).read_bytes(),mime='text/plain; charset=utf-8')
                    if url.path == '/tool-guide.docx':
                        return self.response((KIT/'docs/工具操作图解.docx').read_bytes(),mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
                    if url.path == '/api/report' and 'base' in q and 'target' in q:
                        # Export needs POST; GET is deliberately read-only.
                        return self.response({'error':'Use POST /api/audit'},405)
                self.response({'error':'Not found'},404)
            except Exception as e:
                self.response({'error':str(e)},400)

        def do_POST(self):
            if not self.guard_host() or self.headers.get('X-Skinlab-Token')!=session.token:
                return self.response({'error':'Local request rejected'},403)
            if self.headers.get('Content-Type','').split(';')[0]!='application/json':
                return self.response({'error':'JSON required'},415)
            try:
                size = int(self.headers.get('Content-Length',0))
                if not 0 < size < (12_000_000 if self.path=='/api/pngs' else 1_000_000):
                    raise ValueError('Request too large')
                payload = json.loads(self.rfile.read(size))
                with session.lock:
                    if self.path == '/api/pngs':
                        return self.response({'ids':session.add_pngs(payload['files'],payload.get('origin'),payload.get('mode','frame'))})
                    if self.path == '/api/source':
                        ident = session.add_source(payload['path'],payload.get('label',''),payload['kind'],payload.get('png_origin'))
                        return self.response({'id':ident,'catalog':session.catalog()})
                    if self.path == '/api/baseline':
                        return self.response(session.save_baseline(payload))
                    if self.path == '/api/confirmation':
                        return self.response(session.save_confirmation(payload))
                    if self.path == '/api/source/remove':
                        session.remove_source(payload['id']); return self.response(session.catalog())
                    if self.path == '/api/reload':
                        session.reload(); return self.response(session.catalog())
                    if self.path == '/api/preferences':
                        session.save_preferences(payload);return self.response({'saved':True})
                    if self.path == '/api/review':
                        key = payload['base']+'\n'+payload['target']+'\n'+payload['action']
                        if payload.get('visual') not in ('approved','changes_needed','unreviewed'):
                            raise ValueError('Review state invalid')
                        session.state['reviews'][key] = {k:payload.get(k) for k in ('visual','reason','deviation_approved')}
                        session.state['reviews'][key]['base_signature'] = session.clip(payload['base'],payload['action']).get('signature')
                        session.state['reviews'][key]['target_signature'] = session.clip(payload['target'],payload['action']).get('signature')
                        session.save(); return self.response({'saved':True})
                    if self.path == '/api/palette':
                        mapping = session.set_palette(payload['bank'],payload['mapping'])
                        return self.response({'saved':True,'mapping':mapping})
                    if self.path == '/api/audit':
                        return self.response(session.audit(payload['base'],payload['target'],payload.get('mapping')))
                self.response({'error':'Not found'},404)
            except Exception as e:
                self.response({'error':str(e)},400)
    server = ThreadingHTTPServer(('127.0.0.1',port),Handler,bind_and_activate=False)
    if sys.platform=='win32':
        server.allow_reuse_address=False
        server.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
    server.server_bind();server.server_activate()
    print(f'Celeste Skin Lab {VERSION} http://127.0.0.1:{port}',flush=True)
    print('Session:',session.path,flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['serve','catalog','audit'])
    parser.add_argument('--session',default=str(KIT/'session'))
    parser.add_argument('--game',help='User-owned Celeste directory; read-only')
    parser.add_argument('--port',type=int,default=8766)
    parser.add_argument('--base'); parser.add_argument('--target')
    args = parser.parse_args()
    if args.game:
        source = Path(args.game).expanduser().resolve(); workspace = Path(args.session).expanduser().resolve()
        if workspace==source or workspace.is_relative_to(source) or source.is_relative_to(workspace):
            parser.error('Source and session must be independent; refusing before creating any session files')
    session = Session(args.session)
    if args.game:
        session.add_source(args.game,'原版 Celeste','official')
    if args.command=='serve':
        serve(session,args.port)
    elif args.command=='catalog':
        result = session.catalog(); result.pop('token',None)
        print(json.dumps(result,ensure_ascii=False,indent=2))
    else:
        print(json.dumps(session.audit(args.base,args.target),ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
