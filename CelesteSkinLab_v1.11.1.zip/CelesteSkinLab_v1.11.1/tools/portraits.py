"""Portrait XML loading and compact single-cycle expression clips."""
import copy,hashlib,json,re
from xml.etree import ElementTree as ET

ROLE='portraits'
NAMES={'portrait_madeline':'马德琳','portrait_madeline_phone':'马德琳 · 电话','portrait_badeline':'Badeline','portrait_theo':'Theo','portrait_granny':'老奶奶','portrait_oshiro':'Oshiro','portrait_mom':'妈妈','portrait_bird':'鸟'}
EXPRESSIONS={'normal':'普通','peaceful':'平静','angry':'生气','deadpan':'无语','sad':'难过','sadder':'更难过','upset':'不安','surprised':'惊讶','distracted':'走神','determined':'坚定','determinedclosed':'闭眼坚定','panic':'惊慌','together':'合体','togetherZoom':'合体推近','sleep':'睡觉'}

def weighted_targets(value):
    out=[]
    for item in (value or '').split(','):
        if not item.strip():continue
        pair=item.strip().split(':');weight=int(pair[1]) if len(pair)>1 else 1
        if weight>0:out.append((pair[0],weight))
    return out

def expressions(bank):
    return list(dict.fromkeys(a[5:] for a in bank['animations'] if a.startswith('idle_') and not re.search(r'_(?:blink\d*|alt\d*|loop)$',a[5:],re.I)))

def register(session):
    native=[(k,r) for k,r in session.banks.items() if r['source']=='official' and r['name'].startswith('portrait_')]
    for source in session.sources.values():
        existing={r['name'] for r in session.banks.values() if r['source']==source.id and r['name'].startswith('portrait_')}
        if source.id!='official':
            for key,row in native:
                if row['name'] in existing:continue
                b=session.resolve_bank(key)
                if any(k.startswith(b['paths'][0][1]) for k in source.keys()):
                    node=ET.Element(row['name'],copy=row['name'],path=b['paths'][0][1])
                    newkey=f'{source.id}|__skinlab_portraits__.xml|{node.tag}'
                    session.banks[newkey]=dict(key=newkey,source=source.id,file='__skinlab_portraits__.xml',name=node.tag,node=node)
        children=[]
        for key,row in list(session.banks.items()):
            if row['source']==source.id and row['name'].startswith('portrait_'):
                row['entity_component']=True
                children.append(dict(bank=key,prefix=row['name'],label=NAMES.get(row['name'],row['name'].removeprefix('portrait_'))))
        if children:
            key=f'{source.id}|__skinlab_portraits__.xml|portraits'
            session.banks[key]=dict(key=key,source=source.id,file='__skinlab_portraits__.xml',name=ROLE,node=ET.Element(ROLE),portrait_children=children)

def resolve(session,row):
    out=dict(paths=[],animations={},metadata={},origin=['absolute',0,0],start=None,is_player=False)
    for child in row['portrait_children']:
        b=session.resolve_bank(child['bank'])
        for expr in expressions(b):
            key=child['prefix']+'/'+expr
            out['animations'][key]=dict(id=key,kind='Portrait',_portrait_bank=child['bank'],expression=expr,label=child['label'])
        for anim in b['animations']:
            key=child['prefix']+'/@'+anim
            out['animations'][key]=dict(id=key,kind='PortraitRaw',_portrait_bank=child['bank'],raw_animation=anim,label=child['label'])
    if out['animations']:out['start']=next(iter(out['animations']))
    return out

def groups(session):
    result={}
    for row in session.banks.values():
        if not row.get('portrait_children'):continue
        for a,d in resolve(session,row)['animations'].items():
            group=d['label']+(' · XML动画' if 'raw_animation' in d else ' · 表情')
            if a not in result.setdefault(group,[]):result[group].append(a)
    return {ROLE:result} if result else {}

def clip(session,key,action,mode='talk'):
    from skinlab import frame_sequence
    cache=(key,action,'portrait-cycle',mode)
    if cache in session.clips:return session.clips[cache]
    row=session.banks[key];definition=resolve(session,row)['animations'].get(action)
    if not definition:return dict(action=action,missing_action=action,frames=[],delay=0,kind='Missing')
    b=session.resolve_bank(definition['_portrait_bank']);raw=definition.get('raw_animation');expr=definition.get('expression')
    idle='idle_'+expr if expr else None;talk='talk_'+expr if expr else None;begin='begin_'+expr if expr else None
    states=[]
    if expr:
        for value,label,name in [('talk','说话',talk),('idle','停嘴',idle),('begin','开场',begin)]:
            if name in b['animations']:states.append(dict(value=value,label=label))
        branches=[n for n in b['animations'] if n.startswith(idle+'_')]
        for i,name in enumerate(branches):
            tail=name[len(idle)+1:]
            label='眨眼'+tail[5:] if tail.startswith('blink') else tail
            states.append(dict(value='anim:'+name,label=label))
    selected=mode if any(x['value']==mode for x in states) else ('talk' if talk in b['animations'] else 'idle')
    name=raw or {'talk':talk,'idle':idle,'begin':begin}.get(selected) or selected.removeprefix('anim:')
    a=b['animations'].get(name)
    if not a:return dict(action=action,missing_action=action,frames=[],delay=0,kind='Missing')
    available=session.frame_files(b,a.get('path',''),a.get('frames'),a.get('_definition'))
    sequence=frame_sequence(a.get('frames'),available);output=[];missing=[];fallback=[]
    delay=float(a.get('delay',a.get('_delay_default',0)))
    for index in sequence:
        if index not in available:
            missing.append(name+':'+str(index));f=dict(index=index,missing=True)
        else:
            sid,texture=available[index];f=copy.deepcopy(session.cache_image(sid,texture));f['index']=index
            origin=b['origin'];f['origin']=[origin[1]*f['size'][0],origin[2]*f['size'][1]] if origin[0]=='justify' else origin[1:]
            if sid!=row['source']:fallback.append(name+':'+str(index))
        f.update(duration=delay or .1,portrait_animation=name,talking=name.startswith('talk_'),portrait_phase='begin' if name.startswith('begin_') else 'talk' if name.startswith('talk_') else 'idle')
        # A held PNG is one inspection frame with its original total duration.
        if output and (f.get('source'),f.get('texture'),f.get('index'))==(output[-1].get('source'),output[-1].get('texture'),output[-1].get('index')):
            output[-1]['duration']=round(output[-1]['duration']+f['duration'],8)
        else:output.append(f)
    result=dict(action=action,path=action,sequence=[f.get('index',0) for f in output],source_sequence=sequence,frames_expression=a.get('frames'),
        kind=a['kind'],delay=delay,goto=a.get('goto'),origin_definition=b['origin'],metadata={},
        frames=output,frame_durations=[f['duration'] for f in output],missing_frames=missing,fallback_indices=fallback,
        preview_palette={},preview_effects={},preview_matched_pixels=0,procedural_effects_rendered=False,
        portrait=True,portrait_mode=selected,available_states=states,expression=expr,has_talk=talk in b['animations'] if expr else raw.startswith('talk_'),
        has_begin=begin in b['animations'] if expr else False,unique_image_count=len({f.get('url') for f in output}))
    result['signature']=hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest()
    session.clips[cache]=result;return result
