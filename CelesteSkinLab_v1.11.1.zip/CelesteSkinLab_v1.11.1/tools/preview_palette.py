"""Explicit source-RGB to target-RGB maps for each dash state."""
import re


def hex_color(value):
    if not isinstance(value, str):
        raise ValueError('原色和新色都应填写六位RGB色值。')
    value = value.strip().lstrip('#')
    if not re.fullmatch('[0-9a-fA-F]{6}', value):
        raise ValueError('原色和新色都应填写六位RGB色值，例如91B5E7。')
    return value.upper()


def normalize_palette(value):
    if not isinstance(value, dict) or set(value) - {'0', '1', '2'}:
        raise ValueError('请填写0、1、2三档；每档填keep或多组“原色”:“新色”。')
    out = {}
    for dash in ('0', '1', '2'):
        item = value.get(dash, 'keep')
        if isinstance(item, str) and item.strip().lower() == 'keep':
            out[dash] = 'keep'
        elif isinstance(item, dict) and len(item) <= 64:
            pairs = {}
            for source, target in item.items():
                source, target = hex_color(source), hex_color(target)
                if source in pairs:
                    raise ValueError('同一档中的原色不能重复填写。')
                pairs[source] = target
            out[dash] = pairs if pairs else 'keep'
        else:
            raise ValueError('每档填keep，或填写多组“原色”:“新色”；单独一个新色值无法确定替换关系。')
    return out
