"""Verified vanilla reference profiles; no automatic anatomy checks."""
COLLISION_REFERENCE = {
    'normal': {'label': '站立／普通', 'hitbox': [-4, -11, 8, 11], 'hurtbox': [-4, -11, 8, 9]},
    'duck': {'label': '蹲下', 'hitbox': [-4, -6, 8, 6], 'hurtbox': [-4, -6, 8, 4]},
    'feather': {'label': '羽毛', 'hitbox': [-4, -10, 8, 8], 'hurtbox': [-3, -9, 6, 6]},
}
COLLISION_NOTE = ('框的尺寸取自原版 Player，像素边框按 CelesteTAS 的方式绘制。'
                  '本工具配色：绿色碰撞框，红色受伤框。')
