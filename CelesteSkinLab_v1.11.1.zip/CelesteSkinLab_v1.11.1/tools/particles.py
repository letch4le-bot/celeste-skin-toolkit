"""SkinModHelper's static death particle and native 0.834-second radial preview."""
from xml.etree import ElementTree as ET
import copy,hashlib,io,json,math,re
from PIL import Image

ROLE='death_particle'

def register(session):
    rows=[]
    for key,r in list(session.banks.items()):
        if r.get('portrait_children'):continue
        try:a=session.resolve_bank(key)['animations']
        except (KeyError,ValueError):continue
        rows.append(dict(key=key,source=r['source'],file=r['file'],name=r['name'],actions=list(a),entity_component=r.get('entity_component',False)))
    players=[c for c in session.choices(rows) if not c['internal'] and c['role'] in ['player','player_no_backpack','player_badeline','badeline']]
    seen=set()
    for c in players:
        if c['source']=='official' and c['role']!='player':continue
        if c['bank'] in seen:continue
        seen.add(c['bank']);ident='death_'+hashlib.sha256(c['bank'].encode()).hexdigest()[:10]
        key=f"{c['source']}|__skinlab_particles__.xml|{ident}"
        label='死亡粒子' if c['source']=='official' else c['label']+' · 死亡粒子'
        session.banks[key]=dict(key=key,source=c['source'],file='__skinlab_particles__.xml',name=ident,node=ET.Element(ident),death_player=c['bank'],death_label=label,entity_component=True)

def choices(session):
    return [dict(id=k,bank=k,source=r['source'],label=r['death_label'],role=ROLE,internal=False) for k,r in session.banks.items() if r.get('death_player')]

def resolve(row):
    return dict(paths=[],animations={name:dict(id=name,kind='DeathPreview') for name in ['scatter','particle']},metadata={},origin=['absolute',32,32],start='scatter',is_player=False)

def clip(session,key,action,dash='1'):
    cache=(key,action,str(dash),'death')
    if cache in session.clips:return session.clips[cache]
    row=session.banks[key];bank=session.resolve_bank(row['death_player']);source=session.sources[row['source']]
    options=[prefix+'death_particle' for sid,prefix in bank['paths'] if sid==source.id]+['death_particle']
    texture=next((p for p in options if p in source.keys()),None)
    native=texture is None
    sid=source.id
    if native:
        sid='official';texture='characters/player/hair00'
        if sid not in session.sources:return dict(action=action,frames=[],missing_action='先加载原版以读取死亡粒子',kind='Missing',delay=0)
    particle=session.sources[sid].image(texture)
    config=source.texts.get('Graphics/Atlases/Gameplay/'+bank['paths'][0][1]+'skinConfig/CharacterConfig.yaml','')
    fixed=re.search(r'^DeathParticleColor:\s*["\']?([A-Fa-f0-9]{6})',config,re.M)
    idle=next(iter(bank['animations']))
    colour=session.clip(row['death_player'],idle,str(dash)).get('preview_effects',{}).get('hair_color',[172,50,50])
    if fixed:colour=[int(fixed.group(1)[i:i+2],16) for i in [0,2,4]]
    def save(im,index):
        out=io.BytesIO();im.save(out,format='PNG');data=out.getvalue();h=hashlib.sha256(data).hexdigest();p=session.path/'assets'/(h+'.png')
        if not p.exists():p.write_bytes(data)
        return dict(url='/assets/'+p.name,size=list(im.size),origin=[im.width/2,im.height/2],source=sid,texture=texture,index=index,sha256=h,raw_sha256=h,alpha_bounds=list(im.getbbox() or [0,0,0,0]))
    frames=[]
    if action=='particle':frames=[save(particle,0)];delay=0.;kind='Loop'
    elif action=='scatter':
        side=max(64,math.ceil(52+max(particle.size)))
        for i in range(51):
            ease=i/50.;scale=.5+ease if ease<.5 else 1-(2*ease-1)**3
            im=Image.new('RGBA',(side,side))
            if scale>0:
                size=(max(1,round(particle.width*scale)),max(1,round(particle.height*scale)))
                art=particle.resize(size,Image.Resampling.NEAREST);outline=Image.new('RGBA',size,(0,0,0,255));outline.putalpha(art.getchannel('A'))
                tint=colour if math.floor(ease*10)%2==0 else [255,255,255]
                pixels=[(*(round(px[k]*tint[k]/255) for k in range(3)),px[3]) for px in art.get_flattened_data()];art.putdata(pixels)
                positions=[]
                for j in range(8):
                    angle=(j/8+ease*.25)*math.tau;radius=(1-(1-ease)**3)*24
                    positions.append((round(side/2+math.cos(angle)*radius-size[0]/2),round(side/2+math.sin(angle)*radius-size[1]/2)))
                for x,y in positions:
                    for dx,dy in [(-1,0),(1,0),(0,-1),(0,1)]:im.alpha_composite(outline,(x+dx,y+dy))
                for x,y in positions:im.alpha_composite(art,(x,y))
            frames.append(save(im,i))
        delay=.834/50;kind='Anim'
    else:return dict(action=action,frames=[],missing_action=action,delay=0,kind='Missing')
    result=dict(action=action,path=texture,sequence=list(range(len(frames))),frames_expression=None,kind=kind,delay=delay,goto=None,origin_definition=['justify',.5,.5],metadata={},frames=frames,missing_frames=[],fallback_indices=[],preview_palette={},preview_effects={'hair_color':colour},preview_matched_pixels=0,procedural_effects_rendered=action=='scatter',death_particle=True,uses_original_particle=native,particle_size=list(particle.size),particle_texture=texture,particle_frame=save(particle,0),duration=.834 if action=='scatter' else 0,unique_image_count=len({f['url'] for f in frames}))
    result['signature']=hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest();session.clips[cache]=result;return result
