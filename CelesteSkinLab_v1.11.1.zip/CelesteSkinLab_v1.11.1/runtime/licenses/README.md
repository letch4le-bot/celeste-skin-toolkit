# 第三方组件

Python、Pillow 与 Microsoft WebView2 SDK 的许可随包保留。Pillow 的各项许可见 Python/Lib/site-packages/pillow-12.3.0.dist-info/licenses；Python 和 WebView2 的许可在本目录。

组件来源和 SHA256 记录在上一级 dependencies.json。WebView2 Runtime 由电脑原有环境提供，不在本包中安装。工具不附带游戏或参考 mod 的图片。
