using System;
using System.Drawing;
using System.IO;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
[assembly: AssemblyTitle("Celeste Skin Lab")]
[assembly: AssemblyVersion("1.11.1.0")]

static class Program {
    [DllImport("kernel32",CharSet=CharSet.Unicode)] static extern bool SetDllDirectory(string path);
    [STAThread] static void Main(string[] args) {
        string root=AppDomain.CurrentDomain.BaseDirectory;
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender,ResolveEventArgs e) {
            string path=Path.Combine(root,"runtime","webview",new AssemblyName(e.Name).Name+".dll");
            return File.Exists(path)?Assembly.LoadFrom(path):null;
        };
        SetDllDirectory(Path.Combine(root,"runtime","webview"));
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        try { Run(root,args); }
        catch(Exception e) { MessageBox.Show("启动失败："+e.Message,"皮肤动作对照",MessageBoxButtons.OK,MessageBoxIcon.Error); }
    }
    static void Run(string root,string[] args) {
        string key=BitConverter.ToString(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(root.ToLowerInvariant()))).Replace("-","").Substring(0,20);
        bool created;
        using(var mutex=new Mutex(true,"Local\\CelesteSkinLab_"+key,out created)) {
            if(!created){MessageBox.Show("工具已经打开。","皮肤动作对照");return;}
            Application.Run(new LabWindow(root,args));
        }
    }
}

sealed class OwnedJob:IDisposable {
    IntPtr handle;
    [StructLayout(LayoutKind.Sequential)] struct Limits {public long a,b;public uint flags;public UIntPtr min,max;public uint active;public UIntPtr affinity;public uint priority,scheduling;}
    [StructLayout(LayoutKind.Sequential)] struct Counters {public ulong a,b,c,d,e,f;}
    [StructLayout(LayoutKind.Sequential)] struct Extended {public Limits basic;public Counters io;public UIntPtr processMemory,jobMemory,peakProcess,peakJob;}
    [DllImport("kernel32",CharSet=CharSet.Unicode)]static extern IntPtr CreateJobObject(IntPtr sa,string name);
    [DllImport("kernel32")]static extern bool SetInformationJobObject(IntPtr job,int cls,IntPtr info,uint len);
    [DllImport("kernel32")]static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
    [DllImport("kernel32")]static extern bool CloseHandle(IntPtr handle);
    public OwnedJob(){handle=CreateJobObject(IntPtr.Zero,null);Extended x=new Extended();x.basic.flags=0x2000;int n=Marshal.SizeOf(x);IntPtr p=Marshal.AllocHGlobal(n);try{Marshal.StructureToPtr(x,p,false);SetInformationJobObject(handle,9,p,(uint)n);}finally{Marshal.FreeHGlobal(p);}}
    public void Add(Process process){if(handle!=IntPtr.Zero)AssignProcessToJobObject(handle,process.Handle);}
    public void Dispose(){if(handle!=IntPtr.Zero){CloseHandle(handle);handle=IntPtr.Zero;}}
}

sealed class LabWindow:Form {
    readonly string root;readonly string[] args;readonly Label status;readonly TextBox address;
    readonly Panel content;readonly Button browser,copy,guide,back,exit;Process server;OwnedJob job;
    string url="";bool closing;readonly StringBuilder output=new StringBuilder();WebView2 view;
    public LabWindow(string directory,string[] arguments) {
        root=directory;args=arguments;Text="皮肤动作对照";Width=1280;Height=860;MinimumSize=new Size(850,580);StartPosition=FormStartPosition.CenterScreen;
        Font=new Font("Microsoft YaHei UI",10);BackColor=Color.FromArgb(15,23,32);
        var bar=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true,MinimumSize=new Size(0,46),Padding=new Padding(8,6,6,4),BackColor=SystemColors.Control};
        browser=new Button{Text="在浏览器打开",AutoSize=true,Enabled=false};copy=new Button{Text="复制地址",AutoSize=true,Enabled=false};guide=new Button{Text="使用说明",AutoSize=true};
        back=new Button{Text="返回对照",AutoSize=true,Enabled=false};exit=new Button{Text="退出工具",AutoSize=true};
        address=new TextBox{ReadOnly=true,Width=245,BorderStyle=BorderStyle.FixedSingle};
        bar.Controls.Add(back);bar.Controls.Add(browser);bar.Controls.Add(copy);bar.Controls.Add(guide);bar.Controls.Add(exit);bar.Controls.Add(address);
        status=new Label{Dock=DockStyle.Bottom,Height=27,ForeColor=Color.White,Padding=new Padding(10,3,0,0),Text="正在启动…"};
        content=new Panel{Dock=DockStyle.Fill};Controls.Add(content);Controls.Add(status);Controls.Add(bar);
        browser.Click+=delegate{if(url!="")Open(url);};copy.Click+=delegate{if(url!="")Clipboard.SetText(url);};
        back.Click+=delegate{NavigateTo("");};guide.Click+=delegate{NavigateTo("/guide");};exit.Click+=delegate{Close();};
        Shown+=async delegate{await Start();};FormClosing+=delegate{closing=true;Stop();};
    }
    static string Q(string value){return "\""+value.Replace("\"","\\\"")+"\"";}
    static void Open(string value){Process.Start(new ProcessStartInfo(value){UseShellExecute=true});}
    void NavigateTo(string path){if(url=="")return;if(view!=null&&view.CoreWebView2!=null)view.CoreWebView2.Navigate(url+path);else Open(url+path);}
    async Task Start() {
        try {
            string python=Path.Combine(root,"runtime","python","python.exe");
            if(!File.Exists(python))throw new IOException("缺少程序文件，请重新解压完整的工具包。");
            Directory.CreateDirectory(Path.Combine(root,"data"));
            int port=8766;while(port<8816){var listener=new TcpListener(IPAddress.Loopback,port);try{listener.Start();listener.Stop();break;}catch(SocketException){port++;}}
            if(port==8816)throw new IOException("暂时没有可用的本机端口。");
            url="http://127.0.0.1:"+port;
            var info=new ProcessStartInfo(python,Q(Path.Combine(root,"tools","skinlab.py"))+" serve --session "+Q(Path.Combine(root,"data","session"))+" --port "+port){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=root,RedirectStandardOutput=true,RedirectStandardError=true,StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8};
            info.EnvironmentVariables.Remove("PYTHONHOME");info.EnvironmentVariables.Remove("PYTHONPATH");info.EnvironmentVariables["PYTHONIOENCODING"]="utf-8";
            server=new Process{StartInfo=info,EnableRaisingEvents=true};
            DataReceivedEventHandler receive=delegate(object s,DataReceivedEventArgs e){if(e.Data!=null)lock(output){output.AppendLine(e.Data);}};
            server.OutputDataReceived+=receive;server.ErrorDataReceived+=receive;
            job=new OwnedJob();server.Start();job.Add(server);server.BeginOutputReadLine();server.BeginErrorReadLine();
            bool ready=false;
            for(int i=0;i<200&&!closing;i++){
                if(server.HasExited)throw new IOException("本机服务启动失败。"+output.ToString());
                ready=await Task.Run(delegate{try{var request=WebRequest.CreateHttp(url+"/api/catalog");request.Timeout=500;using(var response=request.GetResponse()){return true;}}catch{return false;}});
                if(ready)break;await Task.Delay(100);
            }
            if(closing)return;if(!ready)throw new IOException("启动超时，请重新打开工具。");
            address.Text=url;browser.Enabled=copy.Enabled=back.Enabled=true;status.Text="已就绪　返回对照可关闭说明页；退出工具可停止程序";
            File.WriteAllText(Path.Combine(root,"data","server-address.txt"),url,Encoding.UTF8);
            try {
                view=new WebView2{Dock=DockStyle.Fill};content.Controls.Add(view);
                var env=await CoreWebView2Environment.CreateAsync(null,Path.Combine(root,"data","webview"));
                await view.EnsureCoreWebView2Async(env);
                view.CoreWebView2.Settings.AreDefaultContextMenusEnabled=false;
                view.CoreWebView2.WebMessageReceived+=delegate(object sender,CoreWebView2WebMessageReceivedEventArgs e){
                    if(!e.Source.StartsWith(url+"/"))return;
                    string request=e.TryGetWebMessageAsString(),chosen=null,field=request=="pick-game"?"gamepath":"modpath";
                    if(request.StartsWith("{")){
                        var serializer=new JavaScriptSerializer();
                        var message=serializer.Deserialize<System.Collections.Generic.Dictionary<string,object>>(request);
                        if(message.ContainsKey("type")&&(string)message["type"]=="drop-png"){
                            string requestId=Convert.ToString(message["requestId"]);
                            try{
                                var paths=new System.Collections.Generic.List<string>();
                                foreach(var item in e.AdditionalObjects){var file=item as CoreWebView2File;if(file==null||!File.Exists(file.Path)||!System.Text.RegularExpressions.Regex.IsMatch(file.Path,@"\.(png|jpe?g|webp|bmp|gif)$",System.Text.RegularExpressions.RegexOptions.IgnoreCase))throw new IOException("请选择支持的静态图片。");paths.Add(file.Path);}
                                if(paths.Count<1||paths.Count>32)throw new IOException("每次可拖入1至32张图片。");
                                view.CoreWebView2.PostWebMessageAsJson(serializer.Serialize(new{type="dropped-png-paths",requestId=requestId,paths=paths}));
                            }catch(Exception error){view.CoreWebView2.PostWebMessageAsJson(serializer.Serialize(new{type="dropped-png-paths",requestId=requestId,error=error.Message}));}
                        }
                        return;
                    }
                    if(request=="pick-game"||request=="pick-folder"){
                        using(var dialog=new FolderBrowserDialog{Description=request=="pick-game"?"选择 Celeste 游戏目录":"选择皮肤文件夹",ShowNewFolderButton=false}){
                            if(dialog.ShowDialog(this)==DialogResult.OK)chosen=dialog.SelectedPath;
                        }
                    }else if(request=="pick-zip"){
                        using(var dialog=new OpenFileDialog{Title="选择皮肤 ZIP",Filter="皮肤 ZIP|*.zip",CheckFileExists=true}){
                            if(dialog.ShowDialog(this)==DialogResult.OK)chosen=dialog.FileName;
                        }
                    }
                    if(chosen!=null)view.CoreWebView2.PostWebMessageAsJson(new JavaScriptSerializer().Serialize(new{type="picked-path",field=field,path=chosen}));
                };
                view.CoreWebView2.NewWindowRequested+=delegate(object sender,CoreWebView2NewWindowRequestedEventArgs e){e.Handled=true;Open(e.Uri);};
                view.CoreWebView2.NavigationStarting+=delegate(object sender,CoreWebView2NavigationStartingEventArgs e){Uri target;if(Uri.TryCreate(e.Uri,UriKind.Absolute,out target)&&!e.Uri.StartsWith(url+"/")&&e.Uri!=url){e.Cancel=true;Open(e.Uri);}};
                view.Source=new Uri(url);
            }catch(Exception){if(view!=null){content.Controls.Remove(view);view.Dispose();view=null;}var note=new Label{Text="点击上方“在浏览器打开”即可使用。",ForeColor=Color.White,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleCenter};content.Controls.Add(note);status.Text="本机服务已启动　当前电脑未能打开内嵌网页，可使用浏览器";}
        }catch(Exception e){if(!closing){status.Text="启动失败";MessageBox.Show(this,e.Message,"皮肤动作对照",MessageBoxButtons.OK,MessageBoxIcon.Error);Close();}}
    }
    void Stop(){if(view!=null){view.Dispose();view=null;}if(server!=null){try{if(!server.HasExited)server.Kill();server.WaitForExit(3000);}catch{}server.Dispose();server=null;}if(job!=null){job.Dispose();job=null;}}
}
