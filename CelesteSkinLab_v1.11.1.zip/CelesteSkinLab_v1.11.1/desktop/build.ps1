﻿$ErrorActionPreference='Stop'
$taskTool=Split-Path -Parent $PSScriptRoot
$taskCompiler=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$taskOutput=Join-Path $taskTool '皮肤动作对照.exe'
$taskCore=Join-Path $taskTool 'runtime/webview/Microsoft.Web.WebView2.Core.dll'
$taskForms=Join-Path $taskTool 'runtime/webview/Microsoft.Web.WebView2.WinForms.dll'
& $taskCompiler /nologo /target:winexe /platform:x64 /utf8output /optimize+ "/out:$taskOutput" /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Net.Http.dll /r:System.Web.Extensions.dll "/r:$taskCore" "/r:$taskForms" (Join-Path $PSScriptRoot 'SkinLab.cs')
if($LASTEXITCODE -ne 0){throw 'Desktop compilation failed.'}
