"""Entity collections: real atlas parsing and texture-only/XML override contracts, synthetic art."""
import copy,json,struct,unittest
from PIL import Image
import test_skinlab as fixtures
from skinlab import Session
bstring=fixtures.bstring

class EntityTests(unittest.TestCase):
    setUp=fixtures.SkinLabTests.setUp
    tearDown=fixtures.SkinLabTests.tearDown

    def entities(self):
        graphics=self.game/'Content/Graphics'
        p=graphics/'Sprites.xml'
        xml='''<bird path="characters/bird/"><Origin x="16" y="24"/>
          <Loop id="idle" path="crow" frames="0,1,1,2" delay=".1"/>
          <Anim id="peck" path="crow" frames="2,1" delay=".08" goto="idle"/></bird>
        <glider path="objects/glider/"><Justify x=".5" y=".58"/><Loop id="idle" path="idle" delay=".06"/></glider>
        <booster path="objects/booster/"><Center/><Loop id="loop" path="booster" frames="0,1" delay=".1"/></booster>
        <boosterRed path="objects/booster/"><Center/><Anim id="pop" path="boosterRed" frames="0,1" delay=".08"/></boosterRed>
        <strawberry path="collectables/strawberry/"><Center/><Loop id="idle" path="normal" frames="0,1" delay=".1"/></strawberry>
        <moonberry path="collectables/moonberry/"><Center/><Loop id="idle" path="normal" frames="0,1" delay=".1"/></moonberry>'''
        p.write_text(p.read_text().replace('</Sprites>',xml+'</Sprites>'))
        entries=[(name,*values) for name,(_,values) in self.session.sources['official'].packed.items()]
        prefixes={'characters/bird/crow':3,'objects/glider/idle':2,'objects/booster/booster':2,
                  'objects/booster/boosterRed':2,'collectables/strawberry/normal':2,'collectables/moonberry/normal':2,
                  'objects/refill/idle':2,'objects/refill/flash':3,'objects/refill/outline':1,
                  'objects/refillTwo/idle':2,'objects/refillTwo/flash':3,'objects/refillTwo/outline':1}
        for prefix,n in prefixes.items():
            for i in range(n):entries.append((prefix+f'{i:02}',0,0,4,4,0,0,36,20))
        meta=struct.pack('<i',1)+bstring('synthetic')+struct.pack('<ih',0,1)+bstring('synthetic')+struct.pack('<h',len(entries))
        for name,*values in entries:meta+=bstring(name)+struct.pack('<hhhhhhhh',*values)
        (graphics/'Atlases/Gameplay.meta').write_bytes(meta)
        self.session.reload()

    def collection(self,role,sid='official'):
        return next(c['bank'] for c in self.session.catalog()['choices'] if c['source']==sid and c['role']==role)

    def test_categories_group_entities_and_keep_native_timing_origins(self):
        self.entities();catalog=self.session.catalog()
        self.assertEqual([c['label'] for c in catalog['entity_categories']],['交互实体','泡泡','冲刺水晶','草莓'])
        key=self.collection('props_interactive');bird=self.session.clip(key,'bird/idle')
        self.assertEqual(bird['sequence'],[0,1,1,2]);self.assertEqual(bird['delay'],.1)
        self.assertEqual(bird['frames'][0]['origin'],[16,24])
        self.assertEqual(self.session.clip(key,'bird/peck')['goto'],'bird/idle')
        glider=self.session.clip(key,'glider/idle')
        self.assertEqual(glider['frames'][0]['origin'],[18,11.6])
        self.assertFalse(any('bangs' in f for f in glider['frames']))
        self.assertIn('bird/idle',catalog['entity_groups']['props_interactive']['鸟'])
        self.assertIn('glider/idle',catalog['entity_groups']['props_interactive']['水母'])
        self.assertNotIn('bird',[c['role'] for c in catalog['choices']])
        self.assertEqual(self.session.clip(self.base,'recover')['sequence'],[1,1,1,2,2])
        self.assertNotIn('idle',self.session.resolve_bank(key)['animations'])

    def test_refills_read_code_defined_layers_with_centered_origin(self):
        self.entities();key=self.collection('props_refills')
        for name in ('refill','refillTwo'):
            for action,n,delay in [('idle',2,.1),('flash',3,.05),('outline',1,0)]:
                clip=self.session.clip(key,name+'/'+action)
                self.assertEqual(len(clip['frames']),n);self.assertEqual(clip['delay'],delay)
                self.assertEqual(clip['frames'][0]['origin'],[18,10]);self.assertFalse(clip['missing_frames'])

    def test_texture_only_override_is_detected_and_palette_does_not_modify_state_on_read(self):
        self.entities();mod=self.root/'refillmod';folder=mod/'Graphics/Atlases/Gameplay/objects/refill';folder.mkdir(parents=True)
        for i in range(2):Image.new('RGBA',(36,20),(60,180,100,255)).save(folder/f'idle{i:02}.png')
        original={p.name:p.read_bytes() for p in folder.iterdir()}
        sid=self.session.add_source(mod,'Synthetic refill','candidate');key=self.collection('props_refills',sid)
        self.assertEqual([c['role'] for c in self.session.catalog()['choices'] if c['source']==sid],['props_refills'])
        clip=self.session.clip(key,'refill/idle');self.assertEqual(clip['frames'][0]['source'],sid)
        self.assertEqual(self.session.clip(key,'refill/flash')['frames'][0]['source'],'official')
        self.session.set_palette(key,{'1':{'3CB464':'FF0000'}})
        state=copy.deepcopy(self.session.state)
        changed=self.session.clip(key,'refill/idle');self.assertEqual(changed['preview_matched_pixels'],1440)
        self.assertNotEqual(changed['frames'][0]['sha256'],clip['frames'][0]['sha256'])
        self.assertEqual(self.session.state,state)
        self.assertEqual(original,{p.name:p.read_bytes() for p in folder.iterdir()})

    def test_helper_entity_xml_and_hidden_preferences_survive_reload(self):
        self.entities();mod=self.root/'xmlmod';folder=mod/'Graphics/Custom/';folder.mkdir(parents=True)
        (folder/'Sprites.xml').write_text('<Sprites><bird path="mybird/"><Origin x="3" y="7"/><Anim id="custom" path="fly" frames="0" delay=".2"/></bird></Sprites>')
        images=mod/'Graphics/Atlases/Gameplay/mybird';images.mkdir(parents=True)
        Image.new('RGBA',(10,14),(1,2,3,255)).save(images/'fly00.png')
        (mod/'SkinModHelperConfig.yaml').write_text('- SkinName: Test\n  General_List: true\n  OtherSprite_ExPath: Custom\n')
        sid=self.session.add_source(mod,'Synthetic bird','candidate');key=self.collection('props_interactive',sid)
        choice=next(c for c in self.session.catalog()['choices'] if c['bank']==key)
        self.assertFalse(choice['internal'])
        clip=self.session.clip(key,'bird/custom');self.assertEqual(clip['frames'][0]['origin'],[3,7]);self.assertEqual(clip['delay'],.2)
        self.session.save_preferences({'hiddenactionspanel':'true','hidden-interactive':'true','hidden-bubbles':'false','base':key})
        reopened=Session(self.root/'session');self.assertEqual(reopened.state['preferences']['hidden-interactive'],'true')
        self.assertEqual(reopened.clip(key,'bird/custom')['signature'],clip['signature'])

if __name__=='__main__':unittest.main()
