"""Coordinate and persistence regressions using synthetic art only."""
import sys,unittest
from pathlib import Path
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from precision import COLLISION_REFERENCE
import test_skinlab as _fixtures

class CollisionReferenceTests(unittest.TestCase):
    def test_vanilla_reference_does_not_depend_on_image_bounds(self):
        self.assertEqual(COLLISION_REFERENCE['normal']['hitbox'],[-4,-11,8,11])
        self.assertEqual(COLLISION_REFERENCE['duck']['hitbox'],[-4,-6,8,6])
        self.assertEqual(COLLISION_REFERENCE['feather']['hurtbox'],[-3,-9,6,6])

# Reuse fixture setup without inheriting and rerunning the original test suite.
class KeyPreferenceTests(unittest.TestCase):
    setUp=_fixtures.SkinLabTests.setUp
    tearDown=_fixtures.SkinLabTests.tearDown

    def test_custom_keys_survive_reopening_and_invalid_keys_do_not_write(self):
        from skinlab import Session
        keys={'toggle':['Space'],'prev':['ArrowLeft','Numpad4'],'next':['Ctrl+KeyD']}
        self.session.save_preferences({'keybindings':keys,'inspect':self.base})
        reopened=Session(self.root/'session')
        self.assertEqual(reopened.catalog()['preferences']['keybindings'],keys)
        before=(self.root/'session/session.json').read_bytes()
        for bad in ({'toggle':['Space'],'prev':['Space'],'next':['KeyD']},
                    {'toggle':['Space'],'prev':None,'next':['KeyD']},
                    {'toggle':['Space'],'prev':['ArrowLeft'],'next':['<script>']}):
            with self.assertRaises(ValueError):self.session.save_preferences({'keybindings':bad})
            self.assertEqual((self.root/'session/session.json').read_bytes(),before)

    def test_clips_have_no_auto_pixel_probe_and_report_never_claims_gameplay_pass(self):
        clip=self.session.clip(self.base,'idle')
        self.assertNotIn('pixel_probe',clip['frames'][0])
        report=self.session.audit(self.base,self.base)
        self.assertFalse(report['gameplay_tested'])
        self.assertTrue(report['resource_pass'])
        self.assertNotIn('pixel_probe_actions',report)
        self.assertEqual(report['manual_pixel_checks'],[{'action':'idle','parts':['脚底'],'status':'manual_only'}])

    def test_different_art_is_not_an_error_or_an_automatic_pixel_check(self):
        from test_skinlab import make_mod
        mod=self.root/'cape';make_mod(mod,'<Sprites><hero copy="player" path="mine/"><Loop id="idle" path="idle" frames="0-2" delay=".1"/></hero></Sprites>')
        # Larger art on the same canvas represents a hat or cape, not a missing resource.
        im=Image.new('RGBA',(32,32));im.paste((60,180,100,255),(1,1,30,32))
        for i in range(3):im.save(mod/f'Graphics/Atlases/Gameplay/mine/idle{i:02d}.png')
        sid=self.session.add_source(mod,'Hat and cape','candidate')
        target=next(k for k,b in self.session.banks.items() if b['source']==sid)
        r=self.session.audit(self.base,target)
        self.assertTrue(r['resource_pass']);self.assertTrue(r['static_pass'])
        self.assertEqual(r['playback_needs_confirmation'],[])
        self.assertTrue(all('pixel_probes' not in row for row in r['rows']))

    def test_different_timing_can_be_accepted_but_missing_resources_cannot(self):
        from test_skinlab import make_mod
        mod=self.root/'timing';make_mod(mod,'<Sprites><hero copy="player" path="mine/"><Loop id="idle" path="idle" frames="0-2" delay=".2"/></hero></Sprites>')
        sid=self.session.add_source(mod,'Slow design','candidate');target=next(k for k,b in self.session.banks.items() if b['source']==sid)
        r=self.session.audit(self.base,target);self.assertTrue(r['resource_pass']);self.assertIn('idle',r['playback_needs_confirmation'])
        a,b=self.session.clip(self.base,'idle'),self.session.clip(target,'idle')
        self.session.state['reviews'][self.base+'\n'+target+'\nidle']={'visual':'unreviewed','deviation_approved':True,'reason':'Intentional slower breathing','base_signature':a['signature'],'target_signature':b['signature']}
        r=self.session.audit(self.base,target);self.assertIn('idle',r['playback_accepted_design']);self.assertNotIn('idle',r['playback_needs_confirmation'])

    def test_manual_pixel_scope_excludes_moving_animations(self):
        path=self.game/'Content/Graphics/Sprites.xml'
        extra=''.join(f'<Loop id="{name}" path="idle" frames="0-2" delay=".1"/>' for name in ('idleB','walk','runSlow','jumpSlow','wallslide','climbup'))
        text=path.read_text();path.write_text(text.replace('</player>',extra+'</player>'))
        self.session.reload()
        report=self.session.audit(self.base,self.base)
        self.assertEqual({r['action'] for r in report['manual_pixel_checks']},{'idle','wallslide','climbup'})
        for r in report['manual_pixel_checks']:
            self.assertEqual(r['parts'],['脚底'] if r['action'].startswith('idle') else ['手','脚','下巴','头顶'])

if __name__=='__main__':unittest.main()
