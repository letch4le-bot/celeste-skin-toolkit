"""Multi-color exact maps, source matching, keep and non-cascading swaps."""
from pathlib import Path
import sys,unittest
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from preview_palette import normalize_palette
from skinlab import Session
import test_skinlab as fixtures

BLUE=['91B5E7','6D97D7','4B71B5','304873']
GREY=['B7A9C1','9786A5','756480','51475F']
PINK=['E2B8EC','C88ED9','A46AB6','70467F']

def rgb(text):return tuple(bytes.fromhex(text))
def cube(c):
 r,g,b=(int(v*15/255+.5) for v in c)
 return r+b*16,g

class PreviewPaletteTests(unittest.TestCase):
 setUp=fixtures.SkinLabTests.setUp
 tearDown=fixtures.SkinLabTests.tearDown

 def make_skin(self,with_lut=True):
  path=self.root/'skin'
  fixtures.make_mod(path,'<Sprites><player_no_backpack path="mine/"><Origin x="16" y="32"/><Loop id="idle" path="idle" frames="0-2" delay=".1"/><Anim id="recover" path="idle" frames="1*3,2*2" delay=".08" goto="idle"/></player_no_backpack></Sprites>')
  root=path/'Graphics/Atlases/Gameplay/mine'
  if with_lut:
   (root/'ColorGrading').mkdir()
   for dash,colors in enumerate([GREY,BLUE,PINK]):
    lut=Image.new('RGB',(256,16))
    for b in range(16):
     for g in range(16):
      for r in range(16):lut.putpixel((r+b*16,g),(r*17,g*17,b*17))
    for source,target in zip(BLUE,colors):lut.putpixel(cube(rgb(source)),rgb(target))
    lut.putpixel(cube((212,225,236)),(218,225,236))
    lut.save(root/f'ColorGrading/dash{dash}.png')
  for i in range(3):
   im=Image.new('RGBA',(32,32))
   for x,c in enumerate(BLUE):im.putpixel((10+x+i,28),(*rgb(c),160 if x==3 else 255))
   im.putpixel((20,28),(255,255,255,255));im.putpixel((21,28),(212,225,236,255))
   im.putpixel((5,5),(*rgb(BLUE[0]),0));im.save(root/f'idle{i:02}.png')
  sid=self.session.add_source(path,'Synthetic seal palette','candidate')
  key=next(k for k,b in self.session.banks.items() if b['source']==sid)
  return path,key

 def image(self,key,dash,index=0,action='idle'):
  f=self.session.clip(key,action,str(dash))['frames'][index]
  return Image.open(self.session.path/f['url'].lstrip('/')).convert('RGBA')

 def test_four_independent_colors_all_frames_keep_and_source_files(self):
  path,key=self.make_skin();before={p.relative_to(path):p.read_bytes() for p in path.rglob('*') if p.is_file()}
  original=[self.image(key,1,i).tobytes() for i in range(3)]
  custom=['F08A21','210B63','23A143','C2E611']
  self.session.set_palette(key,{'0':dict(zip(BLUE,custom)),'1':'keep','2':dict(zip(BLUE,PINK))})
  for i in range(3):
   self.assertEqual(self.image(key,1,i).tobytes(),original[i])
   for dash,colors in [(0,custom),(2,PINK)]:
    im=self.image(key,dash,i)
    for x,c in enumerate(colors):self.assertEqual(im.getpixel((10+x+i,28)),(*rgb(c),160 if x==3 else 255))
    self.assertEqual(im.getpixel((20,28)),(255,255,255,255))
    self.assertEqual(im.getpixel((21,28)),(218,225,236,255))
    self.assertEqual(im.getpixel((5,5)),(*rgb(BLUE[0]),0))
  self.assertEqual(self.session.clip(key,'idle','0')['preview_matched_pixels'],12)
  clip=self.session.clip(key,'recover','0');self.assertEqual(clip['sequence'],[1,1,1,2,2]);self.assertEqual(clip['goto'],'idle')
  self.assertEqual(before,{p.relative_to(path):p.read_bytes() for p in path.rglob('*') if p.is_file()})

 def test_partial_map_preserves_unmapped_native_lut_colors(self):
  path,key=self.make_skin();self.session.set_palette(key,{'0':{BLUE[0]:'010203'}})
  im=self.image(key,0)
  self.assertEqual(im.getpixel((10,28)),(1,2,3,255))
  for x,c in enumerate(GREY[1:],1):self.assertEqual(im.getpixel((10+x,28))[:3],rgb(c))
  self.assertEqual(im.getpixel((21,28)),(218,225,236,255))

 def test_swaps_are_simultaneous_and_do_not_cascade(self):
  path,key=self.make_skin();self.session.set_palette(key,{'1':{BLUE[0]:BLUE[1],BLUE[1]:BLUE[2],BLUE[2]:BLUE[0]}})
  im=self.image(key,1)
  for x,c in enumerate([BLUE[1],BLUE[2],BLUE[0]]):self.assertEqual(im.getpixel((10+x,28))[:3],rgb(c))

 def test_maps_work_without_luts_or_automatic_detection(self):
  path,key=self.make_skin(False);self.session.set_palette(key,{'2':dict(zip(BLUE,PINK))})
  for x,c in enumerate(PINK):self.assertEqual(self.image(key,2).getpixel((10+x,28))[:3],rgb(c))
  self.assertEqual(self.image(key,2).getpixel((21,28)),(212,225,236,255))

 def test_restore_reopen_and_legacy_auto_values_are_not_inferred(self):
  path,key=self.make_skin();old=self.image(key,1).tobytes();mapping={'0':'keep','1':dict(zip(BLUE,GREY)),'2':'keep'}
  self.session.set_palette(key,mapping);reopened=Session(self.root/'session');self.assertEqual(reopened.state['palettes'][key],mapping)
  self.session.set_palette(key,{'0':{},'1':'keep','2':'keep'});self.assertEqual(self.image(key,1).tobytes(),old)
  self.session.state['palettes'][key]={'0':'keep','1':'2E86AB','2':dict(zip(BLUE,PINK))};self.session.save();self.session.reload()
  self.assertEqual(self.image(key,1).tobytes(),old)
  for x,c in enumerate(PINK):self.assertEqual(self.image(key,2).getpixel((10+x,28))[:3],rgb(c))

 def test_invalid_single_colors_rejected_without_writing_and_hex_normalized(self):
  path,key=self.make_skin();before=self.session.state_file.read_bytes()
  for bad in [[],{'3':{}},{'0':'FFFFFF'},{'0':3},{'0':['keep']},{'0':{'bad':'123456'}},{'0':{'#FFFFFF':'123456','ffffff':'654321'}}]:
   with self.assertRaises(ValueError):self.session.set_palette(key,bad)
   self.assertEqual(self.session.state_file.read_bytes(),before)
  self.assertEqual(normalize_palette({'0':{'#91b5e7':'#b7a9c1'}}),{'0':{'91B5E7':'B7A9C1'},'1':'keep','2':'keep'})
  self.assertEqual(normalize_palette({'0':{},'1':{},'2':{}}),{'0':'keep','1':'keep','2':'keep'})

if __name__=='__main__':unittest.main()
