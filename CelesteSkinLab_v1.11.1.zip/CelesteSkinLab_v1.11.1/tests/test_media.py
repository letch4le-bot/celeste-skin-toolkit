"""Synthetic regression cases for portrait semantics and distinct import modes."""
from pathlib import Path
import io,shutil,sys,unittest,uuid
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from skinlab import Session,validate_pose_png,validate_reference_image
from portraits import weighted_targets

class MediaTests(unittest.TestCase):
    def setUp(self):
        self.base=Path(__file__).resolve().parents[1]/'.test-temp';self.base.mkdir(exist_ok=True)
        self.root=self.base/('media-'+uuid.uuid4().hex);self.root.mkdir()
    def tearDown(self):
        assert self.root.resolve().is_relative_to(self.base.resolve())
        shutil.rmtree(self.root)
    def image(self,size,colour):
        b=io.BytesIO();Image.new('RGBA',size,colour).save(b,format='PNG');return b.getvalue()
    def package(self):
        p=self.root/'mod';g=p/'Graphics';a=g/'Atlases/Portraits/hero';a.mkdir(parents=True)
        for i in range(4):(a/f'face{i:02}.png').write_bytes(self.image((160,160),(10+i,20,230,255)))
        (g/'Portraits.xml').write_text('''<Sprites><portrait_madeline path="hero/"><Center/>
        <Anim id="idle_normal" path="face" frames="0*2" delay=".1" goto="idle_normal:4,idle_normal_blink"/>
        <Anim id="idle_normal_blink" path="face" frames="1,2,1" delay=".08" goto="idle_normal"/>
        <Loop id="talk_normal" path="face" frames="3,0" delay=".2"/>
        <Anim id="idle_sleep" path="face" frames="0,1,2" delay=".1"/>
        <Anim id="begin_togetherZoom" path="face" frames="0,1" delay=".06"/>
        <Loop id="idle_togetherZoom" path="face" frames="2" delay=".1"/>
        <Loop id="talk_togetherZoom" path="face" frames="3,2" delay=".2"/>
        </portrait_madeline><portrait_madeline_phone copy="portrait_madeline"/></Sprites>''',encoding='utf-8')
        session=Session(self.root/'session');sid=session.add_source(p,'Example','candidate')
        c=next(c for c in session.catalog()['choices'] if c['source']==sid and c['role']=='portraits');return session,c['bank']
    def test_import_modes_keep_native_pixels(self):
        for size in [(10,10),(160,160),(1024,720),(2048,2048)]:
            data=self.image(size,(25,75,125,255));result=validate_reference_image(data)
            self.assertEqual(Image.open(io.BytesIO(result)).size,size)
            with self.assertRaises(ValueError):validate_pose_png(data,[16,32])
        self.assertTrue(validate_pose_png(self.image((32,32),'white'),[16,32]))
    def test_arbitrary_reference_roundtrip_and_copy_rejection(self):
        p=self.root/'large.png';p.write_bytes(self.image((1024,720),'blue'));s=Session(self.root/'s')
        ids=s.add_pngs([{'path':str(p)}],[16,32],mode='reference');self.assertEqual(len(ids),1)
        c=next(c for c in s.catalog()['choices'] if c['source']==ids[0]);self.assertEqual(c['size'],[1024,720])
        s=Session(self.root/'s');clip=s.clip(c['bank'],'pose');self.assertEqual(clip['frames'][0]['size'],[1024,720])
        with self.assertRaises(ValueError):s.add_pngs([{'path':str(p)}],[16,32],mode='frame')
    def test_one_native_cycle_without_forcing_talk_on_sleep(self):
        s,key=self.package();c=s.clip(key,'portrait_madeline/normal')
        self.assertTrue(c['frames'][0]['talking'])
        self.assertEqual(c['sequence'],[3,0])
        self.assertEqual(len(c['frames']),2)
        idle=s.clip(key,'portrait_madeline/normal',portrait_mode='idle')
        self.assertEqual(len(idle['frames']),1)
        self.assertEqual(idle['frame_durations'],[.2])
        self.assertEqual(idle['goto'],'idle_normal:4,idle_normal_blink')
        sleep=s.clip(key,'portrait_madeline/sleep');self.assertFalse(sleep['has_talk'])
        self.assertEqual(sleep['sequence'],[0,1,2])
        self.assertEqual(len(sleep['frames']),3)
    def test_opening_and_blink_are_independent_cycles(self):
        s,key=self.package();c=s.clip(key,'portrait_madeline/togetherZoom',portrait_mode='begin')
        self.assertEqual([f['portrait_phase'] for f in c['frames']],['begin','begin'])
        self.assertEqual(c['frame_durations'],[.06,.06])
        blink=s.clip(key,'portrait_madeline/normal',portrait_mode='anim:idle_normal_blink')
        self.assertEqual(blink['sequence'],[1,2,1])
        self.assertTrue(all(f['portrait_animation']=='idle_normal_blink' for f in blink['frames']))
        self.assertIn('anim:idle_normal_blink',{s['value'] for s in blink['available_states']})
        self.assertEqual(weighted_targets('idle:10,blink1,blink2'),[('idle',10),('blink1',1),('blink2',1)])
        raw=s.clip(key,'portrait_madeline/@talk_normal');self.assertEqual(raw['sequence'],[3,0]);self.assertEqual(raw['kind'],'Loop')
        phone=s.clip(key,'portrait_madeline_phone/normal');self.assertTrue(phone['has_talk']);self.assertFalse(phone['missing_frames'])

if __name__=='__main__':unittest.main()
