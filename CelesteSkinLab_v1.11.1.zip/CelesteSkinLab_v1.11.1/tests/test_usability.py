"""Import boundaries, original story hair and user-defined idle audit regressions."""
import base64, io, unittest
from PIL import Image
import test_skinlab as fixtures
from skinlab import Session

class UsabilityTests(unittest.TestCase):
    setUp=fixtures.SkinLabTests.setUp
    tearDown=fixtures.SkinLabTests.tearDown

    def test_common_static_formats_normalize_without_changing_original_files(self):
        for fmt,extension in [('PNG','png'),('JPEG','jpg'),('JPEG','jpeg'),('BMP','bmp'),('GIF','gif'),('WEBP','webp')]:
            with self.subTest(fmt=fmt,extension=extension):
                path=self.root/('free-name.'+extension);Image.new('RGB',(32,32),(60,100,150)).save(path,format=fmt);before=path.read_bytes()
                ids=self.session.add_pngs([{'path':str(path)}],[16,32]);self.session.reload()
                key=next(k for k,b in self.session.banks.items() if b['source']==ids[0]);f=self.session.clip(key,'pose')['frames'][0]
                self.assertEqual(f['size'],[32,32]);self.assertEqual(f['origin'],[16,32]);self.assertEqual(path.read_bytes(),before)
                mime='jpeg' if fmt=='JPEG' else fmt.lower()
                uploaded=self.session.add_pngs([{'name':path.name,'png':f'data:image/{mime};base64,'+base64.b64encode(before).decode()}],[16,32])
                self.assertEqual(len(uploaded),1)

    def test_non32_and_animated_images_reject_entire_batch(self):
        good=self.root/'ok.png';Image.new('RGBA',(32,32)).save(good)
        invalid=self.root/'oversize.png';Image.new('RGB',(64,32)).save(invalid)
        animated=self.root/'animated.gif';Image.new('RGB',(32,32),'red').save(animated,save_all=True,append_images=[Image.new('RGB',(32,32),'blue')],duration=100)
        before=self.session.state_file.read_bytes()
        for path in (invalid,animated):
            with self.assertRaises(ValueError):self.session.add_pngs([{'path':str(good)},{'path':str(path)}],[16,32])
            self.assertEqual(self.session.state_file.read_bytes(),before)

    def test_cleared_and_copy_keys_and_column_order_survive_reload(self):
        keys={'toggle':['Space'],'prev':[],'next':['ArrowRight'],'copyToggle':['KeyP'],'copyPrev':[],'copyNext':['KeyN'],'copyPlay':[],'copyLoop':[]}
        self.session.save_preferences({'keybindings':keys,'cardorder':['target','base']})
        saved=Session(self.session.path).state['preferences']
        self.assertEqual(saved['keybindings'],keys);self.assertEqual(saved['cardorder'],['target','base'])
        with self.assertRaises(ValueError):self.session.save_preferences({'keybindings':dict(keys,copyNext=['Space'])})

    def test_idle_abc_excluded_from_automatic_contract_and_manual_list(self):
        path=self.game/'Content/Graphics/Sprites.xml';xml=path.read_text()
        xml=xml.replace('</player>','<Loop id="idleA" path="missing"/><Loop id="idleB" path="idle" frames="0" delay="4"/><Loop id="idleC" path="missing"/></player>')
        path.write_text(xml);self.session.reload();report=self.session.audit(self.base,self.base)
        self.assertTrue(report['resource_pass']);self.assertFalse({'idleA','idleB','idleC'} & {r['action'] for r in report['rows']})
        self.assertEqual(report['excluded_custom_actions'],['idleA','idleB','idleC'])

    def test_story_badeline_uses_shared_player_bangs_and_fixed_purple(self):
        path=self.game/'Content/Graphics/Sprites.xml';xml=path.read_text().replace('</Sprites>','<badeline path="characters/badeline/"><Origin x="16" y="32"/><Loop id="idle" path="idle" frames="0" delay=".1"/><Metadata><Frames path="idle" hair="0,-2"/></Metadata></badeline></Sprites>');path.write_text(xml);self.session.reload()
        source=self.session.sources['official']
        source.packed['characters/badeline/idle00']=source.packed['characters/player/idle00']
        source.packed['characters/player/bangs00']=source.packed['characters/player/idle00']
        key=next(k for k,b in self.session.banks.items() if b['name']=='badeline')
        for dash in ('0','1','2'):
            clip=self.session.clip(key,'idle',dash);self.assertIn('bangs',clip['frames'][0]);self.assertEqual(clip['preview_effects']['hair_color'],(155,63,181))

if __name__=='__main__':unittest.main()
