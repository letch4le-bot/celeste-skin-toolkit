"""Lookout is an independent entity sprite, including Helper player-bound XML."""
import copy,struct,unittest
from xml.etree import ElementTree as ET
from PIL import Image
import test_skinlab as fixtures
from skinlab import Session

class LookoutTests(unittest.TestCase):
    setUp=fixtures.SkinLabTests.setUp
    tearDown=fixtures.SkinLabTests.tearDown

    def add_lookout(self):
        root=ET.parse(self.game/'Content/Graphics/Sprites.xml').getroot()
        node=ET.SubElement(root,'lookout',path='objects/lookout/',start='idle')
        ET.SubElement(node,'Justify',x='.5',y='1')
        for prefix,texture in [('', 'lookout'),('nobackpack_','nobackpack'),('badeline_','badeline')]:
            ET.SubElement(node,'Loop',id=prefix+'idle',path=texture,frames='5*9,6',delay='.1')
            for name,sequence in [('lookRight','0-4'),('lookLeft','15-17,3,4')]:
                ET.SubElement(node,'Anim',id=prefix+name,path=texture,frames=sequence,delay='.08',goto=prefix+'looking')
            ET.SubElement(node,'Loop',id=prefix+'looking',path=texture,frames='4',delay='.08')
            for frame,name in enumerate(['lookingUp','lookingUpRight','lookingRight','lookingDownRight','lookingDown','lookingDownLeft','lookingLeft','lookingUpLeft'],7):
                ET.SubElement(node,'Loop',id=prefix+name,path=texture,frames=str(frame))
        ET.ElementTree(root).write(self.game/'Content/Graphics/Sprites.xml',encoding='unicode')
        entries=[(name,*values) for name,(_,values) in self.session.sources['official'].packed.items()]
        for prefix in ['lookout','nobackpack','badeline']:
            entries.extend((f'objects/lookout/{prefix}{i:02}',0,0,4,4,-14,-25,32,32) for i in range(18))
        data=struct.pack('<i',1)+fixtures.bstring('synthetic')+struct.pack('<ih',0,1)+fixtures.bstring('synthetic')+struct.pack('<h',len(entries))
        for name,*values in entries:data+=fixtures.bstring(name)+struct.pack('<hhhhhhhh',*values)
        (self.game/'Content/Graphics/Atlases/Gameplay.meta').write_bytes(data)
        self.session.reload()
        return node

    def choice(self,source='official'):
        return next(c for c in self.session.catalog()['choices'] if c['source']==source and c['role']=='lookout')

    def test_original_has_three_groups_and_native_sequences(self):
        self.add_lookout();choice=self.choice();catalog=self.session.catalog()
        self.assertEqual(choice['label'],'望远镜');self.assertTrue(choice['internal'])
        groups=catalog['entity_groups']['lookout'];self.assertEqual([len(v) for v in groups.values()],[12,12,12])
        key=choice['bank'];self.assertEqual(self.session.clip(key,'idle')['sequence'],[5]*9+[6])
        self.assertEqual(self.session.clip(key,'lookLeft')['sequence'],[15,16,17,3,4])
        self.assertEqual(self.session.clip(key,'nobackpack_lookLeft')['goto'],'nobackpack_looking')
        for action in self.session.resolve_bank(key)['animations']:
            clip=self.session.clip(key,action)
            self.assertFalse(clip['missing_frames']);self.assertFalse(clip['fallback_indices'])
            self.assertEqual(clip['frames'][0]['origin'],[16,32])
            self.assertFalse(any('bangs' in f for f in clip['frames']))

    def test_player_other_sprite_path_exposes_lookout_and_survives_reload(self):
        node=copy.deepcopy(self.add_lookout());node.set('path','myLookout/')
        mod=self.root/'bound-skin';fixtures.make_mod(mod,'<Sprites><myPlayer copy="player" path="mine/"/></Sprites>')
        folder=mod/'Graphics/Example/Fullhouse';folder.mkdir(parents=True)
        root=ET.Element('Sprites');root.append(node);ET.ElementTree(root).write(folder/'Sprites.xml',encoding='unicode')
        (mod/'SkinModHelperConfig.yaml').write_text('- SkinName: Demo\n  Player_List: true\n  General_List: false\n  Character_ID: myPlayer\n  OtherSprite_Path: Example/Fullhouse\n')
        textures=mod/'Graphics/Atlases/Gameplay/myLookout';textures.mkdir(parents=True)
        for prefix in ['lookout','nobackpack','badeline']:
            for i in range(18):Image.new('RGBA',(32,32),(70,110,90,255)).save(textures/f'{prefix}{i:02}.png')
        sid=self.session.add_source(mod,'My Fullhouse','candidate');choice=self.choice(sid)
        self.assertEqual(choice['id'],sid+'|Demo|lookout');self.assertTrue(choice['internal'])
        self.assertEqual(choice['label'],'Demo · 望远镜')
        result=self.session.audit(self.choice()['bank'],choice['bank']);self.assertTrue(result['resource_pass'])
        self.session.save_preferences({'base':self.choice()['bank'],'target':choice['id'],'group':'望远镜 · 玩家（无背包）','action':'nobackpack_lookingDown'})
        reopened=Session(self.root/'session')
        self.assertEqual(reopened.state['preferences']['action'],'nobackpack_lookingDown')
        self.assertEqual(len(reopened.resolve_bank(choice['bank'])['animations']),36)
        self.assertEqual(reopened.clip(choice['bank'],'lookingRight')['frames'][0]['source'],sid)

    def test_texture_only_lookout_override_keeps_fallback_visible(self):
        self.add_lookout();mod=self.root/'texture-only';folder=mod/'Graphics/Atlases/Gameplay/objects/lookout';folder.mkdir(parents=True)
        for i in range(18):Image.new('RGBA',(32,32),(30,90,140,255)).save(folder/f'lookout{i:02}.png')
        sid=self.session.add_source(mod,'Texture override','candidate');choice=self.choice(sid)
        custom=self.session.clip(choice['bank'],'lookRight');self.assertFalse(custom['fallback_indices'])
        self.assertTrue(all(f['source']==sid for f in custom['frames']))
        fallback=self.session.clip(choice['bank'],'badeline_lookRight')
        self.assertEqual(fallback['fallback_indices'],[0,1,2,3,4])
        self.assertTrue(all(f['source']=='official' for f in fallback['frames']))

    def test_character_actions_include_only_corresponding_lookout_variant(self):
        self.add_lookout();catalog=self.session.catalog()
        for role,prefix in [('player',''),('player_no_backpack','nobackpack_')]:
            c=next(c for c in catalog['choices'] if c['source']=='official' and c['role']==role)
            b=self.session.resolve_bank(c['bank']);actions=[a for a in b['animations'] if a.startswith('lookout/')]
            self.assertEqual(len(actions),12)
            clip=self.session.clip(c['bank'],'lookout/lookLeft')
            native=self.session.clip(self.choice()['bank'],prefix+'lookLeft')
            self.assertEqual(clip['sequence'],native['sequence'])
            self.assertEqual(clip['frames'],native['frames'])
            self.assertTrue(clip['lookout'])
        again=self.session.catalog()
        self.assertEqual(len(catalog['choices']),len(again['choices']))
        self.assertEqual(len(catalog['banks']),len(again['banks']))

if __name__=='__main__':unittest.main()
