"""Meaningful parser/safety tests using only synthetic geometry, no game art."""
import io
import json
import struct
import sys
import shutil
import uuid
import unittest
import zipfile
from pathlib import Path
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from skinlab import Session, Source, frame_sequence, parse_xml, safe_key

def bstring(text):
    value = text.encode(); assert len(value)<128
    return bytes([len(value)])+value

def make_game(root):
    graphics = root/'Content/Graphics'; atlas = graphics/'Atlases'; atlas.mkdir(parents=True)
    xml = '''<Sprites>
    <player path="characters/player/" start="idle"><Origin x="16" y="32"/>
      <Loop id="idle" path="idle" frames="0,1,2" delay="0.1"/>
      <Anim id="recover" path="idle" frames="1*3,2*2" delay="0.08" goto="idle"/>
      <Loop id="bigFall" path="bigFall" frames="0" delay="0.06"/>
      <Anim id="wakeUp" path="wakeUp/" frames="0" delay="0.1"/>
    </player>
    <player_no_backpack copy="player" path="characters/player_no_backpack/"/>
    <badeline_boss path="boss/"><Justify x="0.5" y="0.64"/><Loop id="idle" path="idle" frames="0" delay=".1"/></badeline_boss>
    </Sprites>'''
    (graphics/'Sprites.xml').write_text(xml)
    entries = [('characters/player/idle'+f'{i:02d}',i*4,0,4,4,-14,-25,32,32) for i in range(3)]
    entries += [('characters/player/bigfall00',0,0,4,4,-14,-25,32,128),
                ('characters/player/wakeUp/00',0,0,4,4,-14,-25,32,32),
                ('boss/idle00',0,0,4,4,-46,-57,96,96)]
    meta = struct.pack('<i',1)+bstring('synthetic')+struct.pack('<ih',0,1)+bstring('synthetic')+struct.pack('<h',len(entries))
    for name,*values in entries:
        meta += bstring(name)+struct.pack('<hhhhhhhh',*values)
    (atlas/'Gameplay.meta').write_bytes(meta)
    # Tiny RLE sheet, all four rows contain three independently colored cells.
    data = struct.pack('<iiB',12,4,1)
    for y in range(4):
        for i in range(3):
            data += bytes([4,255,40+i*20,70,150+i*20])
    (atlas/'synthetic.data').write_bytes(data)

def make_mod(root, xml, frames=(0,1,2)):
    graphics = root/'Graphics'; folder = graphics/'Atlases/Gameplay/mine'; folder.mkdir(parents=True)
    (graphics/'Sprites.xml').write_text(xml)
    for i in frames:
        im = Image.new('RGBA',(32,32)); im.paste((60,180,100,255),(14,24,18,28)); im.save(folder/f'idle{i:02d}.png')

class SkinLabTests(unittest.TestCase):
    def setUp(self):
        self.test_root = Path(__file__).resolve().parents[1]/'.test-temp'
        self.test_root.mkdir(exist_ok=True)
        self.root = self.test_root / ('case-'+uuid.uuid4().hex)
        self.root.mkdir()
        self.game = self.root/'game'; make_game(self.game)
        self.session = Session(self.root/'session')
        self.session.add_source(self.game,'Synthetic official','official')
        self.base = next(k for k,b in self.session.banks.items() if b['source']=='official' and b['name']=='player')

    def tearDown(self):
        self.assertTrue(self.root.resolve().is_relative_to(self.test_root.resolve()))
        shutil.rmtree(self.root)

    def test_sources_and_view_choices_survive_a_new_session(self):
        self.session.save_preferences({'base':self.base,'action':'recover','dash':'2','refs':[],'modpath':'D:/我的皮肤.zip'})
        reopened=Session(self.root/'session')
        self.assertIn(self.base,reopened.banks)
        self.assertEqual(reopened.catalog()['preferences']['action'],'recover')
        self.assertEqual(reopened.catalog()['preferences']['gamepath'],str(self.game.resolve()))
        self.assertEqual(reopened.catalog()['preferences']['modpath'],'D:/我的皮肤.zip')
        self.assertEqual(reopened.clip(self.base,'recover')['sequence'],[1,1,1,2,2])

    def test_preferences_cannot_be_used_to_write_arbitrary_state(self):
        before=self.session.state.copy()
        for value in [{'sources':[]},{'refs':['x']*13},{'gamepath':0}]:
            with self.assertRaises(ValueError):self.session.save_preferences(value)
        self.assertEqual(self.session.state,before)

    def test_repeats_crop_offsets_case_and_subfolder(self):
        clip = self.session.clip(self.base,'recover')
        self.assertEqual(clip['sequence'],[1,1,1,2,2])
        self.assertEqual(clip['delay'],.08)
        self.assertEqual(clip['goto'],'idle')
        self.assertEqual(clip['frames'][0]['alpha_bounds'],[14,25,18,29])
        self.assertFalse(self.session.clip(self.base,'bigFall')['missing_frames'])
        self.assertEqual(self.session.clip(self.base,'bigFall')['frames'][0]['size'],[32,128])
        self.assertFalse(self.session.clip(self.base,'wakeUp')['missing_frames'])

    def test_copy_falls_back_as_a_whole_not_mixed_frames(self):
        mod = self.root/'mod'; make_mod(mod,'<Sprites><my_player copy="player" path="mine/"/></Sprites>',frames=(0,2))
        sid = self.session.add_source(mod,'Synthetic mod','candidate')
        target = next(k for k,b in self.session.banks.items() if b['source']==sid)
        clip = self.session.clip(target,'idle')
        self.assertEqual(clip['fallback_indices'],[0,1,2])
        self.assertTrue(all(f['source']=='official' for f in clip['frames']))

    def test_explicit_missing_frame_is_hard_failure_even_when_approved(self):
        mod = self.root/'mod'; make_mod(mod,'<Sprites><my_player copy="player" path="mine/"><Loop id="idle" path="idle" frames="0-2" delay=".1"/></my_player></Sprites>',frames=(0,2))
        sid = self.session.add_source(mod,'Synthetic incomplete','candidate')
        target = next(k for k,b in self.session.banks.items() if b['source']==sid)
        key = self.base+'\n'+target+'\nidle'
        self.session.state['reviews'][key] = {'visual':'approved','deviation_approved':True,'reason':'Cannot waive a missing image'}
        row = next(r for r in self.session.audit(self.base,target)['rows'] if r['action']=='idle')
        self.assertEqual(row['missing_frames'],[1])
        self.assertFalse(row['static_contract_pass'])

    def test_boss_justify_is_not_player_bottom_anchor(self):
        boss = next(k for k,b in self.session.banks.items() if b['name']=='badeline_boss')
        frame = self.session.clip(boss,'idle')['frames'][0]
        self.assertEqual(frame['size'],[96,96])
        self.assertEqual(frame['origin'],[48,61.44])

    def test_no_source_files_modified_and_no_false_gameplay_pass(self):
        before = {p.relative_to(self.game):p.read_bytes() for p in self.game.rglob('*') if p.is_file()}
        report = self.session.audit(self.base,self.base)
        after = {p.relative_to(self.game):p.read_bytes() for p in self.game.rglob('*') if p.is_file()}
        self.assertEqual(before,after)
        self.assertTrue(report['static_pass'])
        self.assertFalse(report['visual_all_approved'])
        self.assertFalse(report['gameplay_tested'])

    def test_reject_nonempty_workspace_source_overlap_and_hostile_inputs(self):
        foreign = self.root/'foreign'; foreign.mkdir(); original=foreign/'keep.txt'; original.write_text('keep')
        with self.assertRaises(ValueError): Session(foreign)
        self.assertEqual(original.read_text(),'keep')
        with self.assertRaises(ValueError): self.session.add_source(self.root,'overlap','candidate')
        for bad in ('../secret.png','C:/secret.png','/secret.png'):
            with self.assertRaises(ValueError): safe_key(bad)
        with self.assertRaises(ValueError): parse_xml(b'<!DOCTYPE Sprites [<!ENTITY x SYSTEM "file:///secret">]><Sprites/>')

    def test_zip_outer_directory_and_traversal(self):
        mod = self.root/'mod'; make_mod(mod,'<Sprites><mine path="mine/"><Loop id="idle" path="idle" frames="0-2" delay=".1"/></mine></Sprites>')
        zipped = self.root/'good.zip'
        with zipfile.ZipFile(zipped,'w') as z:
            for p in mod.rglob('*'):
                if p.is_file(): z.write(p,'Outer/'+p.relative_to(mod).as_posix())
        source = Source('ref','Synthetic','reference',zipped).load()
        self.assertEqual(len(source.pngs),3)
        hostile = self.root/'bad.zip'
        with zipfile.ZipFile(hostile,'w') as z: z.writestr('../Graphics/Sprites.xml','<Sprites/>')
        with self.assertRaises(ValueError): Source('ref','Bad','reference',hostile).load()

    def test_sequence_rejects_malformed_or_unbounded_range(self):
        for bad in ('3-1','0*200000','x','-1'):
            with self.assertRaises(ValueError): frame_sequence(bad,{0,1})

    def test_old_visual_approval_expires_after_palette_change(self):
        signature = self.session.clip(self.base,'idle')['signature']
        key = self.base+'\n'+self.base+'\nidle'
        self.session.state['reviews'][key] = {'visual':'approved','base_signature':signature,'target_signature':signature}
        row = next(r for r in self.session.audit(self.base,self.base)['rows'] if r['action']=='idle')
        self.assertEqual(row['visual_review'],'approved')
        self.session.state['palettes'][self.base] = {'0':{'FFFFFF':'44B7FF'}}
        self.session.clips.clear()
        row = next(r for r in self.session.audit(self.base,self.base)['rows'] if r['action']=='idle')
        self.assertEqual(row['visual_review'],'stale')
        self.assertFalse(row['approval_matches_current_content'])

    def test_multiple_reference_packages_keep_separate_sources_and_friendly_choices(self):
        for index in range(2):
            mod=self.root/('reference-'+str(index))
            make_mod(mod,'<Sprites><hero path="mine/"><Loop id="idle" path="idle" frames="0-2" delay=".1"/></hero></Sprites>')
            (mod/'SkinModHelperConfig.yaml').write_text('- SkinName: Hero\n  Player_List: true\n  Character_ID: hero\n  SkinDialogKey: HeroTitle\n')
            (mod/'Dialog').mkdir();(mod/'Dialog/English.txt').write_text('HeroTitle= Example Wolf')
            self.session.add_source(mod,'Reference '+str(index),'reference')
        choices=[c for c in self.session.catalog()['choices'] if self.session.sources[c['source']].kind=='reference' and not c['internal'] and c['role']=='player']
        self.assertEqual(len(choices),2)
        self.assertEqual(len({c['source'] for c in choices}),2)
        self.assertTrue(all(c['label']=='Example Wolf · 玩家' for c in choices))
        self.session.save_preferences({'refs':[c['id'] for c in choices]})
        reopened=Session(self.root/'session')
        self.assertEqual(len(reopened.catalog()['sources']),3)
        self.assertEqual(len(reopened.state['preferences']['refs']),2)
        reopened.remove_source(choices[0]['source'])
        self.assertEqual(len(reopened.catalog()['sources']),2)

    def test_native_static_hair_anchor_and_body_are_separate(self):
        mod=self.root/'hair';make_mod(mod,'<Sprites><hero path="mine/"><Origin x="16" y="32"/><Loop id="idle" path="idle" frames="0" delay=".1"/><Metadata><Frames path="idle" hair="2,-3:1"/></Metadata><Loop id="runFast" path="idle" frames="0"/><Loop id="jumpSlow" path="idle" frames="0"/></hero></Sprites>')
        folder=mod/'Graphics/Atlases/Gameplay/mine'
        Image.new('RGBA',(10,10),'white').save(folder/'bangs01.png')
        sid=self.session.add_source(mod,'Hair anchor','candidate')
        key=next(k for k,b in self.session.banks.items() if b['source']==sid)
        frame=self.session.clip(key,'idle')['frames'][0]
        self.assertEqual(frame['bangs_offset'],[-3,-17])
        self.assertEqual(frame['bangs_bounds'],[-3,-17,10,10])
        self.assertEqual(frame['origin'],[16,32])
        self.assertNotEqual(frame['url'],frame['bangs']['url'])

    def test_dash_lut_is_read_and_changes_invalidate_review_signature(self):
        mod=self.root/'lut';make_mod(mod,'<Sprites><hero path="mine/"><Loop id="idle" path="idle" frames="0" delay=".1"/></hero></Sprites>')
        folder=mod/'Graphics/Atlases/Gameplay/mine/ColorGrading';folder.mkdir()
        Image.new('RGBA',(256,16),(30,180,250,255)).save(folder/'dash0.png')
        sid=self.session.add_source(mod,'LUT','candidate');key=next(k for k,b in self.session.banks.items() if b['source']==sid)
        clip=self.session.clip(key,'idle','0');signature=clip['signature']
        image=Image.open(self.session.path/clip['frames'][0]['url'].lstrip('/'))
        self.assertEqual(image.getpixel((14,24)),(30,180,250,255))
        Image.new('RGBA',(256,16),(240,40,70,255)).save(folder/'dash0.png')
        self.session.reload()
        self.assertNotEqual(signature,self.session.clip(key,'idle','0')['signature'])

    def test_fixed_playback_lut_runs_after_recording_tint(self):
        mod=self.root/'post-tint';make_mod(mod,'<Sprites><hero path="mine/"><Loop id="idle" path="idle" frames="0" delay=".1"/></hero></Sprites>')
        folder=mod/'Graphics/Atlases/Gameplay/mine'
        (folder/'ColorGrading').mkdir();(folder/'skinConfig').mkdir()
        (folder/'skinConfig/CharacterConfig.yaml').write_text('SilhouetteMode: true\nColorGradingAfterColored: true\nColorGrade_Path: mine/ColorGrading/playback\n')
        lut=Image.new('RGBA',(256,16),(0,0,0,255))
        # Source (60,180,100) * native red (172,50,50) -> LUT cell (2,2,1).
        lut.putpixel((2+16,2),(245,45,87,255));lut.save(folder/'ColorGrading/playback.png')
        sid=self.session.add_source(mod,'Playback','candidate');key=next(k for k,b in self.session.banks.items() if b['source']==sid)
        clip=self.session.clip(key,'idle','1')
        image=Image.open(self.session.path/clip['frames'][0]['url'].lstrip('/'))
        self.assertEqual(image.getpixel((14,24)),(245,45,87,255))
        self.assertTrue(clip['preview_effects']['after_colored'])
        self.assertEqual(clip['preview_effects']['lut'],'mine/ColorGrading/playback')

if __name__ == '__main__':
    unittest.main()
