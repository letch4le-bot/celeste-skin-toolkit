// Check the production drawing helper without browser automation or game artwork.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const text=fs.readFileSync(path.join(__dirname,'../web/precision.js'),'utf8');
const source=text.split('\n').find(s=>s.startsWith('function hollowCells('));
const context={};vm.createContext(context);vm.runInContext(source,context);
for(const [rect,count] of [[[-4,-11,8,11],34],[[-4,-11,8,9],30],[[-4,-6,8,6],24],[[-4,-6,8,4],20]]){
  const cells=new Set(),[x0,y0,w,h]=rect;
  context.hollowCells({fillRect(x,y,width,height){for(let yy=y;yy<y+height;yy++)for(let xx=x;xx<x+width;xx++)cells.add(xx+','+yy)}},rect,'#ff0000');
  assert.equal(cells.size,count);
  for(const cell of cells){const[x,y]=cell.split(',').map(Number);assert(x>=x0&&x<x0+w&&y>=y0&&y<y0+h)}
  assert(cells.has((x0+w-1)+','+(y0+h-1)));assert(!cells.has((x0+w)+','+(y0+h)));
}
console.log('TAS / Monocle occupied-cell outlines verified for 4 reference boxes.');

// Exercise production guides, including overlap: green terrain box, red hurtbox.
const controls={hitbox:{checked:true},hurtbox:{checked:true},bounds:{checked:false},wall:{checked:false},anchor:{checked:false}};
const guideContext={$:id=>controls[id],isPlayer:()=>true,profile:()=>({hitbox:[-4,-11,8,11],hurtbox:[-4,-11,8,9]}),extent:{x:0,y:0}};
vm.createContext(guideContext);
vm.runInContext(source+'\n'+text.slice(text.indexOf('function guides('),text.indexOf('\ndraw=function')),guideContext);
const colors=new Map(),g={save(){},restore(){},translate(){},fillRect(x,y,w,h){for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)colors.set(xx+','+yy,this.fillStyle)}};
guideContext.guides(g,{},null,1);
assert.equal(colors.get('-4,-1'),'#00ff00');
assert.equal(colors.get('-4,-11'),'#ff0000');
assert.equal(colors.get('3,-3'),'#ff0000');
console.log('Production collision/hurtbox colors and overlapping edges verified.');
