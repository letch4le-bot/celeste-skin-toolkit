"""Pose import, immutable snapshots and scoped human records, using synthetic art."""
import base64,io,json,sys,unittest
from pathlib import Path
from PIL import Image
import test_skinlab as fixtures

class WorkflowTests(unittest.TestCase):
    setUp=fixtures.SkinLabTests.setUp
    tearDown=fixtures.SkinLabTests.tearDown
    def test_png_requires_explicit_origin_and_survives_reload(self):
        path=self.root/'single.png';im=Image.new('RGBA',(32,32),(20,30,40,255));im.save(path);before=path.read_bytes()
        for origin in [None,[1.5,2],[True,2],[0,5000]]:
            with self.assertRaises(ValueError):self.session.add_source(path,'PNG','candidate',origin)
        sid=self.session.add_source(path,'PNG','candidate',[16,32]);key=next(k for k,b in self.session.banks.items() if b['source']==sid)
        self.session.reload();clip=self.session.clip(key,'pose')
        self.assertEqual(clip['frames'][0]['origin'],[16,32]);self.assertEqual(clip['unique_image_count'],1)
        self.assertEqual(self.session.catalog()['sources'][-1]['png_origin'],[16,32]);self.assertEqual(path.read_bytes(),before)

    def test_snapshot_is_immutable_and_never_auto_approves(self):
        out=io.BytesIO();Image.new('RGBA',(3,4),(10,20,30,255)).save(out,format='PNG')
        row=self.session.save_baseline({'png':'data:image/png;base64,'+base64.b64encode(out.getvalue()).decode(),'origin':[1,4],'label':'test'})
        asset=self.session.path/row['url'].lstrip('/');before=asset.read_bytes()
        self.session.reload();self.assertEqual(asset.read_bytes(),before)
        self.assertEqual(self.session.state['confirmations'],[])
        self.assertEqual(self.session.state['baselines'][0]['origin'],[1,4])

    def test_confirmation_scopes_and_changed_data_are_distinct(self):
        common={'target':self.base,'action':'idle','position':0,'visual':'approved','dash':'1'}
        with self.assertRaises(ValueError):self.session.save_confirmation(dict(common,scope='gameplay'))
        for scope in ['pose','animation','gameplay']:
            self.session.save_confirmation(dict(common,scope=scope,reason='Synthetic manual record, no actual gameplay'))
        self.assertEqual([r['scope'] for r in self.session.state['confirmations']],['pose','animation','gameplay'])
        self.assertFalse(self.session.audit(self.base,self.base)['gameplay_tested'])
        previous=self.session.state['confirmations'][0]['signature']
        bank=self.session.banks[self.base]['node'];bank.find('Loop').set('delay','.3');self.session.clips.clear()
        self.assertNotEqual(self.session.clip(self.base,'idle')['signature'],previous)
        self.assertEqual(self.session.state['confirmations'][0]['signature'],previous)
        with self.assertRaises(ValueError):self.session.save_confirmation(dict(common,scope='pose',position=10000))

    def test_counts_do_not_remove_repeated_positions(self):
        clip=self.session.clip(self.base,'recover')
        self.assertEqual(clip['sequence'],[1,1,1,2,2]);self.assertEqual(clip['unique_image_count'],2)
        self.assertEqual(len(clip['frames']),5);self.assertEqual(clip['delay'],.08)

    def test_overlay_colors_persist_and_reject_invalid_values(self):
        from skinlab import Session
        self.session.save_preferences({'nativecolor':'#ff9900','skincolor':'#22bbcc'})
        reopened=Session(self.root/'session')
        self.assertEqual(reopened.catalog()['preferences']['nativecolor'],'#ff9900')
        before=(self.root/'session/session.json').read_bytes()
        with self.assertRaises(ValueError):self.session.save_preferences({'nativecolor':'red;bad'})
        self.assertEqual((self.root/'session/session.json').read_bytes(),before)

    def test_all_seven_previous_player_group_omissions_are_classified(self):
        from skinlab import GROUPS
        grouped={a for ids in GROUPS.values() for a in ids}
        self.assertTrue({'lookUp','slide','tired','tiredStill','climbLookBack','flip','shaking'} <= grouped)
        role_groups=self.session.catalog()['role_groups']
        self.assertIn('badeline_boss',role_groups)
        self.assertIn('badelineBoost',role_groups)

    def test_browser_png_batch_is_local_and_survives_reload(self):
        from skinlab import Session
        out=io.BytesIO();Image.new('RGBA',(32,32),(20,30,40,255)).save(out,format='PNG')
        encoded='data:image/png;base64,'+base64.b64encode(out.getvalue()).decode()
        ids=self.session.add_pngs([dict(name='../../任意姿势.png',png=encoded)], [16,32])
        self.assertEqual(len(ids),1)
        saved=self.session.state['sources'][-1]
        self.assertEqual(saved['label'],'任意姿势.png')
        self.assertEqual(Path(saved['path']).parent,self.session.path/'imports')
        reopened=Session(self.session.path)
        self.assertFalse(reopened.errors)
        key=next(k for k,b in reopened.banks.items() if b['source']==ids[0])
        self.assertEqual(reopened.clip(key,'pose')['frames'][0]['origin'],[16,32])
        # Direct source imports cannot bypass the owned-session path guard.
        with self.assertRaises(ValueError):reopened.add_source(saved['path'],'bypass','reference',[16,32])

    def test_png_batch_validation_keeps_existing_sources_and_art(self):
        path=self.root/'arbitrary.png';Image.new('RGBA',(32,32),(10,20,30,255)).save(path)
        before=path.read_bytes();state=self.session.state_file.read_bytes()
        with self.assertRaises(Exception):self.session.add_pngs([dict(path=str(path)),dict(name='broken.png',png='data:image/png;base64,eA==')],[16,32])
        self.assertEqual(self.session.state_file.read_bytes(),state)
        self.assertEqual(path.read_bytes(),before)
        self.assertFalse((self.session.path/'imports').exists())
        for origin in [None,[True,9],[1.5,9]]:
            with self.assertRaises(ValueError):self.session.add_pngs([dict(path=str(path))],origin)
        ids=self.session.add_pngs([dict(path=str(path)),dict(path=str(path))],[16,32])
        self.assertEqual(len(ids),1)
        self.assertEqual(self.session.state['sources'][-1]['path'],str(path.resolve()))
        self.assertFalse(self.session.state['sources'][-1].get('imported_png'))
        Image.new('RGBA',(32,32),(100,110,120,255)).save(path);self.session.reload()
        self.assertNotEqual(self.session.sources[ids[0]].hashes['Graphics/Atlases/Gameplay/single/pose00.png'],__import__('hashlib').sha256(before).hexdigest())

if __name__=='__main__':
    import unittest
    unittest.main()
