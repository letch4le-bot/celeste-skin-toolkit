const assert=require('node:assert/strict');
const {referenceDisplay,clipDuration,playPosition,advanceClock}=require('../web/preview-core.js');
const {actionGroups}=require('../web/preview-core.js');
const grouped=actionGroups([{role:'badeline',actions:['walk','lookout/looking']}],{}, {badeline:'Badeline · 剧情'});
assert.deepEqual(grouped.groups['望远镜'],['lookout/looking']);
assert.deepEqual(grouped.groups['Badeline · 剧情'],['walk']);
assert.deepEqual(referenceDisplay(1024,720,8),{scale:.25,width:256,height:180,gridVisible:false});
assert.equal(referenceDisplay(1024,720,8,true).width,1024);
assert.deepEqual(referenceDisplay(10,10,8),{scale:25.6,width:256,height:256,gridVisible:true});
assert.equal(referenceDisplay(160,160,16).gridVisible,true);
assert.equal(referenceDisplay(160,160,8).gridVisible,false);
for(const size of [[32,32],[160,160],[1024,720],[720,1024],[8192,1]]){
 for(const z of [2,3,4,6,8,12,16]){const v=referenceDisplay(...size,z);assert.equal(Math.max(v.width,v.height),32*z);assert.ok(Math.min(v.width,v.height)>=1)}
}
const clip={frames:[0,1,2,3],delay:.1,frame_durations:[.06,.06,.2,4.68]};
assert.equal(clipDuration(clip),5);
assert.equal(playPosition({manual:false,time:.12,repeat:false},clip),2);
assert.equal(playPosition({manual:false,time:4.9,repeat:false},clip),3);
assert.equal(playPosition({manual:false,time:5.01,repeat:true},clip),0);
assert.equal(playPosition({manual:true,index:1,time:4.9,repeat:true},clip),1);
const c={time:4.95,run:true,repeat:false,manual:false,index:0};advanceClock(c,clip,.1,1);assert.equal(c.run,false);assert.equal(c.index,3);
console.log('Arbitrary-size normalization, grid density and variable XML frame timing passed.');
