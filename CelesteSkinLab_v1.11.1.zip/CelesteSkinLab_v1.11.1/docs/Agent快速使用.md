# Agent 快速使用

先定位当前工具根目录：其中有 `皮肤动作对照.exe`、`tools/` 和 `runtime/`。以下命令都在这个目录运行，使用工具自带 Python。

## 从当前制作任务开始

1. 默认打开 `皮肤动作对照.exe`，加载用户的 Celeste 目录，选择原版角色用途。也可以加载参考皮肤 ZIP 或文件夹作并排对照。
2. 从第一张 32×32 像素小样起就放入独立图片区，与原版待机比较。开始做动作后，加载含 `Graphics/Sprites.xml` 和当前图片的皮肤工作目录，用途选“我的皮肤”。首次建最小目录的方法见教程包的 Agent 第 03 章。
3. 选好“我的皮肤包”“角色与用途”和动作，与原版对应动作完整播放、逐帧对照。修改文件后点“重新读取”，核实当前加载的是本轮工作目录。
4. 用“当前动作备注”记录用户实际采用的范围；用“检查资源与播放数据”生成自动报告。报告保存在当前会话的 `reports/`。

临时换帧只改变播放副本。用户采用后，要把结果落实到工作目录的 PNG 和 XML，再点“重新读取”确认。

## 桌面与命令行使用同一会话

桌面版保存到当前工具目录的 `data/session/`。需要读已加载角色或生成同一份报告时，CLI 的 `--session` 指向这个目录。换一个空目录会得到另一份空会话。

查看已加载的动画定义：

```powershell
.\runtime\python\python.exe -X utf8 .\tools\skinlab.py catalog --session .\data\session
```

按界面选角色做检查时，从 `catalog` 里取对应条目的 `choices[].bank`，将完整值传给 `--base` 和 `--target`（注意不要取 `id`，`choices[].bank` 包含望远镜等已合并动作的虚拟 bank 键值）：

```powershell
.\runtime\python\python.exe -X utf8 .\tools\skinlab.py audit --session .\data\session --base 'official|Content/Graphics/Sprites.xml|player' --target '来源ID|Graphics/Sprites.xml|MySkinPlayer'
```

上面 `--base` 与 `--target` 的参数请直接替换为当前 `catalog` 中对应角色的 `choices[].bank` 完整值。

## 在浏览器里打开工具

桌面版已启动时，读取当前工具目录的 `data/server-address.txt`，在可操作的浏览器打开该地址（或点窗口上方的“在浏览器打开”）。它和桌面窗口共用同一会话，无需再启动一个服务。

未使用桌面版时，可以直接启动网页服务：

```powershell
.\runtime\python\python.exe -X utf8 .\tools\skinlab.py serve --session .\data\session --port 8766
```

终端显示 `Celeste Skin Lab 1.11.1 http://127.0.0.1:8766` 后即可打开页面。服务运行时保持该进程；端口占用时改用其他 `--port`，不要关闭用户其他服务，也不要同时启动两个进程写同一个会话。

## 界面入口与常用 API

- **头像与死亡粒子**：默认显示。头像在“状态”里切换说话、停嘴、开场与眨眼，每次播放一轮实际帧；无专用说话帧的动作（如 `sleep`）直接显示待机。电话头像按分组选择。死亡粒子可看粒子原图，也能预览按原版行为采样的八方向散开效果（约 0.834 秒）。
- **望远镜与隐藏实体**：选好角色后，在动作分组中选“望远镜”，动作 ID 带 `lookout/` 前缀（已合并在 `catalog` 返回的角色 bank 中）；未替换时标明原版回退。点播放条右侧的“点我显示隐藏动作”，可勾选查看交互实体、泡泡、冲刺水晶和草莓。
- **固定参考图与临时换帧**：固定参考图支持不同尺寸，默认显示长边为 `32 * zoom`，勾选“原始尺寸”按 1× 查看；临时换帧要求 32×32 静态图。
- **常用接口**：
  - 导入图片：`POST /api/pngs`，在 JSON 请求体中传入 `"files"`，并设置 `"mode": "reference"`（固定参考图）或 `"mode": "frame"`（临时换帧，需同时传 `"origin": [16, 32]`）。
  - 读取动作与头像片段：`/api/clip` 的 `portrait_mode` 可选 `talk`、`idle`、`begin` 或 `available_states` 返回的分支值，按 `frame_durations` 播放；死亡粒子动作为 `particle`（原图）或 `scatter`（散开效果）。
  - 重新读取与检查：`POST /api/reload` 重新读取已加载源；`POST /api/audit` 生成资源与播放数据检查报告。

## 怎样理解检查结果

`resource_pass` 表示当前动画定义覆盖范围内的资源检查通过；播放数据差异单独列出，结合当前设计判断。`static_pass` 是兼容字段；`visual_all_approved` 表示逐动作记录齐全；`gameplay_tested` 固定为 `false`，实际游戏表现仍需进测试地图验证。可选的 `idleA/idleB/idleC` 不纳入全动作自动对照，按用户需求决定是否制作。

底层解析规则、冲刺配色映射、预览边界与故障排查见[开发说明](开发说明.md)；旧版本调整见[历史维护记录](历史维护记录.md)。
