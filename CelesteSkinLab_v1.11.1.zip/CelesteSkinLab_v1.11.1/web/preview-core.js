'use strict';
(function(root){
  function actionGroups(entries, groups, roleGroups={}, entityGroups={}) {
    const actual=[...new Set(entries.flatMap(e=>e.actions||[]))];
    const result={};
    for(const [name,ids] of Object.entries(groups)){
      const found=new Set(entries.filter(e=>!roleGroups[e.role]&&!entityGroups[e.role]).flatMap(e=>(e.actions||[]).filter(a=>ids.includes(a))));
      const rows=actual.filter(a=>found.has(a));if(rows.length)result[name]=rows;
    }
    for(const e of entries){
      if(entityGroups[e.role]){for(const[name,ids]of Object.entries(entityGroups[e.role])){const matched=(e.actions||[]).filter(a=>ids.includes(a));if(matched.length){const rows=result[name]||(result[name]=[]);for(const a of matched)if(!rows.includes(a))rows.push(a)}}}
      else {const name=roleGroups[e.role];if(name){const rows=result[name]||(result[name]=[]);for(const a of e.actions||[])if(!rows.includes(a))rows.push(a)}}
    }
    const lookout=actual.filter(a=>a.startsWith('lookout/'));if(lookout.length){for(const name of Object.keys(result))result[name]=result[name].filter(a=>!lookout.includes(a));result['望远镜']=lookout;}
    const covered=new Set(Object.values(result).flat());const other=actual.filter(a=>!covered.has(a));
    if(other.length)result['其他']=other;
    return {actions:actual,groups:result};
  }
  function playbackEntries(entries){const animated=entries.filter(e=>e.role!=='pose');return animated.length?animated:entries}
  function replacedClip(original, replacements){
    const frames=original.frames.map((f,j)=>replacements.get(j)?.frame||f);
    return {...original,frames,unique_image_count:new Set(frames.map(f=>f.url||f.raw_sha256||JSON.stringify(f))).size};
  }
  function replacementPositions(start,count,total){
    if(!Number.isInteger(start)||!Number.isInteger(count)||start<0||count<1||start+count>total)throw Error('替换位置超出动作范围，请调整起始位置或少选几张图片。');
    return Array.from({length:count},(_,i)=>start+i);
  }
  function frameExtent(frames){
    let left=-8,right=8,top=-14,bottom=0;
    for(const f of frames){if(!f.size||!f.origin)continue;left=Math.min(left,-f.origin[0]);right=Math.max(right,f.size[0]-f.origin[0]);top=Math.min(top,-f.origin[1]);bottom=Math.max(bottom,f.size[1]-f.origin[1]);
      if(f.bangs_bounds){const[x,y,w,h]=f.bangs_bounds;left=Math.min(left,x-1);right=Math.max(right,x+w+1);top=Math.min(top,y-1);bottom=Math.max(bottom,y+h+1)}}
    const radius=Math.max(-left,right);return{x:Math.ceil(radius+4),y:Math.ceil(-top+4),w:Math.ceil(radius*2+8),h:Math.ceil(bottom-top+8)};
  }
  function clipDuration(clip){return clip.frame_durations?clip.frame_durations.reduce((a,b)=>a+b,0):clip.frames.length*(clip.delay>0?clip.delay:.1)}
  function referenceDisplay(w,h,zoom,native=false){const scale=native?1:32*zoom/Math.max(w,h);return{scale,width:Math.max(1,Math.round(w*scale)),height:Math.max(1,Math.round(h*scale)),gridVisible:scale>=3}}
  function playPosition(clock,clip){
    const n=clip.frames.length;if(!n)return 0;
    if(clock.manual)return Math.max(0,Math.min(n-1,clock.index));
    if(clip.frame_durations){const duration=clipDuration(clip);let t=clock.repeat?clock.time%duration:Math.min(clock.time,duration-1e-8);for(let i=0;i<n;i++){if(t<clip.frame_durations[i]-1e-8)return i;t-=clip.frame_durations[i]}return n-1}
    const j=Math.floor(clock.time/(clip.delay>0?clip.delay:.1)+1e-6);return clock.repeat?j%n:Math.min(n-1,j);
  }
  function advanceClock(clock,clip,dt,speed){
    if(!clock.run)return;
    clock.time+=Math.min(.1,Math.max(0,dt))*speed;
    if(!clock.repeat&&clock.time>=clipDuration(clip)){
      clock.run=false;clock.manual=true;clock.index=Math.max(0,clip.frames.length-1);
    }
  }
  const api={clipDuration,referenceDisplay,actionGroups,playbackEntries,replacedClip,replacementPositions,frameExtent,playPosition,advanceClock};
  if(typeof module!=='undefined')module.exports=api;Object.assign(root,api);
})(globalThis);
