'use strict';
// Real file drops and the accessible file picker share the same import path.
const dropZones=new Map(),pendingDrops=new Map();let dropSerial=0,dropQueue=Promise.resolve();
function dropStatus(zone,text,error=false){zone.message.textContent=text;zone.message.classList.toggle('error',error)}
function dropOrigin(){return[16,32]}
function makeDropZone(id,title,mode){
 const box=document.createElement('section');box.className='png-drop-zone';box.id=id;box.setAttribute('aria-label',title);
 box.innerHTML=`<strong>${title}</strong><span class="muted">${mode==='reference'?'任意尺寸静态图片 · 默认适配显示':'仅32×32静态图片 · 对齐点 (16,32)'}</span><div class="form"><button type="button">选择图片</button><input type="file" accept="image/png,image/jpeg,image/webp,image/bmp,image/gif,.png,.jpg,.jpeg,.webp,.bmp,.gif" multiple hidden></div><p class="muted drop-hint"></p><p class="drop-message" role="status" aria-live="polite"></p>`;
 const zone={id,mode,box,input:box.querySelector('input'),button:box.querySelector('button'),message:box.querySelector('.drop-message')};
 box.querySelector('.drop-hint').textContent=window.chrome?.webview?.postMessageWithAdditionalObjects?'从资源管理器拖到这里。记住原路径，改图后点“重新读取”。':'从资源管理器拖到这里。浏览器保存本地副本，改图后请重新拖入。';
 zone.button.onclick=()=>zone.input.click();zone.input.onchange=()=>{enqueueDrop(zone,[...zone.input.files]);zone.input.value=''};
 dropZones.set(id,zone);return zone;
}
const referenceDrop=makeDropZone('png-drop-reference','拖入图片作固定参考','reference');$('setup').before(referenceDrop.box);referenceDrop.box.insertAdjacentHTML('beforeend','<details class="origin-help"><summary>原点是什么？</summary><div class="origin-example"><svg viewBox="0 0 180 176" width="180" height="176" role="img" aria-label="32乘32图片，左上角为0,0，底边中央的原点为16,32"><rect x="25" y="16" width="128" height="128" fill="#dce5eb" stroke="#6c9ab8"/><path d="M89 30V144M25 144H153" stroke="#8ba5b6" stroke-dasharray="3 3"/><path d="M79 144H99M89 134V154" stroke="#20a56e" stroke-width="2"/><text x="27" y="11" fill="currentColor" font-size="12">左上 (0,0)</text><text x="45" y="169" fill="currentColor" font-size="12">原点 (16,32)</text></svg><p>原点是图片上用来对齐角色位置的那个点，画面中的十字就是它。<br>例如 32×32 图片填 (16,32)，就是把图片底边中央对齐十字。人物跳起、坐下时，在图内改变姿势，原点仍保持一致。</p></div></details>');
const frameDrop=makeDropZone('png-drop-frame','拖入图片作换帧图片','frame');$('copy-images').closest('.form').before(frameDrop.box);
function dataURL(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('图片读取失败：'+file.name));reader.readAsDataURL(file)})}
async function finishDrop(zone,files,origin,retainedPath){
 const result=await api('/api/pngs',{files,origin,mode:zone.mode});await refresh();
 const ids=result.ids.map(id=>preferred(id,'pose')?.id).filter(Boolean);
 if(zone.mode==='reference'){
  for(const id of ids)if(!refs.includes(id))refs.push(id);
  updateActions();await loadClips();
 }else{
  fillCopyImages();for(const o of $('copy-images').options)o.selected=ids.includes(o.value);
 }
 savePreferences();dropStatus(zone,`已加入 ${ids.length} 张${zone.mode==='reference'?'固定参考图':'换帧图片'}。`+(retainedPath?'改图后可点“重新读取”。':'改图后请重新拖入。'));
}
function enqueueDrop(zone,files){
 dropQueue=dropQueue.catch(()=>{}).then(async()=>{
  zone.button.disabled=true;try{
   const origin=dropOrigin(zone);
   if(!files.length||files.length>32)throw Error('每次可拖入1至32张图片。');
   if(files.some(f=>! /\.(png|jpe?g|webp|bmp|gif)$/i.test(f.name)))throw Error('这里接收PNG、JPG/JPEG、WebP、BMP和静态GIF；ZIP和文件夹请使用“加载游戏与皮肤”。');
   if(files.some(f=>f.size>2_000_000)||files.reduce((n,f)=>n+f.size,0)>8_000_000)throw Error('单张图片最多2MB，一次最多8MB。');
   if(zone.mode==='reference'&&refs.length+files.length>12)throw Error('对照栏最多12张，请少选几张或先移除旧对照栏。');
   dropStatus(zone,'正在导入 '+files.length+' 张图片…');
   if(window.chrome?.webview?.postMessageWithAdditionalObjects){
    const requestId=String(++dropSerial);
    await new Promise((resolve,reject)=>{
     pendingDrops.set(requestId,{zone,origin,files,resolve,reject});
     try{window.chrome.webview.postMessageWithAdditionalObjects(JSON.stringify({type:'drop-png',requestId}),files)}catch(e){pendingDrops.delete(requestId);reject(e)}
    });
   }else await finishDrop(zone,await Promise.all(files.map(async file=>({name:file.name,png:await dataURL(file)}))),origin,false);
  }catch(e){dropStatus(zone,e.message,true)}finally{zone.button.disabled=false}
 });return dropQueue;
}
if(window.chrome?.webview)window.chrome.webview.addEventListener('message',async e=>{
 const data=e.data;if(data.type!=='dropped-png-paths')return;const pending=pendingDrops.get(data.requestId);if(!pending)return;pendingDrops.delete(data.requestId);
 try{if(data.error)throw Error(data.error);if(!Array.isArray(data.paths)||data.paths.length!==pending.files.length)throw Error('没有取得拖入图片的路径，请重新拖入。');await finishDrop(pending.zone,data.paths.map(path=>({path})),pending.origin,true);pending.resolve()}catch(error){pending.reject(error)}
});
function draggedFiles(event){return [...(event.dataTransfer?.types||[])].includes('Files')}
document.addEventListener('dragover',event=>{
 if(!draggedFiles(event))return;event.preventDefault();
 const box=event.target.closest?.('.png-drop-zone');for(const zone of dropZones.values())zone.box.classList.toggle('drag-over',zone.box===box);
 event.dataTransfer.dropEffect=box?'copy':'none';
});
document.addEventListener('dragleave',event=>{if(!event.relatedTarget)for(const zone of dropZones.values())zone.box.classList.remove('drag-over')});
document.addEventListener('drop',event=>{
 if(!draggedFiles(event))return;event.preventDefault();for(const zone of dropZones.values())zone.box.classList.remove('drag-over');
 const box=event.target.closest?.('.png-drop-zone'),zone=box&&dropZones.get(box.id);
 if(zone)enqueueDrop(zone,[...event.dataTransfer.files]);else say('把图片拖到“固定参考”或“换帧图片”区域。',true);
});
