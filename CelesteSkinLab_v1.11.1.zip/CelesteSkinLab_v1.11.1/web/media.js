'use strict';
// Portraits, particles and fixed reference images use bounded display sizes.
const mediaNative=new Set();let mediaNativeLoaded=false;
const portraitControl=document.createElement('label');portraitControl.id='portrait-controls';portraitControl.hidden=true;
portraitControl.innerHTML='状态<select id="portrait-mode"><option value="talk">说话</option><option value="idle">停嘴</option></select>';
$('action').closest('label').after(portraitControl);fields.push('portrait-mode');
const mediaAPI=api;
api=async function(path,payload){
 if(path.startsWith('/api/clip?'))path+='&portrait_mode='+encodeURIComponent($('portrait-mode').value||'talk');
 const data=await mediaAPI(path,payload);if(path.startsWith('/api/clip?')&&data.particle_frame?.url)await image(data.particle_frame.url);return data;
};
$('portrait-mode').onchange=()=>{loadClips();savePreferences()};
const mediaActionLabel=actionLabel;
const expressionLabels={normal:'普通',peaceful:'平静',angry:'生气',deadpan:'无语',sad:'难过',sadder:'更难过',upset:'不安',surprised:'惊讶',distracted:'走神',determined:'坚定',determinedclosed:'闭眼坚定',panic:'惊慌',together:'合体',togetherZoom:'合体推近',sleep:'睡觉'};
actionLabel=function(action){
 if(action.startsWith('lookout/'))return lookoutLabels[action.slice(8)]||labels[action.slice(8)]||action.slice(8);
 if(action==='scatter')return '散开效果';if(action==='particle')return '粒子原图';
 if(action.startsWith('portrait_')){const a=action.split('/').slice(1).join('/');return a.startsWith('@')?a.slice(1):expressionLabels[a]||a}
 return mediaActionLabel(action);
};
function mediaCard(t){return ['pose','portraits','death_particle'].includes(t.c.role)}
const mediaBuildCards=buildCards;
buildCards=function(){
 mediaBuildCards();if(!mediaNativeLoaded){try{for(const id of JSON.parse(catalog.preferences?.nativecards||'[]'))mediaNative.add(id)}catch{}mediaNativeLoaded=true}
 portraitControl.hidden=!clips.some(t=>t.c.role==='portraits');
 const states=new Map(clips.filter(t=>t.clip.portrait).flatMap(t=>(t.clip.available_states||[]).map(s=>[s.value,s.label])));
 portraitControl.hidden=!states.size;
 if(states.size){const previous=$('portrait-mode').value;$('portrait-mode').replaceChildren();for(const[v,label]of states)option($('portrait-mode'),label,v);$('portrait-mode').value=states.has(previous)?previous:clips.find(t=>t.clip.portrait)?.clip.portrait_mode||states.keys().next().value}
 copyPanel.hidden=clips.some(t=>['portraits','death_particle'].includes(t.c.role));
 for(const t of clips){
  if(!mediaCard(t))continue;
  const section=t.canvas.closest('.card');section.classList.add('media-card');
  if(t.mini&&t.c.role==='pose'&&Math.max(...(t.c.size||[0]))>256)t.mini.parentElement.style.display='none';
  const label=document.createElement('label');label.className='native-size-toggle';
  const check=document.createElement('input');check.type='checkbox';check.checked=mediaNative.has(t.id);check.setAttribute('aria-label',t.c.label+' 原始尺寸');
  label.append(check,document.createTextNode('原始尺寸'));section.querySelector('.card-tools').append(label);
  check.onchange=()=>{if(check.checked)mediaNative.add(t.id);else mediaNative.delete(t.id);draw();api('/api/preferences',{nativecards:JSON.stringify([...mediaNative])}).catch(e=>say(e.message,true))};
  t.canvas.onmousemove=e=>{
   const[f]=selectedFrame(t.clip);if(!f||!t.mediaView)return;const r=t.canvas.getBoundingClientRect(),v=t.mediaView;
   const x=Math.floor((e.clientX-r.left)/r.width*v.w-v.x+f.origin[0]),y=Math.floor((e.clientY-r.top)/r.height*v.h-v.y+f.origin[1]);
   t.readout.textContent=`原图像素 (${x}, ${y}) · ${f.size.join('×')}`;
  };
 }
};
computeExtent=function(){const frames=clips.filter(t=>!mediaCard(t)).flatMap(t=>t.clip.frames);extent=frameExtent(frames)};
const mediaSelected=selectedFrame;
const mediaIsPlayer=isPlayer;
isPlayer=t=>!t.clip.lookout&&mediaIsPlayer(t);
selectedFrame=function(clip){
 if(!clip.frame_durations)return mediaSelected(clip);
 const j=playPosition({manual:manualSeeking,index:manualIndex,time,repeat},clip);return[clip.frames[j]||null,j];
};
function mediaExtent(t){
 let left=0,right=0,top=0,bottom=0;
 for(const f of t.clip.frames){if(!f.size)continue;left=Math.min(left,-f.origin[0]);right=Math.max(right,f.size[0]-f.origin[0]);top=Math.min(top,-f.origin[1]);bottom=Math.max(bottom,f.size[1]-f.origin[1])}
 return{x:-left,y:-top,w:Math.max(1,right-left),h:Math.max(1,bottom-top)};
}
function paintMedia(t){
 const[f,j]=selectedFrame(t.clip),c=t.canvas,v=mediaExtent(t),native=mediaNative.has(t.id);
 const geometry=referenceDisplay(v.w,v.h,+$('zoom').value,native),scale=geometry.scale;t.mediaView=v;
 c.width=geometry.width;c.height=geometry.height;c.style.width=c.width+'px';c.style.height=c.height+'px';
 const g=c.getContext('2d');g.imageSmoothingEnabled=false;
 const dark=$('bg').value==='dark';g.fillStyle=dark?'#163042':'#dce5eb';g.fillRect(0,0,c.width,c.height);
 if($('bg').value==='check'){g.fillStyle='#bdcbd4';for(let y=0;y<c.height;y+=16)for(let x=0;x<c.width;x+=16)if((x/16+y/16)%2)g.fillRect(x,y,16,16)}
 if(f?.url){
  g.save();g.scale(scale,scale);g.translate(v.x,v.y);g.scale(+$('facing').value,1);g.drawImage(images.get(f.url),-f.origin[0],-f.origin[1]);g.restore();
  // One source pixel per cell. Do not replace it with a coarser fake grid.
  if($('grid').checked&&scale>=3){
   g.save();g.strokeStyle=dark?'#94a9b755':'#3e596855';g.lineWidth=1;g.beginPath();
   for(let x=0;x<=f.size[0];x++){const px=(v.x-f.origin[0]+x)*scale;g.moveTo(px,0);g.lineTo(px,c.height)}
   for(let y=0;y<=f.size[1];y++){const py=(v.y-f.origin[1]+y)*scale;g.moveTo(0,py);g.lineTo(c.width,py)}g.stroke();g.restore();
  }
 }
 if(t.mini){
  const mini=t.clip.particle_frame||f;if(mini?.url){const im=images.get(mini.url);if(im){t.mini.width=im.width;t.mini.height=im.height;t.mini.getContext('2d').drawImage(im,0,0)}}
 }
 const phase=f?.portrait_phase==='begin'?'开场':f?.talking?'说话':'停嘴';
 t.status.textContent=t.clip.missing_action?'没有这个表情／动作':t.c.role==='pose'?'固定参考图':t.clip.portrait?`${phase} · ${f?.portrait_animation||''}\n位置 ${j+1} / ${t.clip.frames.length} · ${run?'播放中':'已暂停'}`:`位置 ${j+1} / ${t.clip.frames.length} · ${run?'播放中':'已暂停'}`;
 if(t.clip.portrait&&!t.clip.has_talk&&!t.clip.expression?.startsWith('@'))t.status.textContent+='\n此表情未定义说话动画';
 if(t.clip.death_particle&&t.clip.uses_original_particle)t.status.textContent+='\n沿用原版粒子';
 t.technical.textContent=`${t.b.file} · ${t.b.name}\n原图 ${f?.size?.join('×')||'缺失'} · 源帧 ${f?.index??'—'}\n显示 ${c.width}×${c.height} · 比例 ${scale.toFixed(3)}×`;
 if($('grid').checked&&scale<3)t.technical.textContent+='\n当前比例低于3×，省略密集像素网格';
 if(t.clip.portrait&&t.clip.goto)t.technical.textContent+='\n后续动画：'+t.clip.goto;
}
const mediaDraw=draw;
draw=function(){
 if(!extent)return;
 const all=clips;clips=all.filter(t=>!mediaCard(t));try{mediaDraw()}finally{clips=all}
 for(const t of clips.filter(mediaCard))paintMedia(t);
 const a=timingClip();if(a?.frames.length){$('frame').max=a.frames.length;if(document.activeElement!==$('frame'))$('frame').value=selectedFrame(a)[1]+1}
 $('pause').textContent=run?'暂停':'播放';$('workmessage').textContent=actionLabel($('action').value)+' · '+clips.length+' 栏 · '+(run?'播放中':'已暂停');
 if(clips.some(t=>t.c.role==='portraits'))$('dash-note').textContent='';
};
tick=function(now){
 const dt=Math.min(.1,(now-last)/1000||0);last=now;
 if(draft?.clock.run){advanceClock(draft.clock,draft.clip,dt,+$('copy-speed').value);drawCopy()}
 if(run){time+=dt*+$('speed').value;const duration=Math.max(0,...clips.map(t=>clipDuration(t.clip)));if(!repeat&&time>=duration)run=false;draw()}
 requestAnimationFrame(tick);
};

const mediaSeek=seek,mediaToggle=toggle;
seek=function(index){mediaSeek(index);const c=timingClip();if(c?.frame_durations)time=c.frame_durations.slice(0,manualIndex).reduce((a,b)=>a+b,0)};
toggle=function(){const c=timingClip();if(!run&&manualSeeking&&c?.frame_durations)time=c.frame_durations.slice(0,manualIndex).reduce((a,b)=>a+b,0);mediaToggle()};
$('pause').onclick=toggle;$('frame').oninput=$('frame').onchange=()=>seek(Math.max(1,+$('frame').value)-1);
