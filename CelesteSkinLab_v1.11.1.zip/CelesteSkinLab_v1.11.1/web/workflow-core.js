'use strict';
// Native-coordinate RGBA difference. Transparent RGB bytes carry no visible change.
function parseAllowedRegion(text) {
  if (!text.trim()) return null;
  const parts = text.split(',').map(s=>s.trim());
  if (parts.length!==4 || parts.some(s=>! /^-?\d+$/.test(s))) throw Error('限定区域填写 x,y,宽,高，均为整数');
  const r=parts.map(Number);
  if (r.some(v=>!Number.isSafeInteger(v)||Math.abs(v)>8192)||r[2]<=0||r[3]<=0) throw Error('区域宽高须为正，坐标范围为±8192');
  return r;
}
function nativeDifference(a,b,width,height,origin,region) {
  let changed=0,outside=0;const mask=new Uint8ClampedArray(a.length);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const i=(y*width+x)*4;
    if(a[i+3]===b[i+3]&&(a[i+3]===0||a[i]===b[i]&&a[i+1]===b[i+1]&&a[i+2]===b[i+2]))continue;
    changed++;
    const wx=x-origin[0],wy=y-origin[1];
    if(region&&!(wx>=region[0]&&wy>=region[1]&&wx<region[0]+region[2]&&wy<region[1]+region[3]))outside++;
    mask.set([255,45,140,220],i);
  }
  return {changed,outside,mask};
}
if(typeof module!=='undefined')module.exports={parseAllowedRegion,nativeDifference};
